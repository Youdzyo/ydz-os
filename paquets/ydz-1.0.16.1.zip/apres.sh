#!/bin/bash
echo "== 1.0.16.1 : correctif écran du Pi ($(date '+%H:%M:%S'))"
# dossier de travail du kiosque, toujours inscriptible (dans ReadWritePaths du service)
install -d -o ydz-kiosk -g ydz-kiosk -m 0750 /var/lib/ydz-kiosk 2>/dev/null \
    || { mkdir -p /var/lib/ydz-kiosk; chown ydz-kiosk:ydz-kiosk /var/lib/ydz-kiosk 2>/dev/null; }
# réinstaller l'unité durcie corrigée puis recharger systemd
if [ -f /opt/ydz/systemd/ydz-kiosk.service ]; then
    cp /opt/ydz/systemd/ydz-kiosk.service /etc/systemd/system/ydz-kiosk.service
    systemctl daemon-reload
    echo "unité ydz-kiosk mise à jour"
fi
# forcer l'écran en mode jour et relancer le kiosque (ydzd redémarre seul car lib/ a changé)
echo jour > /run/ydz/ecran-nuit 2>/dev/null || true
systemd-run --quiet --collect --on-active=20 /bin/systemctl restart ydz-kiosk
echo "== 1.0.16.1 terminé"
