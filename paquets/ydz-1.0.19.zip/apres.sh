#!/bin/bash
# YDZ 1.0.19 : agents assistants + « Bureaux de Claude » (page HDMI pixel-art) + Canal Claude (ntfy signé).
# ydzd est redémarré à la fin par le paquet (lib/ a changé). Rien de lourd ici : le cerveau des agents est
# l'app Ollama du catalogue — on ne l'installe JAMAIS tout seul (l'interface détecte et propose).
echo "== 1.0.19 : agents ($(date '+%H:%M:%S'))"

# Détection, sans rien installer : l'app Ollama est-elle présente et son API joignable ?
if curl -fsS -m 4 -o /dev/null http://127.0.0.1:11434/api/tags 2>/dev/null; then
    echo "Ollama joignable sur 127.0.0.1:11434 : les agents peuvent réfléchir en local"
else
    echo "Ollama non détecté : installe l'app « Ollama » depuis le catalogue (puis « ollama pull llama3.2:3b »), ou configure une API en ligne dans Réglages > Agents"
fi

# L'écran HDMI se recharge une fois ydzd revenu (nouvelle page « Les Bureaux de Claude »).
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.19 terminé"
