"""Serveur HTTP (bibliothèque standard) : API JSON, événements SSE, fichiers
statiques de l'interface (port web du hub uniquement)."""
import json
import mimetypes
import os
import queue
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, parse_qsl, urlsplit

from . import auth as authmod

MAX_BODY = 64 * 1024
MAX_PAQUET = 40 * 1024 * 1024          # paquets de mise à jour (.zip), route /api/maj/paquet
ROUTE_PAQUET = "/api/maj/paquet"
PLACEHOLDER = ("<!doctype html><meta charset=utf-8><title>YDZ OS</title>"
               "<body style='background:#000;color:#d9713f;font:20px sans-serif;padding:40px'>"
               "YDZ OS fonctionne. L'interface n'est pas encore installée (dossier ui/ vide).<br>"
               "<a style='color:#fff' href='/api/etat'>/api/etat</a></body>").encode()
mimetypes.add_type("font/woff2", ".woff2")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("application/manifest+json", ".webmanifest")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "ydzd"
    sys_version = ""
    timeout = 30

    def log_message(self, fmt, *args):      # pas de journal par requête (carte SD)
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _ctx(self, raw):
        node = self.server.node
        pair = self.client_address[0]
        # 1.0.12 : derrière `tailscale serve`, la requête arrive de 127.0.0.1 mais vient du tailnet
        relaye = authmod.relaye(self.headers)
        client = authmod.client_reel(pair, self.headers)
        tok = self.headers.get("X-YDZ-Jeton") or ""
        a = self.headers.get("Authorization") or ""
        if a.startswith("Bearer "):
            tok = a[7:].strip()
        sig = False
        if not node.hub:
            sig = authmod.verify_sig(node.state.get("cle_tour"), self.headers.get("X-YDZ-Sig"),
                                     self.command, self.path, raw, node.sys.now())
        local = node.local.trusted(pair, self.headers.get("X-YDZ-Local") or self._cookie(node.local.COOKIE)) \
            and not node.net_only and not relaye and authmod.hote_local(self.headers)
        login = (self.headers.get("Tailscale-User-Login") or "")[:120] if relaye and authmod.is_local(pair) else ""
        return {"client": client, "token": tok or None, "sig": sig, "local": local, "relaye": relaye,
                "tailscale": bool(login) or authmod.est_tailscale(client), "tailscale_login": login or None}

    def _cookie(self, name):
        try:
            c = SimpleCookie(self.headers.get("Cookie") or "")
            return c[name].value if name in c else None
        except CookieError:
            return None

    def _api(self, raw=b""):
        node = self.server.node
        u = urlsplit(self.path)
        body = {}
        if u.path == ROUTE_PAQUET and self.command == "POST":
            body = {"_brut": raw}             # zip brut : pas de JSON
        elif raw:
            try:
                body = json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return self._send(400, {"erreur": "Corps JSON illisible.", "code": "json"})
            if not isinstance(body, dict):
                return self._send(400, {"erreur": "Un objet JSON est attendu.", "code": "json"})
        ctx = self._ctx(raw)
        if u.path == "/api/events" and self.command == "GET":
            return self._sse()
        code, data = node.dispatch(self.command, u.path, dict(parse_qsl(u.query)), body, ctx)
        self._send(code, data)

    def _sse(self):
        node = self.server.node
        if not node.hub:
            return self._send(404, {"erreur": "Ce nœud n'est pas le hub.", "code": "pas_hub"})
        q = node.events.subscribe()
        if q is None:
            return self._send(503, {"erreur": "Trop d'écrans connectés en même temps.", "code": "occupe"})
        self.close_connection = True
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self._event("etat", node.hub.snapshot(node.status()))
            while not node.stop.is_set():
                try:
                    kind, data = q.get(timeout=15)
                    self._event(kind, data)
                except queue.Empty:
                    self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
        except (OSError, ValueError):
            pass
        finally:
            node.events.unsubscribe(q)

    def _event(self, kind, data):
        self.wfile.write(("event: %s\ndata: %s\n\n" % (
            kind, json.dumps(data, ensure_ascii=False, separators=(",", ":")))).encode())
        self.wfile.flush()

    def _ticket(self):
        """/?billet=… : échange un billet à usage unique contre le cookie du kiosque, puis revient à /."""
        node = self.server.node
        q = parse_qs(urlsplit(self.path).query)
        self.send_response(302)
        if authmod.is_local(self.client_address[0]) and not authmod.relaye(self.headers) \
                and node.local.redeem((q.get("billet") or [""])[0]):
            self.send_header("Set-Cookie", "%s=%s; Path=/; HttpOnly; SameSite=Strict; Max-Age=315360000"
                             % (node.local.COOKIE, node.local.token))
        # on garde le mode d'affichage demandé par le kiosque (?affichage=1)
        self.send_header("Location", "/?affichage=1" if (q.get("affichage") or [""])[0] == "1" else "/")
        self.send_header("Content-Length", "0")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _static(self):
        if "billet=" in urlsplit(self.path).query and urlsplit(self.path).path == "/":
            return self._ticket()
        root = os.path.realpath(self.server.ui_dir)
        rel = urlsplit(self.path).path.lstrip("/") or "index.html"
        full = os.path.realpath(os.path.join(root, rel))
        if not (full == root or full.startswith(root + os.sep)):
            return self._send(403, {"erreur": "Chemin refusé.", "code": "chemin"})
        if os.path.isdir(full):
            full = os.path.join(full, "index.html")
        if not os.path.isfile(full):
            if "." in os.path.basename(rel) and rel != "index.html":
                return self._send(404, {"erreur": "Fichier introuvable.", "code": "inconnu"})
            full = os.path.join(root, "index.html")       # routes de l'interface
            if not os.path.isfile(full):
                return self._send(200, PLACEHOLDER, "text/html; charset=utf-8")
        try:
            with open(full, "rb") as f:
                data = f.read()
        except OSError:
            return self._send(404, {"erreur": "Fichier introuvable.", "code": "inconnu"})
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "image/svg+xml"):
            ctype += "; charset=utf-8"
        long = full.endswith((".woff2", ".png", ".jpg", ".webp"))
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=86400" if long else "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def finish(self):
        try:
            BaseHTTPRequestHandler.finish(self)
        except OSError:                      # client parti (SSE fermé, onglet quitté)
            pass

    def do_GET(self):
        try:
            if self.path.startswith("/api/"):
                return self._api()
            if self.server.ui_dir:
                return self._static()
            self._send(404, {"erreur": "Ici, seule l'API répond (/api/status).", "code": "inconnu"})
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True

    do_HEAD = do_GET

    def do_POST(self):
        try:
            if not self.path.startswith("/api/"):
                return self._send(404, {"erreur": "Route inconnue.", "code": "inconnu"})
            # une page d'un autre site ne doit pas pouvoir agir à la place de l'écran local
            origin = self.headers.get("Origin")
            # « Origin: null » (iframe isolée, page locale) est refusé aussi : c'est le cas d'une page piégée
            if origin and urlsplit(origin).netloc != (self.headers.get("Host") or "") \
                    and not self._origine_relayee(origin):
                return self._send(403, {"erreur": "Origine refusée.", "code": "origine"})
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                n = -1
            limite = MAX_PAQUET if urlsplit(self.path).path == ROUTE_PAQUET else MAX_BODY
            if n < 0 or n > limite:
                self.close_connection = True
                return self._send(413, {"erreur": "Requête trop grosse.", "code": "taille"})
            self._api(self.rfile.read(n) if n else b"")
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True

    def _origine_relayee(self, origin):
        """Derrière tailscale serve (relais sur la machine), le navigateur parle à forge.tailXXXX.ts.net :
        l'origine est alors comparée à X-Forwarded-Host (qu'aucune page web ne peut fabriquer)."""
        if not (authmod.is_local(self.client_address[0]) and authmod.relaye(self.headers)):
            return False
        fh = (self.headers.get("X-Forwarded-Host") or "").split(",")[0].strip()
        u = urlsplit(origin)
        return bool(fh) and u.scheme == "https" and authmod.hote(u.netloc) == authmod.hote(fh) \
            and authmod.hote(fh).endswith(".ts.net")

    def do_OPTIONS(self):
        self._send(405, {"erreur": "Méthode non permise.", "code": "methode"})

    do_PUT = do_DELETE = do_PATCH = do_OPTIONS


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32

    def handle_error(self, request, client_address):
        import sys
        if isinstance(sys.exc_info()[1], (OSError, ValueError)):
            return                           # coupure réseau : rien à signaler
        ThreadingHTTPServer.handle_error(self, request, client_address)

    def __init__(self, addr, node, ui_dir=None):
        ThreadingHTTPServer.__init__(self, addr, Handler)
        self.node, self.ui_dir = node, ui_dir
