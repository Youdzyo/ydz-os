"""Code PIN (PBKDF2), sessions par jeton, limitation des essais, signature hub -> nœud."""
import hashlib
import hmac
import os
import re
import secrets
import threading

PBKDF2_ITER = 200_000
SESSION_TTL = 12 * 3600
MAX_TRIES = 5
LOCK_BASE = 30
LOCK_MAX = 900
SIG_SKEW = 90


def hash_pin(pin, salt=None, iterations=PBKDF2_ITER):
    salt = salt or os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", pin.encode(), salt, iterations)
    return "pbkdf2_sha256$%d$%s$%s" % (iterations, salt.hex(), dk.hex())


def check_pin(pin, stored):
    try:
        algo, it, salt, dk = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        calc = hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), int(it))
        return hmac.compare_digest(calc.hex(), dk)
    except (ValueError, AttributeError):
        return False


def valid_pin(pin):
    return isinstance(pin, str) and bool(re.match(r"^\d{4,8}$", pin))


def weak_pin(pin):
    return len(set(pin)) == 1 or pin in ("1234", "0123", "12345", "123456", "4321", "0000")


class RateLimiter:
    """5 essais, puis verrou de 30 s qui double à chaque nouvelle série ratée."""

    def __init__(self, sys):
        self.sys = sys
        self.d = {}
        self.lock = threading.Lock()

    def wait(self, key):
        with self.lock:
            e = self.d.get(key)
            if not e:
                return 0
            return max(0, int(e["until"] - self.sys.monotonic() + 0.999))

    def fail(self, key):
        with self.lock:
            e = self.d.setdefault(key, {"n": 0, "series": 0, "until": 0})
            e["n"] += 1
            if e["n"] >= MAX_TRIES:
                e["n"] = 0
                e["series"] += 1
                e["until"] = self.sys.monotonic() + min(LOCK_BASE * 2 ** (e["series"] - 1), LOCK_MAX)
            return MAX_TRIES - e["n"] if e["n"] else 0

    def success(self, key):
        with self.lock:
            self.d.pop(key, None)


class Auth:
    def __init__(self, sys, state):
        self.sys, self.state = sys, state
        self.sessions = {}
        self.limiter = RateLimiter(sys)
        self.lock = threading.Lock()

    @property
    def pin_set(self):
        return bool(self.state.get("pin"))

    def set_pin(self, pin):
        if not valid_pin(pin):
            raise ValueError("Le code doit faire 4 à 8 chiffres.")
        if weak_pin(pin):
            raise ValueError("Ce code est trop facile à deviner. Choisis-en un autre.")
        self.state.set("pin", hash_pin(pin))
        with self.lock:
            self.sessions.clear()

    def login(self, pin, client):
        """Retourne (jeton|None, message, attente_s)."""
        for key in (client, "*"):
            w = self.limiter.wait(key)
            if w:
                return None, "Trop d'essais. Réessaie dans %d s." % w, w
        if not self.pin_set:
            return None, "Aucun code PIN n'est encore défini.", 0
        if not (isinstance(pin, str) and check_pin(pin, self.state.get("pin"))):
            left = self.limiter.fail(client)
            w = self.limiter.wait(client)
            if w:
                return None, "Trop d'essais. Réessaie dans %d s." % w, w
            return None, "Code incorrect. Encore %d essai%s." % (left, "s" if left > 1 else ""), 0
        self.limiter.success(client)
        tok = secrets.token_urlsafe(32)
        with self.lock:
            now = self.sys.monotonic()
            self.sessions = {t: e for t, e in self.sessions.items() if e > now}
            if len(self.sessions) > 64:
                self.sessions.pop(next(iter(self.sessions)))
            self.sessions[tok] = now + SESSION_TTL
        return tok, "ok", 0

    def valid(self, token):
        if not token:
            return False
        with self.lock:
            exp = self.sessions.get(token)
            return bool(exp and exp > self.sys.monotonic())

    def logout(self, token):
        with self.lock:
            self.sessions.pop(token, None)


def is_local(addr):
    return addr in ("127.0.0.1", "::1", "::ffff:127.0.0.1")


# --- requêtes relayées (1.0.12 : `tailscale serve`) ------------------------------------------------------
# tailscaled relaie les visiteurs du tailnet vers http://127.0.0.1:80 : vue du démon, la requête vient de
# 127.0.0.1, comme l'écran de la tour. Elle ne doit JAMAIS être prise pour l'écran local. Un relais ajoute
# toujours au moins un de ces en-têtes (Tailscale : Tailscale-User-*, X-Forwarded-*), et son Host est le nom
# public du tailnet (forge.tailXXXX.ts.net). Le kiosque et la CLI, eux, appellent http://127.0.0.1/ en direct.
EN_TETES_RELAIS = ("Tailscale-User-Login", "Tailscale-User-Name", "Tailscale-User-Profile-Pic",
                   "Tailscale-Headers-Info", "X-Forwarded-For", "X-Forwarded-Host", "X-Forwarded-Proto",
                   "Forwarded", "X-Real-IP", "Via")
HOTES_LOCAUX = ("127.0.0.1", "localhost", "::1", "")


def hote(host):
    """« forge.tail1234.ts.net:443 » -> « forge.tail1234.ts.net » ; « [::1]:80 » -> « ::1 »."""
    h = (host or "").strip().lower()
    if h.startswith("["):
        h = h[1:].split("]", 1)[0]
    elif h.count(":") == 1:
        h = h.split(":", 1)[0]
    return h.rstrip(".")


def relaye(headers):
    """Vrai si la requête est passée par un relais (tailscale serve ou autre proxy)."""
    if any(headers.get(k) for k in EN_TETES_RELAIS):
        return True
    h = hote(headers.get("Host"))
    return h.endswith(".ts.net") or h.endswith(".beta.tailscale.net")


def hote_local(headers):
    """L'écran local n'appelle que 127.0.0.1 / localhost (ou sans Host, HTTP/1.0)."""
    return hote(headers.get("Host")) in HOTES_LOCAUX


def client_reel(pair, headers):
    """Adresse du vrai visiteur : X-Forwarded-For n'est cru que s'il vient d'un relais sur la machine."""
    if is_local(pair) and relaye(headers):
        xff = (headers.get("X-Forwarded-For") or "").split(",")[0].strip()
        if xff and len(xff) <= 45 and all(c in "0123456789abcdefABCDEF.:" for c in xff):
            return xff
    return pair


def est_tailscale(ip):
    """Adresse du tailnet (100.64.0.0/10 ou fd7a:115c:a1e0::/48)."""
    import ipaddress
    try:
        a = ipaddress.ip_address((ip or "").replace("::ffff:", ""))
    except ValueError:
        return False
    return a in ipaddress.ip_network("100.64.0.0/10") or a in ipaddress.ip_network("fd7a:115c:a1e0::/48")


class LocalToken:
    """Confiance « écran local » : la preuve n'est pas l'adresse 127.0.0.1 (un conteneur en réseau hôte
    y arrive aussi) mais un jeton que seuls root (CLI) et l'utilisateur du kiosque savent lire.
    Le navigateur du kiosque l'échange contre un cookie via un billet à usage unique (le jeton ne
    passe donc jamais dans la ligne de commande de Chromium)."""
    FILE = "/var/lib/ydz/jeton-local"
    KIOSK_FILE = "/var/lib/ydz-kiosk/jeton-local"
    KIOSK_USER = "ydz-kiosk"
    BILLET_TTL = 120
    COOKIE = "ydz_local"

    def __init__(self, sys, path=FILE, kiosk_path=KIOSK_FILE, kiosk_user=KIOSK_USER):
        self.sys, self.path, self.kiosk_path, self.kiosk_user = sys, path, kiosk_path, kiosk_user
        self.open = False                    # simulation seulement : 127.0.0.1 est cru sur parole
        self.billets = {}
        self.lock = threading.Lock()
        tok = (sys.read(path, "") or "").strip()
        if len(tok) < 32:
            tok = secrets.token_urlsafe(32)
            sys.write(path, tok + "\n", mode=0o600)
        self.token = tok
        self.publish()

    def publish(self):
        """Copie lisible par le seul utilisateur du kiosque (s'il existe)."""
        d = self.kiosk_path.rsplit("/", 1)[0]
        if not self.sys.exists(d):
            return False
        try:
            if (self.sys.read(self.kiosk_path, "") or "").strip() != self.token:
                self.sys.write(self.kiosk_path, self.token + "\n", mode=0o400)
            return self.sys.chown(self.kiosk_path, self.kiosk_user)
        except OSError:
            return False

    def check(self, candidate):
        return bool(candidate) and hmac.compare_digest(str(candidate), self.token)

    def trusted(self, client, candidate):
        return is_local(client) and (self.open or self.check(candidate))

    def make_billet(self):
        now = self.sys.monotonic()
        with self.lock:
            self.billets = {b: e for b, e in self.billets.items() if e > now}
            b = secrets.token_urlsafe(24)
            self.billets[b] = now + self.BILLET_TTL
        return b

    def redeem(self, billet):
        now = self.sys.monotonic()
        with self.lock:
            e = self.billets.pop(billet, None) if isinstance(billet, str) else None
        return bool(e and e > now)


# --- signature des ordres hub -> nœud ------------------------------------
def sign(token, method, path, ts, body=b""):
    msg = b"\n".join([method.upper().encode(), path.encode(), str(int(ts)).encode(),
                      hashlib.sha256(body or b"").digest().hex().encode()])
    return hmac.new(token.encode(), msg, hashlib.sha256).hexdigest()


def sig_header(token, method, path, ts, body=b""):
    return "%d:%s" % (int(ts), sign(token, method, path, ts, body))


def verify_sig(token, header, method, path, body, now):
    if not token or not header or ":" not in header:
        return False
    ts, sig = header.split(":", 1)
    try:
        ts = int(ts)
    except ValueError:
        return False
    if abs(now - ts) > SIG_SKEW:
        return False
    return hmac.compare_digest(sign(token, method, path, ts, body), sig)
