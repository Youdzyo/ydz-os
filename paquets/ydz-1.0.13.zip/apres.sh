#!/bin/bash
# YDZ 1.0.13 : réglages généraux. ydzd est redémarré à la fin par le paquet (lib/ a changé).
echo "== 1.0.13 : réglages généraux ($(date '+%H:%M:%S'))"
chmod 755 /opt/ydz/bin/ydz-nom-hote 2>/dev/null || true

# 1. Bluetooth : BlueZ seulement s'il manque (Pi OS Lite l'a normalement). Jamais bloquant.
if ! command -v bluetoothctl >/dev/null; then
    echo "bluetoothctl absent : installation de bluez et pi-bluetooth"
    apt-get -o Acquire::ForceIPv4=true -o Acquire::Retries=10 install -y --no-install-recommends bluez \
        || echo "bluez n'a pas pu être installé (Réglages > Général > Bluetooth restera indisponible)"
    apt-get -o Acquire::ForceIPv4=true -o Acquire::Retries=10 install -y --no-install-recommends pi-bluetooth \
        || echo "pi-bluetooth non installé (facultatif)"
else
    echo "Bluetooth : bluetoothctl présent"
fi
systemctl enable --now bluetooth.service >/dev/null 2>&1 || echo "service bluetooth non démarré (pas de puce ?)"

# 2. Fuseau horaire : Europe/Paris si le Pi est resté en UTC
TZ_ACTUEL=$(timedatectl show -p Timezone --value 2>/dev/null)
case "$TZ_ACTUEL" in
    ""|UTC|Etc/UTC) timedatectl set-timezone Europe/Paris && echo "fuseau horaire : $TZ_ACTUEL -> Europe/Paris" ;;
    *) echo "fuseau horaire : $TZ_ACTUEL (inchangé)" ;;
esac

# 3. Nom réseau : forge -> pi-one, une seule fois (si le Pi s'appelle encore forge)
MARQUE=/var/lib/ydz/renomme-1.0.13
if [ "$(hostname | cut -d. -f1)" = forge ] && [ ! -e "$MARQUE" ]; then
    echo "RENOMMAGE : forge -> pi-one (nouvelle adresse http://pi-one.local/, IP inchangée, Tailscale : pi-one)"
    if /opt/ydz/bin/ydz-nom-hote pi-one --role forge --sans-relance; then
        date '+%F %T forge -> pi-one' > "$MARQUE"
    else
        echo "RENOMMAGE raté : le Pi garde le nom forge (Réglages > Général > Nom pour réessayer)"
    fi
else
    echo "nom réseau : $(hostname) (inchangé)"
    touch "$MARQUE" 2>/dev/null || true
fi

# 4. Noms d'affichage : « Home Pi Lab », ce Pi = « Pi One » (posés par ydzd à son démarrage s'ils manquent)
echo "noms : Home Pi Lab / Pi One (ydzd les pose au redémarrage s'ils n'existent pas encore)"

# 5. l'écran HDMI se recharge une fois ydzd revenu (nouvelles pages, nouveau nom)
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.13 terminé"
