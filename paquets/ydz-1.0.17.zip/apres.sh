#!/bin/bash
# YDZ OS 1.0.17 « Catalogue d'applications ». ydzd est redémarré à la fin par le paquet (lib/ a changé).
# Les 126 nouvelles apps sont posées dans /opt/ydz/apps/ par le paquet ; elles ne s'installent qu'à la
# demande (pull Docker au clic), jamais pendant la mise à jour. Rien de lourd à faire ici.
# Idempotent et jamais fatal : chaque étape protège son échec.
echo "== 1.0.17 : catalogue d'applications ($(date '+%H:%M:%S'))"

# 1.0.17 (reprise du correctif 1.0.16.1) : réinstaller l'unité kiosque corrigée (dossiers inscriptibles)
install -d -o ydz-kiosk -g ydz-kiosk -m 0750 /var/lib/ydz-kiosk 2>/dev/null || { mkdir -p /var/lib/ydz-kiosk; chown ydz-kiosk:ydz-kiosk /var/lib/ydz-kiosk 2>/dev/null; }
if [ -f /opt/ydz/systemd/ydz-kiosk.service ]; then cp /opt/ydz/systemd/ydz-kiosk.service /etc/systemd/system/ydz-kiosk.service; systemctl daemon-reload; fi

# L'écran HDMI se recharge une fois ydzd revenu, pour afficher le nouveau catalogue et ses icônes.
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk 2>/dev/null \
    || echo "redémarrage du kiosque différé (systemd-run indisponible)"
echo "== 1.0.17 terminé"
