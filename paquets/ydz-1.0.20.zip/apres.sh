#!/bin/bash
# YDZ 1.0.20 : notifications iPhone (ANCS) + musique (AMS) en Bluetooth LE, affichage seul.
# Aucune installation : la fonction s'appuie sur BlueZ (déjà là depuis 1.0.13) et bluetoothctl, en
# sous-processus (pas de bibliothèque Python tierce). ydzd est redémarré à la fin par le paquet (lib/ a
# changé) ; l'écran HDMI se recharge pour afficher la nouvelle page « iPhone ».
echo "== 1.0.20 : iPhone Bluetooth (ANCS/AMS, affichage seul) ($(date '+%H:%M:%S'))"

# BlueZ présent ? (requis pour le lien GATT avec l'iPhone)
if command -v bluetoothctl >/dev/null 2>&1; then
    echo "bluetoothctl présent : le lien BLE pourra être tenté (expérimental, non vérifié sur matériel ici)"
else
    echo "bluetoothctl absent : installe BlueZ (le paquet 1.0.13 le fait), puis appaire l'iPhone dans Réglages > Général > Bluetooth"
fi

# L'écran HDMI se recharge une fois ydzd revenu (nouvelle page « iPhone »).
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.20 terminé"
