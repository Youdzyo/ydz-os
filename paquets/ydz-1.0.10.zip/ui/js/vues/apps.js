// Apps : catalogue, fiche d'une application, installation, réglages, journal, désinstallation.
import { esc, ic, memoire, ilYA } from "../outils.js";
import {
  S, NOM, btn, champ, interrupteur, pastille, vide, ouvrir, enteteDialogue, choisir, informer, toast, tenter, rendre,
} from "../noyau.js";
import { entete, tachePour } from "../cadre.js";
import { lire, lireProtege, agir, session } from "../api.js";

const ETATS = { actif: ["ok", "Active"], arrete: ["off", "Arrêtée"], partiel: ["warn", "Partielle"], erreur: ["crit", "En erreur"] };
const MASQUE = "••••••";

// ------------------------------------------------------------------------- formulaire de réglages
const cleChamp = (cle) => `r:${cle}`;
function valeurChoix(r, v) {
  const o = (r.choix || []).map((c) => (typeof c === "object" ? c : { valeur: c, nom: c }));
  return { options: o, courant: o.find((c) => String(c.valeur) === String(v)) };
}
function champReglage(r, donnees, erreurCle, edition) {
  const v = donnees[cleChamp(r.cle)] ?? "";
  let saisie;
  if (r.type === "booleen") {
    saisie = interrupteur("r-bascule", String(v) === "true", { cle: r.cle }, r.nom);
  } else if (r.type === "choix") {
    const { options, courant } = valeurChoix(r, v);
    saisie = options.length <= 4 && options.every((o) => String(o.nom).length <= 12)
      ? `<div class="segments">${options.map((o) => `<button type="button" class="${courant === o ? "actif" : ""}" data-action="r-choix" data-cle="${esc(r.cle)}" data-valeur="${esc(o.valeur)}">${esc(o.nom)}</button>`).join("")}</div>`
      : `<button type="button" class="champ selecteur" data-action="r-liste" data-cle="${esc(r.cle)}"><span>${esc(courant ? courant.nom : v || "Choisir")}</span>${ic("chevron-down")}</button>`;
  } else {
    saisie = champ(cleChamp(r.cle), v === MASQUE ? "" : v, {
      type: r.type === "secret" ? "secret" : "texte", chiffres: r.type === "nombre", erreur: erreurCle === r.cle, label: r.nom, max: 256,
      placeholder: r.type === "secret" ? (edition ? "Inchangé" : r.genere ? "Vide : créé automatiquement" : "") : "",
    });
  }
  return `<label class="reglage${r.type === "booleen" ? " en-ligne" : ""}${erreurCle === r.cle ? " erreur" : ""}" data-cle="rg-${esc(r.cle)}">
    <span class="reglage-nom">${esc(r.nom)}${r.requis ? " <em>requis</em>" : ""}</span>${saisie}
    ${r.aide ? `<small>${esc(r.aide)}</small>` : ""}</label>`;
}
function valeursInitiales(a, existants) {
  const d = {};
  for (const r of a.reglages) d[cleChamp(r.cle)] = existants?.[r.cle] ?? (r.defaut !== undefined ? String(r.defaut) : "");
  return d;
}
function collecter(a, donnees, edition) {
  const sortie = {};
  for (const r of a.reglages) {
    const v = String(donnees[cleChamp(r.cle)] ?? "");
    if (edition && r.type === "secret" && (v === "" || v === MASQUE)) continue; // garde la valeur actuelle
    sortie[r.cle] = v;
  }
  return sortie;
}
const actionsFormulaire = (app) => ({
  "r-bascule"({ cle }) { this.donnees[cleChamp(cle)] = String(this.donnees[cleChamp(cle)]) === "true" ? "false" : "true"; },
  "r-choix"({ cle, valeur }) { this.donnees[cleChamp(cle)] = valeur; },
  async "r-liste"({ cle }) {
    const r = app().reglages.find((x) => x.cle === cle);
    const v = await choisir({ titre: r.nom, options: valeurChoix(r, "").options, valeur: this.donnees[cleChamp(cle)] });
    if (v !== undefined) this.donnees[cleChamp(cle)] = String(v);
  },
});

// ------------------------------------------------------------------------------------ catalogue
function carteApp(a) {
  const ins = a.installations || [];
  const t = tachePour(a.id);
  const principale = ins[0];
  let pied;
  if (t) pied = `<span class="pastille cours">${ic("loader-circle", "tourne")}${esc(t.titre.split(" ")[0])}…</span>`;
  else if (principale) {
    const [ton, nom] = ETATS[principale.etat] || ETATS.erreur;
    pied = `${pastille(ton, nom)}<span class="sur">${ins.map((i) => NOM(i.noeud)).join(" · ")}</span>`;
  } else pied = `<span class="sur">${esc(a.categorie)}</span><span class="installer">Installer${ic("chevron-right")}</span>`;
  return `<a class="carte app${principale ? " installee" : ""}${principale?.etat === "actif" ? " active" : ""}" href="#/apps/${a.id}" data-cle="a-${a.id}">
    <span class="app-icone">${ic(a.icone)}</span>
    <div class="app-textes"><h2>${esc(a.nom)}</h2><p>${esc(a.description)}</p></div>
    <div class="app-pied">${pied}</div>
  </a>`;
}

function catalogue(vue) {
  const cat = S.apps?.catalogue || [];
  const f = vue.donnees.filtre;
  const categories = [...new Set(cat.map((a) => a.categorie))];
  const installees = cat.filter((a) => a.installations.length);
  const liste = f === "toutes" ? cat : f === "installees" ? installees : cat.filter((a) => a.categorie === f);
  const puce = (id, nom, n) => `<button type="button" class="puce${f === id ? " actif" : ""}" data-action="filtre" data-f="${esc(id)}">${esc(nom)}${n != null ? `<em>${n}</em>` : ""}</button>`;
  return `${entete("Applications", { sous: S.apps ? `${installees.length} installée${installees.length > 1 ? "s" : ""} sur ${cat.length}` : "" })}
    <div class="puces">${puce("toutes", "Toutes", cat.length)}${puce("installees", "Installées", installees.length)}${categories.map((c) => puce(c, c)).join("")}</div>
    ${(S.apps?.erreurs || []).map((e) => `<p class="bandeau warn">${ic("triangle-alert")}${esc(e)}</p>`).join("")}
    ${!S.apps ? `<div class="grille-apps">${'<div class="carte app fantome"></div>'.repeat(6)}</div>`
      : liste.length ? `<div class="grille-apps">${liste.map(carteApp).join("")}</div>`
      : vide("layout-grid", "Aucune application ici", "Choisis-en une dans le catalogue : elle s'installe en quelques minutes.", `<button type="button" class="btn plein" data-action="filtre" data-f="toutes">Voir le catalogue</button>`)}`;
}

// ---------------------------------------------------------------------------------------- fiche
function blocInstallation(a, i) {
  const [ton, nom] = ETATS[i.etat] || ETATS.erreur;
  const t = tachePour(a.id, i.noeud);
  const d = { noeud: i.noeud };
  const actif = i.etat === "actif" || i.etat === "partiel";
  return `<section class="carte installation" data-cle="i-${i.noeud}">
    <header>
      <div><h3>Sur ${NOM(i.noeud)}</h3><p>Installée ${ilYA(i.installe_le)}</p></div>
      ${t ? `<span class="pastille cours">${ic("loader-circle", "tourne")}${esc(t.titre)}</span>` : pastille(ton, nom)}
    </header>
    ${t && t.journal.length ? `<pre class="journal mini">${t.journal.map(esc).join("\n")}</pre>` : ""}
    ${i.url ? `<button type="button" class="adresse" data-action="ouvrir" data-url="${esc(i.url)}">${ic("globe")}<span>${esc(i.url.replace(/^https?:\/\//, ""))}</span>${ic("external-link")}</button>` : ""}
    <div class="actions">
      ${i.url ? btn("ouvrir", "Ouvrir", { icone: "external-link", classe: "plein", d: { url: i.url }, off: !actif }) : ""}
      ${actif ? btn("arreter", "Arrêter", { icone: "square", d, off: !!t }) : btn("demarrer", "Démarrer", { icone: "play", classe: i.url ? "" : "plein", d, off: !!t })}
      ${btn("redemarrer", "Redémarrer", { icone: "rotate-cw", d, off: !!t || !actif })}
      ${a.reglages.length ? btn("reglages", "Réglages", { icone: "settings", d, off: !!t }) : ""}
      ${btn("journal", "Journal", { icone: "scroll-text", d })}
      ${btn("mettre-a-jour", "Mettre à jour", { icone: "download", d, off: !!t })}
      ${btn("desinstaller", "Désinstaller", { icone: "trash-2", classe: "danger-texte", d, off: !!t })}
    </div>
  </section>`;
}

function blocInstaller(vue, a) {
  const noeuds = (vue.detail?.noeuds || S.apps?.noeuds || []).filter((n) => !a.installations.some((i) => i.noeud === n.nom));
  const d = vue.donnees;
  const choisi = noeuds.find((n) => n.nom === d.noeud) || noeuds.find((n) => n.nom === a.noeud_conseille && n.en_ligne) || noeuds.find((n) => n.en_ligne) || noeuds[0];
  if (!choisi) return "";
  const emplacements = choisi.emplacements || [];
  const manque = choisi.ram_libre != null && a.ram_mo * 2 ** 20 > choisi.ram_libre;
  const t = tachePour(a.id);
  return `<section class="carte installation nouvelle" data-cle="installer">
    <header><div><h3>Installer ${esc(a.nom)}</h3><p>Environ ${memoire(a.ram_mo * 2 ** 20)} de mémoire</p></div></header>
    <div class="reglage"><span class="reglage-nom">Sur quel nœud ?</span>
      <div class="segments">${noeuds.map((n) => `<button type="button" class="${n === choisi ? "actif" : ""}" data-action="noeud" data-nom="${n.nom}"${n.en_ligne && n.docker ? "" : " disabled"}>
        ${NOM(n.nom)}${n.nom === a.noeud_conseille ? "<em>conseillé</em>" : ""}${n.en_ligne ? "" : "<em>hors ligne</em>"}</button>`).join("")}</div>
      ${manque ? `<small class="alerte">${ic("triangle-alert")}Mémoire libre sur ${NOM(choisi.nom)} : ${memoire(choisi.ram_libre)}. C'est juste pour cette application.</small>` : ""}
    </div>
    ${emplacements.length ? `<div class="reglage"><span class="reglage-nom">Où ranger ses données ?</span>
      <div class="segments">
        <button type="button" class="${!d.emplacement ? "actif" : ""}" data-action="emplacement" data-chemin="">Carte système</button>
        ${emplacements.map((e) => `<button type="button" class="${d.emplacement === e ? "actif" : ""}" data-action="emplacement" data-chemin="${esc(e)}">Disque « ${esc(e.split("/").pop())} »</button>`).join("")}
      </div></div>` : ""}
    ${a.reglages.map((r) => champReglage(r, d, d.erreurCle, false)).join("")}
    <div class="actions">${t
      ? `<span class="pastille cours">${ic("loader-circle", "tourne")}${esc(t.titre)}…</span>`
      : btn("installer", `Installer sur ${NOM(choisi.nom)}`, { icone: "download", classe: "plein grand", d: { noeud: choisi.nom }, off: !choisi.en_ligne })}</div>
    ${t && t.journal.length ? `<pre class="journal mini">${t.journal.map(esc).join("\n")}</pre>` : ""}
  </section>`;
}

function fiche(vue, id) {
  const a = S.apps?.catalogue.find((x) => x.id === id);
  if (!a) {
    return `${entete("Application", { retour: "#/apps" })}${S.apps ? vide("circle-help", "Application introuvable", "Elle n'est pas au catalogue de cette tour.") : ""}`;
  }
  const installations = (vue.detail?.id === id ? vue.detail.installations : a.installations) || [];
  const complet = { ...a, installations };
  return `${entete(esc(a.nom), { retour: "#/apps", sous: esc(a.categorie) })}
  <div class="fiche-app">
    <aside class="carte resume">
      <span class="app-icone geant">${ic(a.icone)}</span>
      <p class="description">${esc(a.description)}</p>
      <dl class="fiche compacte">
        <div><dt>Mémoire</dt><dd>${memoire(a.ram_mo * 2 ** 20)}</dd></div>
        <div><dt>Ports</dt><dd>${a.ports.map((p) => `${p.port}${p.proto === "udp" ? "/udp" : ""}`).join(", ") || "–"}</dd></div>
        <div><dt>Conseillé sur</dt><dd>${NOM(a.noeud_conseille)}</dd></div>
        <div><dt>Image</dt><dd class="fin">${esc(a.image)}</dd></div>
      </dl>
      ${a.notes?.length ? `<ul class="notes">${a.notes.map((n) => `<li>${ic("info")}<span>${esc(n)}</span></li>`).join("")}</ul>` : ""}
      ${a.privilegie || a.reseau_hote ? `<p class="note-fine">${ic("shield")}${a.reseau_hote ? "Utilise directement le réseau du nœud." : "Demande des droits étendus sur le nœud."}</p>` : ""}
    </aside>
    <div class="colonne">
      ${installations.map((i) => blocInstallation(complet, i)).join("")}
      ${!installations.length || vue.donnees.ailleurs ? blocInstaller(vue, complet)
        : (S.apps?.noeuds.length || 0) > installations.length ? `<button type="button" class="btn discret seul" data-action="ailleurs">${ic("plus")}<span>Installer aussi sur un autre nœud</span></button>` : ""}
    </div>
  </div>`;
}

// ------------------------------------------------------------------------------------ dialogues
function ouvrirReglages(a, installation) {
  const d = ouvrir({
    classe: "large",
    donnees: valeursInitiales(a, installation.reglages),
    rendu: () => `${enteteDialogue(`Réglages de ${esc(a.nom)}`, { icone: "settings", sous: `Sur ${NOM(installation.noeud)}. L'application redémarre pour les appliquer.` })}
      <div class="dlg-corps formulaire">${a.reglages.map((r) => champReglage(r, d.donnees, d.donnees.erreurCle, true)).join("")}</div>
      <footer class="dlg-pied">${btn("fermer", "Annuler", { classe: "discret" })}${btn("enregistrer", "Enregistrer", { icone: "check", classe: "plein" })}</footer>`,
    actions: {
      ...actionsFormulaire(() => a),
      async enregistrer() {
        try {
          await agir(`/api/apps/${a.id}/reglages`, { noeud: installation.noeud, reglages: collecter(a, d.donnees, true) });
          d.fermer();
        } catch (e) {
          d.donnees.erreurCle = e.donnees?.cle || null;
          throw e;
        }
      },
    },
  });
}

function ouvrirJournal(a, nomNoeud) {
  const d = ouvrir({
    classe: "large haut",
    donnees: { lignes: null, erreur: "" },
    rendu: () => `${enteteDialogue(`Journal de ${esc(a.nom)}`, { icone: "scroll-text", sous: `Sur ${NOM(nomNoeud)} · 200 dernières lignes` })}
      <div class="dlg-corps sans-marge">${d.donnees.lignes
        ? d.donnees.lignes.length ? `<pre class="journal" id="journal-app">${d.donnees.lignes.map(esc).join("\n")}</pre>` : vide("scroll-text", "Journal vide", "L'application n'a encore rien écrit.")
        : d.donnees.erreur ? vide("circle-x", "Journal indisponible", esc(d.donnees.erreur)) : `<div class="attente">${ic("loader-circle", "tourne")}</div>`}</div>
      <footer class="dlg-pied">${btn("actualiser", "Actualiser", { icone: "refresh-cw", classe: "discret" })}${btn("fermer", "Fermer", { classe: "plein" })}</footer>`,
    actions: { actualiser: () => relire() },
  });
  async function relire() {
    try {
      const r = await lireProtege(`/api/apps/${a.id}/journal?noeud=${encodeURIComponent(nomNoeud)}&lignes=200`);
      d.donnees.lignes = r.lignes;
      d.donnees.erreur = "";
    } catch (e) {
      d.donnees.erreur = e.message;
      if (e.code === "annule") d.fermer();
    }
    rendre();
    setTimeout(() => { const p = document.getElementById("journal-app"); if (p) p.scrollTop = p.scrollHeight; }, 40);
  }
  relire();
}

function ouvrirDesinstaller(a, nomNoeud) {
  const d = ouvrir({
    classe: "etroit",
    donnees: { supprimer: false },
    rendu: () => `${enteteDialogue(`Désinstaller ${esc(a.nom)} ?`, { icone: "triangle-alert", ton: "danger", sansCroix: true })}
      <div class="dlg-corps">
        <p class="texte">${esc(a.nom)} sera arrêtée et retirée de ${NOM(nomNoeud)}.</p>
        <label class="reglage en-ligne cadre${d.donnees.supprimer ? " danger" : ""}">
          <span class="reglage-nom">Supprimer aussi les données</span>${interrupteur("bascule", d.donnees.supprimer, {}, "Supprimer aussi les données")}
          <small>${d.donnees.supprimer ? "Mondes, fichiers et réglages de cette application seront effacés définitivement." : "Ses données sont gardées : en la réinstallant, tu retrouves tout."}</small>
        </label>
      </div>
      <footer class="dlg-pied">${btn("fermer", "Annuler", { classe: "discret" })}${btn("valider", d.donnees.supprimer ? "Désinstaller et effacer" : "Désinstaller", { icone: "trash-2", classe: "danger" })}</footer>`,
    actions: {
      bascule() { d.donnees.supprimer = !d.donnees.supprimer; },
      async valider() {
        await agir(`/api/apps/${a.id}/desinstaller`, { noeud: nomNoeud, supprimer_donnees: d.donnees.supprimer });
        d.fermer();
      },
    },
  });
}

// ------------------------------------------------------------------------------------------ vue
const vue = {
  donnees: { filtre: "toutes" },
  detail: null,
  entrer(args) {
    const id = args[0];
    if (id !== this.idCourant) {
      this.idCourant = id;
      this.detail = null;
      const filtre = this.donnees.filtre;
      this.donnees = { filtre };
      this.formulairePret = false;
    }
  },
  async charger(args) {
    const id = args[0];
    if (!id) return;
    const r = await lire(`/api/apps/${id}`).catch(() => null);
    if (r && this.idCourant === id) this.detail = r;
  },
  app() { return S.apps?.catalogue.find((x) => x.id === this.idCourant); },
  rendu(args) {
    if (!args[0]) return catalogue(this);
    const a = this.app();
    if (a && !this.formulairePret) { Object.assign(this.donnees, valeursInitiales(a)); this.formulairePret = true; }
    return fiche(this, args[0]);
  },
  actions: {
    ...actionsFormulaire(() => vue.app()),
    filtre({ f }) { this.donnees.filtre = f; },
    noeud({ nom }) { this.donnees.noeud = nom; this.donnees.emplacement = ""; },
    emplacement({ chemin }) { this.donnees.emplacement = chemin; },
    ailleurs() { this.donnees.ailleurs = true; },
    async installer({ noeud: n }) {
      const a = this.app();
      try {
        const corps = { noeud: n, reglages: collecter(a, this.donnees, false) };
        if (this.donnees.emplacement) corps.emplacement = this.donnees.emplacement;
        const r = await agir(`/api/apps/${a.id}/installer`, corps);
        this.donnees.erreurCle = null;
        this.donnees.ailleurs = false;
        if (r.tache && S.etat && !S.etat.taches.some((t) => t.id === r.tache.id)) S.etat.taches.unshift(r.tache);
        toast(`Installation de ${a.nom} lancée sur ${NOM(r.noeud || n)}.`);
      } catch (e) {
        this.donnees.erreurCle = e.donnees?.cle || null;
        throw e;
      }
    },
    async demarrer({ noeud: n }) { await this.simple("demarrer", n); },
    async arreter({ noeud: n }) { await this.simple("arreter", n); },
    async redemarrer({ noeud: n }) { await this.simple("redemarrer", n); },
    async "mettre-a-jour"({ noeud: n }) { await this.simple("mettre-a-jour", n); },
    async reglages({ noeud: n }) {
      const a = this.app();
      // Relit la fiche : les réglages y sont en clair pour l'écran local ou une session PIN.
      const r = await tenter(() => lire(`/api/apps/${a.id}`));
      const i = (r || a).installations.find((x) => x.noeud === n);
      if (i) ouvrirReglages(a, i);
    },
    journal({ noeud: n }) { ouvrirJournal(this.app(), n); },
    desinstaller({ noeud: n }) { ouvrirDesinstaller(this.app(), n); },
    ouvrir({ url }) {
      if (session.demo) {
        return informer({ titre: "Démonstration", icone: "sparkles", texte: `<p>Sur la vraie tour, ce bouton ouvre l'application à l'adresse :</p><p class="adresse-grande">${esc(url)}</p>` });
      }
      if (session.auth.local) {
        return informer({ titre: "Ouvre-la sur ton appareil", icone: "smartphone", texte: `<p>L'écran de la tour reste sur YDZ OS. Depuis ton téléphone ou ton PC, va à l'adresse :</p><p class="adresse-grande">${esc(url)}</p>` });
      }
      window.open(url, "_blank", "noopener");
      return undefined;
    },
  },
  async simple(action, n) {
    const a = this.app();
    const r = await agir(`/api/apps/${a.id}/${action}`, { noeud: n });
    if (r.tache && S.etat && !S.etat.taches.some((t) => t.id === r.tache.id)) S.etat.taches.unshift(r.tache);
  },
};
export default vue;
