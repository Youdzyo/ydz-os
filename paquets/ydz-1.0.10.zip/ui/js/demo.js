// YDZ Shell : mode démonstration. Un faux hub, dans le navigateur, qui répond comme l'API de TECHNIQUE.md §3
// (mêmes routes, mêmes formes de JSON, mêmes codes d'erreur). Rien ne sort de la page, rien n'est gardé.
import DONNEES from "./demo-donnees.js";

const clone = (o) => JSON.parse(JSON.stringify(o));
const D = clone(DONNEES);
const maintenant = () => Math.floor(Date.now() / 1000);
const alea = (a, b) => a + Math.random() * (b - a);
const id8 = () => Math.random().toString(16).slice(2, 10).padEnd(8, "0");
const ok = (json = {}) => ({ statut: 200, json: { ok: true, ...json } });
const lu = (json) => ({ statut: 200, json });
const err = (statut, code, erreur, plus = {}) => ({ statut, json: { erreur, code, ...plus } });

const abonnes = new Set();
const diffuser = (type, donnee) => abonnes.forEach((a) => a[type] && a[type](clone(donnee)));
const notifier = (texte, niveau = "info") => diffuser("surNotification", { niveau, texte });

// --------------------------------------------------------------------------------- état de départ
const N = Object.fromEntries(D.etat.noeuds.map((n) => [n.nom, n]));
const ORDRE = D.etat.noeuds.map((n) => n.nom);
const CATALOGUE = D.apps.catalogue;
const app = (id) => CATALOGUE.find((a) => a.id === id);
const base = { forge: { temp: 52, cpu: 34, ram: 38 }, vault: { temp: 44, cpu: 9, ram: 21 }, pulse: { temp: 41, cpu: 6, ram: 33 } };
const debitBase = { forge: [9.5e6, 2.1e6], vault: [42e6, 6.4e6], pulse: [1.3e6, 0.6e6] };
const demarrage = maintenant();
const allumage = { forge: demarrage - 4 * 86400 - 7000, vault: demarrage - 4 * 86400 - 6900, pulse: demarrage - 86400 - 3000 };
const horsLigne = {}; // nom -> true

// Installations : la référence. Le catalogue et l'état des nœuds en sont déduits.
const inst = { forge: {}, vault: {}, pulse: {} };
function poser(noeud, id, etat, reglages = {}, jours = 3) {
  const a = app(id);
  const defauts = Object.fromEntries(a.reglages.filter((r) => r.defaut !== undefined).map((r) => [r.cle, String(r.defaut)]));
  inst[noeud][id] = {
    etat, reglages: { ...defauts, ...reglages }, installe_le: maintenant() - jours * 86400,
    donnees: noeud === "vault" ? `/srv/ydz/donnees/apps/${id}` : `/var/lib/ydz/donnees/${id}`,
  };
}
poser("forge", "minecraft", "actif", { TYPE: "NEOFORGE", VERSION: "1.21.1", MEMOIRE: "8G", MOTD: "Serveur YDZ" }, 12);
poser("forge", "portainer", "actif", {}, 12);
poser("pulse", "pihole", "actif", { MOT_DE_PASSE: "demo-pihole" }, 9);
poser("pulse", "wg-easy", "actif", {}, 9);
poser("vault", "jellyfin", "actif", { MEDIAS: "/srv/ydz/donnees/partages" }, 6);

// Un troisième disque sur vault, déjà préparé mais pas monté : pour montrer « Remonter ».
const SV = D.stockage.vault;
SV.disques.find((d) => d.id === "sda").libre = 431e9;
SV.disques.push({
  id: "sdc", chemin: "/dev/sdc", modele: "WD Red Plus 4TB", serie: "WD-WX42D81K7TLE", taille: 4000787030016,
  type: "hdd", transport: "sata", amovible: false, systeme: false,
  partitions: [{ chemin: "/dev/sdc1", type: "part", taille: 4000785981440, fs: "ext4", etiquette: "ydz-archives", uuid: "5d1c0de0-aaaa-bbbb-cccc-000000000003", montage: [] }],
  montage: null, nom: null, vide: false, miroir: false, a_remonter: "archives", formatable: true, raison: null,
  smart: { sain: true, temp: 34, heures: 18250, secteurs_realloues: 0, usure_pct: null, avis: null }, total: null, libre: null,
});
SV.partages.push({ nom: "photos", disque: "donnees", chemin: "/srv/ydz/donnees/partages/photos", acces: "prive", adresse: "\\\\vault\\photos", adresse_mac: "smb://vault.local/photos" });
SV.samba.mot_de_passe_defini = true;
D.wol.cibles[0].en_ligne = false;
D.maj.noeuds.forEach((m) => { m.derniere_verif = maintenant() - 86400 * 2; m.paquets = 0; m.derniere_maj = maintenant() - 86400 * 9; });
D.systeme.simulation = true;

const ventilo = D.etat.ventilo;
const ecran = D.etat.ecran;
let testVentiloFin = 0;
let arretTour = false;
let taches = [];
const jetons = {}; // jeton -> préparation de formatage

// ------------------------------------------------------------------------------------- mesures
function derive(v, cible, pas, min, max) {
  const n = v + (cible - v) * 0.15 + alea(-pas, pas);
  return Math.min(max, Math.max(min, n));
}
function tic() {
  for (const nom of ORDRE) {
    const n = N[nom];
    if (horsLigne[nom]) continue;
    const b = base[nom];
    const charge = Object.values(inst[nom]).filter((i) => i.etat === "actif").length;
    n.cpu = Math.round(derive(n.cpu, b.cpu + charge * 2, 4, 1, 97) * 10) / 10;
    n.temp = Math.round(derive(n.temp, b.temp + (n.cpu - b.cpu) * 0.12, 0.5, 30, 84) * 10) / 10;
    const ramPct = derive(n.ram.pct, b.ram + charge * 3, 0.6, 5, 95);
    n.ram.pct = Math.round(ramPct * 10) / 10;
    n.ram.utilise = Math.round((n.ram.total * ramPct) / 100);
    n.charge = [n.cpu / 25, n.cpu / 27, n.cpu / 30].map((x) => Math.round(x * 100) / 100);
    n.reseau.rx_bps = Math.round(derive(n.reseau.rx_bps, debitBase[nom][0], debitBase[nom][0] * 0.35, 2e4, 9e8));
    n.reseau.tx_bps = Math.round(derive(n.reseau.tx_bps, debitBase[nom][1], debitBase[nom][1] * 0.35, 1e4, 9e8));
    n.uptime = maintenant() - allumage[nom];
    n.heure = maintenant();
  }
  const enLigne = ORDRE.filter((x) => !horsLigne[x]);
  const chaud = enLigne.reduce((a, x) => (N[x].temp > (a ? N[a].temp : -1) ? x : a), null);
  ventilo.temp = chaud ? N[chaud].temp : null;
  ventilo.noeud = chaud;
  ventilo.test = maintenant() < testVentiloFin;
  const consigne = chaud ? interpoler(ventilo.courbe, ventilo.temp) : 100;
  ventilo.consigne = ventilo.test ? 100 : Math.round(consigne);
  ventilo.vitesse = ventilo.consigne;
  for (const m of SV.miroirs) {
    if (m.etat === "reconstruction") {
      m.progression = Math.min(100, Math.round((m.progression + alea(2, 5)) * 10) / 10);
      if (m.progression >= 100) { m.etat = "sain"; m.progression = null; }
    }
  }
}
function interpoler(courbe, t) {
  if (t <= courbe[0][0]) return courbe[0][1];
  for (let i = 1; i < courbe.length; i++) {
    const [t0, v0] = courbe[i - 1], [t1, v1] = courbe[i];
    if (t <= t1) return v0 + ((v1 - v0) * (t - t0)) / (t1 - t0 || 1);
  }
  return courbe[courbe.length - 1][1];
}

function conteneurs(noeud, id) {
  const i = inst[noeud][id];
  const marche = i.etat === "actif";
  return [{
    nom: `ydz-${id}-${id}-1`, image: app(id).image, etat: marche ? "running" : "exited",
    statut: marche ? "Up 3 days" : "Exited (0) 2 minutes ago", app: id,
  }];
}
function adresse(noeud, a) {
  return a.web ? `${a.web.schema}://${N[noeud].ip}:${a.web.port}${a.web.chemin}` : null;
}
function masquer(a, reglages) {
  const secrets = new Set(a.reglages.filter((r) => r.type === "secret").map((r) => r.cle));
  return Object.fromEntries(Object.entries(reglages).map(([k, v]) => [k, secrets.has(k) && v ? "••••••" : v]));
}
function installations(a, clair) {
  return ORDRE.filter((n) => inst[n][a.id]).map((n) => {
    const i = inst[n][a.id];
    return {
      noeud: n, etat: i.etat, url: adresse(n, a), conteneurs: conteneurs(n, a.id),
      reglages: clair ? { ...i.reglages } : masquer(a, i.reglages), donnees: i.donnees, installe_le: i.installe_le,
    };
  });
}
function noeudsApps() {
  return ORDRE.map((n) => ({
    nom: n, role: N[n].role, en_ligne: !horsLigne[n], docker: true, ram_total: N[n].ram.total,
    ram_libre: N[n].ram.total - N[n].ram.utilise,
    emplacements: n === "vault" ? SV.disques.filter((d) => d.montage).map((d) => d.montage) : [],
  }));
}

function etat() {
  tic();
  const alertes = [];
  const noeuds = ORDRE.map((nom) => {
    const n = N[nom];
    n.en_ligne = !horsLigne[nom];
    n.connu = true;
    n.vu_il_y_a = n.en_ligne ? 0 : 20;
    n.etat = !n.en_ligne ? n.etat : n.temp >= 80 ? "crit" : n.temp >= 70 ? "warn" : "ok";
    n.apps = Object.keys(inst[nom]).map((id) => ({
      id, etat: inst[nom][id].etat, conteneurs: conteneurs(nom, id), reglages: {}, donnees: inst[nom][id].donnees,
      installe_le: inst[nom][id].installe_le, au_catalogue: true,
    }));
    n.docker = { dispo: true, conteneurs: n.apps.flatMap((x) => x.conteneurs) };
    n.redemarrage_requis = Boolean(D.maj.noeuds.find((m) => m.noeud === nom)?.redemarrage_requis);
    if (nom === "vault") {
      n.disques = [n.disques[0], ...SV.disques.filter((d) => d.montage && d.total).map((d) => ({
        point: d.montage, nom: d.nom, peripherique: d.partitions[0]?.chemin || d.chemin, fs: "ext4",
        total: d.total, utilise: d.total - d.libre, pct: Math.round(((d.total - d.libre) / d.total) * 100),
      }))];
    }
    if (!n.en_ligne && !arretTour) alertes.push({ noeud: nom, niveau: "warn", texte: `${nom.toUpperCase()} ne répond plus` });
    return n;
  });
  taches = taches.slice(0, 12);
  return {
    heure: maintenant(), hub: "forge", version: D.etat.version,
    tour: DEMO_Q.get("alerte") === "crit" ? { etat: "crit", alertes: [{ noeud: "forge", niveau: "crit", texte: "FORGE surchauffe : 86 °C" }, { noeud: "forge", niveau: "warn", texte: "Disque système plein à 94 %" }], arret_en_cours: false }
      : DEMO_Q.get("alerte") === "warn" ? { etat: "warn", alertes: [{ noeud: "forge", niveau: "warn", texte: "Disque système plein à 91 %" }], arret_en_cours: false }
      : { etat: alertes.length ? "warn" : "ok", alertes, arret_en_cours: arretTour },
    noeuds, ventilo, ecran, taches, auth: { pin_defini: true },
    reseau_maison: reseauDemo(),
    pihole: piholeDemo(),
    affichage: affichageDemo(noeuds),
  };
}

// écran du Pi : nuit, météo, PC, services, conso (?nuit=horloge|eteint et ?alerte=crit|warn pour essayer)
const DEMO_Q = new URLSearchParams(location.search);
const DEMO_DEBUT = maintenant();
const DEMO_REG = { nuit_actif: true, nuit_debut: "00:00", nuit_fin: "07:00", nuit_mode: DEMO_Q.get("nuit") || "eteint", rotation_s: Number(DEMO_Q.get("rotation") ?? 30), meteo_ville: "Toulouse", prix_kwh: 0.194 };
function affichageDemo(noeuds) {
  const nuit = DEMO_Q.get("nuit");
  const R = DEMO_REG;
  const watts = noeuds.filter((n) => n.en_ligne).reduce((s, n) => s + 3 + 5 * (n.cpu || 0) / 100, 0);
  const heures = Array.from({ length: 8 }, (_, i) => {
    const h = (new Date().getHours() + i) % 24;
    return { h: `${String(h).padStart(2, "0")}h`, temp: Math.round(12 + 4 * Math.sin((h - 9) / 24 * 6.28)), icone: h > 18 || h < 7 ? "moon" : i > 4 ? "cloud-rain" : "cloud-sun", pluie: i > 4 ? 60 : 0 };
  });
  const j = (k) => new Date(Date.now() + k * 864e5).toISOString().slice(0, 10);
  return {
    nuit: { actif: R.nuit_actif, debut: R.nuit_debut, fin: R.nuit_fin, mode: R.nuit_mode, en_cours: Boolean(nuit) && R.nuit_actif },
    rotation_s: R.rotation_s, meteo_ville: R.meteo_ville,
    meteo: { ville: R.meteo_ville, temp: 14, ressenti: 12, texte: "Partiellement nuageux", icone: "cloud-sun", vent: 18, humidite: 72,
      heures, jours: [{ date: j(0), min: 8, max: 16, icone: "cloud-sun" }, { date: j(1), min: 9, max: 14, icone: "cloud-rain" }, { date: j(2), min: 6, max: 13, icone: "sun" }], maj: maintenant() },
    pc: { nom: "PC de Justin", en_ligne: true, depuis: DEMO_DEBUT - 2 * 3600 - 840 },
    services: [
      { id: "homeassistant", nom: "Home Assistant", icone: "house-plug", noeud: "forge", etat: "ok" },
      { id: "minecraft", nom: "Minecraft", icone: "pickaxe", noeud: "forge", etat: "ok" },
      { id: "pihole", nom: "Pi-hole", icone: "shield", noeud: "forge", etat: "ok" },
      { id: "portainer", nom: "Portainer", icone: "container", noeud: "forge", etat: "ok" },
      { id: "uptime-kuma", nom: "Uptime Kuma", icone: "activity", noeud: "forge", etat: "warn" },
      { id: "wg-easy", nom: "WireGuard (wg-easy)", icone: "shield-check", noeud: "forge", etat: "off" },
    ],
    conso: { watts: Math.round(watts * 10) / 10, mesure: false, kwh_mois: Math.round(watts * 7.2 * 10) / 10, euros_mois: Math.round(watts * 7.2 * R.prix_kwh * 100) / 100, prix_kwh: R.prix_kwh },
  };
}

// réseau de la maison (1.0.10) : appareils, Wi-Fi du Pi, débit des nuits passées, Pi-hole
// (?wifi=faible|filaire et ?pihole=0 pour essayer les autres cas)
const H = 3600, J = 86400;
const APPAREILS = [
  ["dc:a6:32:5e:10:41", "192.168.1.41", "forge", "", 60 * J, 0, true, true],
  ["a4:3e:51:8c:02:01", "192.168.1.1", "livebox", "Livebox", 60 * J, 0, true],
  ["d8:3a:dd:12:7a:42", "192.168.1.42", "vault", "", 41 * J, 0, true],
  ["d8:3a:dd:12:7a:43", "192.168.1.43", "pulse", "", 41 * J, 0, true],
  ["f2:6b:91:3c:aa:35", "192.168.1.35", "iPhone de Justin", "", 60 * J, 0, true],
  ["2c:f0:5d:a1:b2:40", "192.168.1.40", "DESKTOP 7K2QH1", "PC de Justin", 60 * J, 0, true],
  ["8c:79:f5:20:11:52", "192.168.1.52", "Samsung", "TV Samsung", 60 * J, 0, true],
  ["78:c8:81:4e:90:60", "192.168.1.60", "PS5 712", "PS5", 52 * J, 0, true],
  ["a8:51:ab:77:31:36", "192.168.1.36", "iPad", "iPad du salon", 60 * J, 0, true],
  ["e4:f0:42:9b:00:21", "192.168.1.21", "Google Nest Mini", "", 33 * J, 0, true],
  ["ec:b5:fa:0d:44:22", "192.168.1.22", "Philips hue", "Pont Philips Hue", 60 * J, 0, true],
  ["02:7d:c4:19:e8:77", "192.168.1.77", "", "", 40 * 60, 0, true],
  ["3c:2a:f4:6e:c1:70", "192.168.1.70", "HP DeskJet 2700", "", 58 * J, 3 * H + 1200, false],
  ["5a:12:fe:33:70:38", "192.168.1.38", "Galaxy A54", "", 19 * J, 5 * H, false],
  ["f0:18:98:aa:12:45", "192.168.1.45", "MacBook Air", "", 25 * J, 2 * J + 4 * H, false],
].map(([mac, ip, nom_auto, nom_perso, depuis, vu, en_ligne, moi]) => ({
  mac, ip, nom_auto, nom_perso, premiere_vue: DEMO_DEBUT - depuis, derniere_vue: DEMO_DEBUT - vu, en_ligne, moi: Boolean(moi),
}));
const nomAppareil = (a) => a.nom_perso || a.nom_auto || "";
function listeAppareils() {
  return APPAREILS.map((a) => ({ ...a, nom: nomAppareil(a), derniere_vue: a.en_ligne ? maintenant() - 40 : a.derniere_vue }))
    .sort((a, b) => (b.moi - a.moi) || (b.en_ligne - a.en_ligne) || (b.derniere_vue - a.derniere_vue) || a.nom.localeCompare(b.nom));
}
const NOUVEAUX = [{ t: DEMO_DEBUT - 40 * 60, mac: "02:7d:c4:19:e8:77", ip: "192.168.1.77", nom: "" }];
// 30 nuits de mesures, à 03:30 (valeurs stables d'une visite à l'autre)
const DEBITS = Array.from({ length: 30 }, (_, i) => {
  const d = new Date(); d.setHours(3, 30, 0, 0);
  if (d.getTime() > Date.now()) d.setDate(d.getDate() - 1);
  d.setDate(d.getDate() - (29 - i));
  const s = Math.sin(i * 1.7) * 0.5 + Math.sin(i * 0.53) * 0.5;
  return { t: Math.floor(d.getTime() / 1000), down_mbps: Math.round((236 + 48 * s - (i === 11 ? 120 : 0)) * 10) / 10, up_mbps: Math.round((61 + 14 * Math.cos(i * 1.3)) * 10) / 10, ping_ms: Math.round((13 + 4 * Math.abs(Math.sin(i * 2.1))) * 10) / 10 };
});
const DEBIT = { en_cours: false, erreur: null };
function wifiDemo() {
  const w = DEMO_Q.get("wifi");
  if (w === "filaire") return { filaire: true };
  const dbm = w === "faible" ? -84 : -71;
  const pct = Math.round(Math.max(0, Math.min(100, (dbm + 90) * 2.5)));
  return { ssid: "Livebox-A1B2", signal_dbm: dbm, qualite_pct: pct, debit_mbps: w === "faible" ? 58 : 433, frequence_mhz: w === "faible" ? 2437 : 5180, niveau: pct >= 75 ? "excellent" : pct >= 50 ? "bon" : pct >= 25 ? "moyen" : "faible" };
}
function reseauDemo() {
  const enLigne = APPAREILS.filter((a) => a.en_ligne).length;
  const recents = APPAREILS.filter((a) => !a.moi).sort((a, b) => b.premiere_vue - a.premiere_vue).slice(0, 6)
    .map((a) => ({ nom: nomAppareil(a), ip: a.ip, en_ligne: a.en_ligne, premiere_vue: a.premiere_vue }));
  return {
    appareils: enLigne, tailscale: 2, maj: DEMO_DEBUT, connus: APPAREILS.length, nouveaux: NOUVEAUX, recents,
    debit: { en_cours: DEBIT.en_cours, dernier: DEBITS[DEBITS.length - 1], historique: DEBITS, erreur: DEBIT.erreur, heure_nuit: "03:30" },
    wifi: wifiDemo(),
  };
}
const PIHOLE = { bloquees: 9120, requetes: 48211 };
function piholeDemo() {
  if (DEMO_Q.get("pihole") === "0") return null;
  const k = Math.floor((maintenant() - DEMO_DEBUT) / 4);
  const req = PIHOLE.requetes + k * 7, bl = PIHOLE.bloquees + k;
  return { bloquees: bl, requetes: req, pourcentage: Math.round((bl / req) * 1000) / 10, domaines_liste: 142387, maj: maintenant() };
}
function routeAppareil(mac, corps) {
  const a = APPAREILS.find((x) => x.mac === mac.toLowerCase());
  if (corps.oublier === true) {
    if (!a) return err(404, "appareil", "Cet appareil n'est pas (ou plus) connu.");
    if (a.moi) return err(400, "appareil", "Le Pi lui-même ne peut pas être oublié.");
    APPAREILS.splice(APPAREILS.indexOf(a), 1);
    return ok();
  }
  if (!("nom" in corps)) return err(400, "nom", "Indique « nom » (vide pour effacer) ou « oublier ».");
  if (corps.nom !== null && typeof corps.nom !== "string") return err(400, "nom", "Le nom doit être un texte.");
  const nom = String(corps.nom || "");
  if (/[\u0000-\u001f<>]/.test(nom)) return err(400, "nom", "Ce nom contient un caractère interdit.");
  const propre = nom.split(/\s+/).filter(Boolean).join(" ");
  if (propre.length > 40) return err(400, "nom", "Nom trop long : 40 caractères au plus.");
  if (!a) return err(404, "appareil", "Cet appareil n'est pas (ou plus) connu.");
  a.nom_perso = propre;
  return ok({ appareil: listeAppareils().find((x) => x.mac === a.mac) });
}
function lancerDebit() {
  if (DEBIT.en_cours) return err(409, "debit_en_cours", "Un test de débit est déjà en cours. Il dure moins d'une minute.");
  DEBIT.en_cours = true;
  setTimeout(() => {
    const r = { t: maintenant(), down_mbps: Math.round(alea(205, 275) * 10) / 10, up_mbps: Math.round(alea(52, 74) * 10) / 10, ping_ms: Math.round(alea(11, 17) * 10) / 10 };
    DEBITS.push(r);
    while (DEBITS.length > 30) DEBITS.shift();
    DEBIT.en_cours = false;
    notifier(`Test de débit : ↓ ${String(r.down_mbps).replace(".", ",")} Mbit/s · ↑ ${String(r.up_mbps).replace(".", ",")} Mbit/s · ${Math.round(r.ping_ms)} ms`, "ok");
    diffuser("surEtat", etat());
  }, 7000);
  return ok(reseauDemo().debit);
}

// --------------------------------------------------------------------------------------- tâches
function tache({ type, titre, cible = null, noeud }, etapes, fin) {
  const t = { id: id8(), type, titre, cible, noeud, etat: "en_cours", message: "", journal: [], complet: [], debut: maintenant(), fin: null };
  taches.unshift(t);
  let delai = 0;
  const publie = () => diffuser("surTache", vueTache(t));
  etapes.forEach(([ms, ligne]) => {
    delai += ms;
    setTimeout(() => { t.complet.push(ligne); t.journal = t.complet.slice(-3); publie(); }, delai);
  });
  setTimeout(() => {
    let message;
    try { message = fin(); t.etat = "ok"; } catch (e) { message = e.message; t.etat = "erreur"; }
    t.message = message;
    t.fin = maintenant();
    publie();
    diffuser("surEtat", etat());
  }, delai + 700);
  return t;
}
const vueTache = (t) => { const { complet, ...reste } = t; return reste; };
const occupe = (cible, noeud) => taches.some((t) => t.etat === "en_cours" && t.cible === cible && t.noeud === noeud);

// ----------------------------------------------------------------------------------------- apps
function valider(a, reglages, existants) {
  const sortie = { ...(existants || {}) };
  for (const r of a.reglages) {
    let v = reglages?.[r.cle];
    if (v === undefined || v === "••••••") v = sortie[r.cle];
    if (v === undefined || v === null) v = r.defaut !== undefined ? r.defaut : "";
    v = String(v);
    if (/['\n]/.test(v) || v.length > 256) return err(400, "reglages", `${r.nom} : caractère interdit ou valeur trop longue.`, { cle: r.cle });
    if (!v && r.type === "secret" && r.genere) v = id8() + id8();
    if (!v && r.requis) return err(400, "reglages", `${r.nom} : ce réglage est obligatoire.`, { cle: r.cle });
    if (v && r.type === "nombre" && !/^-?\d+$/.test(v)) return err(400, "reglages", `${r.nom} : un nombre est attendu.`, { cle: r.cle });
    if (v && r.type === "secret" && r.min && v.length < r.min) return err(400, "reglages", `${r.nom} : ${r.min} caractères au moins.`, { cle: r.cle });
    if (v && r.motif && !new RegExp(r.motif).test(v)) return err(400, "reglages", `${r.nom} : valeur refusée. ${r.aide || ""}`.trim(), { cle: r.cle });
    sortie[r.cle] = v;
  }
  return { reglages: sortie };
}

function actionApp(id, action, corps) {
  const a = app(id);
  if (!a) return err(404, "app_inconnue", "Cette application n'est pas au catalogue.");
  let noeud = corps.noeud;
  if (action === "installer" && !noeud) noeud = !horsLigne[a.noeud_conseille] ? a.noeud_conseille : "forge";
  if (!N[noeud]) return err(404, "noeud", "Ce nœud n'existe pas.");
  if (horsLigne[noeud]) return err(503, "hors_ligne", `${noeud.toUpperCase()} est hors ligne.`);
  if (occupe(id, noeud)) return err(409, "occupe", `Une opération est déjà en cours pour ${a.nom}.`);
  const i = inst[noeud][id];
  const lance = (titre, etapes, fin) => ok({ tache: vueTache(tache({ type: "app", titre, cible: id, noeud }, etapes, fin)), noeud });
  if (action === "installer") {
    if (i) return err(409, "deja_installee", `${a.nom} est déjà installée sur ${noeud.toUpperCase()}.`);
    const v = valider(a, corps.reglages);
    if (v.statut) return v;
    const libre = N[noeud].ram.total - N[noeud].ram.utilise;
    if (a.ram_mo * 2 ** 20 > libre) return err(409, "memoire", `Pas assez de mémoire libre sur ${noeud.toUpperCase()} pour ${a.nom}.`);
    return lance(`Installation de ${a.nom}`, [
      [300, `Téléchargement de ${a.nom}…`], [1100, ` ${a.image} Pulling`], [1300, ` ydz-${id} Pulled`], [500, "Démarrage…"], [500, ` Container ydz-${id}  Started`],
    ], () => {
      inst[noeud][id] = {
        etat: "actif", reglages: v.reglages, installe_le: maintenant(),
        donnees: corps.emplacement ? `${corps.emplacement}/apps/${id}` : `/var/lib/ydz/donnees/${id}`,
      };
      return `${a.nom} est installée.`;
    });
  }
  if (!i) return err(409, "non_installee", `${a.nom} n'est pas installée sur ${noeud.toUpperCase()}.`);
  switch (action) {
    case "demarrer": return lance(`Démarrage de ${a.nom}`, [[500, "Démarrage…"]], () => { i.etat = "actif"; return `${a.nom} est démarrée.`; });
    case "arreter": return lance(`Arrêt de ${a.nom}`, [[500, "Arrêt…"]], () => { i.etat = "arrete"; return `${a.nom} est arrêtée.`; });
    case "redemarrer": return lance(`Redémarrage de ${a.nom}`, [[400, "Arrêt…"], [800, "Démarrage…"]], () => { i.etat = "actif"; return `${a.nom} a redémarré.`; });
    case "mettre-a-jour": return lance(`Mise à jour de ${a.nom}`, [[400, "Recherche d'une nouvelle image…"], [1500, ` ydz-${id} Pulled`], [600, "Redémarrage…"]], () => { i.etat = "actif"; return `${a.nom} est à jour.`; });
    case "reglages": {
      const v = valider(a, corps.reglages, i.reglages);
      if (v.statut) return v;
      return lance(`Réglages de ${a.nom}`, [[400, "Enregistrement…"], [900, "Redémarrage…"]], () => { i.reglages = v.reglages; i.etat = "actif"; return `${a.nom} a pris ses nouveaux réglages.`; });
    }
    case "desinstaller": return lance(`Désinstallation de ${a.nom}`, [[500, "Arrêt…"], [900, " Container removed"]], () => {
      delete inst[noeud][id];
      return corps.supprimer_donnees ? `${a.nom} est désinstallée, données supprimées.` : `${a.nom} est désinstallée. Ses données sont gardées.`;
    });
    default: return err(404, "inconnu", "Action inconnue.");
  }
}

function journalApp(id, noeud) {
  const a = app(id);
  const h = (d) => new Date(Date.now() - d * 1000).toTimeString().slice(0, 8);
  const gabarits = {
    minecraft: ["[Server thread/INFO]: Starting minecraft server version 1.21.1", "[Server thread/INFO]: Loading NeoForge 21.1.90", "[Server thread/INFO]: Preparing level \"world\"", "[Worker-Main-2/INFO]: Preparing spawn area: 84%", "[Server thread/INFO]: Done (18.412s)! For help, type \"help\"", "[Server thread/INFO]: Justin joined the game", "[Server thread/INFO]: Justin has made the advancement [Stone Age]", "[Server thread/INFO]: Saving the game (this may take a moment!)", "[Server thread/INFO]: Saved the game"],
    pihole: ["FTL started!", "Imported 142 387 domains from gravity", "query[A] ads.example.net from 192.168.1.35", "gravity blocked ads.example.net is 0.0.0.0", "query[AAAA] forge.local from 192.168.1.20", "forwarded forge.local to 9.9.9.9"],
  }[id] || ["Démarrage du service", "Configuration chargée", `Écoute sur le port ${a.ports[0]?.port || 80}`, "Prêt", "Requête traitée en 12 ms", "Sauvegarde automatique terminée"];
  const lignes = [];
  for (let k = 0; k < 40; k++) lignes.push(`${id}  | [${h((40 - k) * 37)}] ${gabarits[k % gabarits.length]}`);
  return lu({ id, lignes, ok: true, noeud });
}

// ------------------------------------------------------------------------------------- stockage
function stockage(noeud) {
  const s = D.stockage[noeud];
  if (noeud === "vault") {
    const vides = s.disques.filter((d) => d.vide && d.formatable && !d.systeme);
    s.suggestion = vides.length >= 2 && !s.miroirs.length
      ? { type: "miroir", disques: vides.slice(0, 2).map((d) => d.chemin), texte: "Deux disques vides de même taille : un miroir protégerait tes fichiers d'une panne." }
      : vides.length ? { type: "formater", disques: [vides[0].chemin], texte: "Un disque vide est prêt à être préparé pour YDZ." } : null;
  }
  return s;
}
function preparer(corps, miroir) {
  const noeud = corps.noeud || "vault";
  const s = D.stockage[noeud];
  if (!s) return err(404, "noeud", "Ce nœud n'existe pas.");
  const chemins = miroir ? corps.disques || [] : [corps.disque];
  const disques = chemins.map((c) => s.disques.find((d) => d.chemin === c));
  if (disques.some((d) => !d) || (miroir && disques.length !== 2)) return err(400, "disque", "Disque introuvable.");
  if (disques.some((d) => d.systeme)) return err(403, "disque_protege", "C'est le disque du système : il ne peut pas être effacé.");
  const nom = String(corps.nom || "");
  if (!/^[a-z0-9]{1,16}$/.test(nom)) return err(400, "nom", "Le nom doit faire 1 à 16 lettres minuscules ou chiffres, sans espace.");
  if (s.disques.some((d) => d.nom === nom && !disques.includes(d))) return err(409, "nom", `Le nom « ${nom} » est déjà pris par un autre disque.`);
  const perdues = disques.some((d) => !d.vide);
  const p = {
    jeton: id8() + id8(), phrase: `EFFACER ${disques.map((d) => d.id.toUpperCase()).join(" ")}`, expire_s: 120, nom, miroir,
    montage: `/srv/ydz/${nom}`, disques: disques.map((d) => ({ chemin: d.chemin, modele: d.modele, serie: d.serie, taille: d.taille })),
    donnees_perdues: perdues,
    avertissement: `TOUT le contenu de ${chemins.join(" et ")} sera effacé définitivement${perdues ? " (des données existent dessus)" : ""}.`,
    noeud,
  };
  jetons[p.jeton] = { p, limite: Date.now() + 120000 };
  return lu(p);
}
function confirmer(corps) {
  const j = jetons[corps.jeton];
  delete jetons[corps.jeton];
  if (!j || Date.now() > j.limite) return err(410, "jeton", "La confirmation a expiré. Recommence la préparation.");
  if (corps.phrase !== j.p.phrase) return err(400, "phrase", "La phrase ne correspond pas. Rien n'a été effacé.");
  const { p } = j;
  const s = D.stockage[p.noeud];
  const noms = p.disques.map((d) => d.chemin).join(" et ");
  const t = tache({ type: "stockage", titre: p.miroir ? `Création du miroir « ${p.nom} »` : `Préparation de ${noms}`, cible: p.nom, noeud: p.noeud }, [
    [400, "Table de partitions GPT…"], [1200, p.miroir ? "Assemblage du miroir (RAID 1)…" : "Partition créée"], [1500, "Formatage ext4…"], [900, `Montage dans ${p.montage}`],
  ], () => {
    p.disques.forEach((pd) => {
      const d = s.disques.find((x) => x.chemin === pd.chemin);
      s.partages = s.partages.filter((x) => x.disque !== d.nom);
      Object.assign(d, {
        montage: p.montage, nom: p.nom, vide: false, miroir: p.miroir, a_remonter: null,
        total: Math.round(d.taille * 0.983), libre: Math.round(d.taille * 0.983),
        partitions: [{ chemin: `${d.chemin}1`, type: "part", taille: d.taille - 1048576, fs: p.miroir ? "linux_raid_member" : "ext4", etiquette: `ydz-${p.nom}`, uuid: id8(), montage: [p.montage] }],
      });
    });
    if (p.miroir) s.miroirs.push({ nom: "md127", niveau: "raid1", actif: true, membres: p.disques.map((d) => `${d.chemin.slice(5)}1`), etat: "reconstruction", progression: 1.2 });
    return p.miroir ? `Le miroir « ${p.nom} » est prêt. La synchronisation continue en fond.` : `Le disque « ${p.nom} » est prêt.`;
  });
  return ok({ tache: vueTache(t), noeud: p.noeud });
}

// ---------------------------------------------------------------------------------- alimentation
function couper(nom, action) {
  setTimeout(() => { horsLigne[nom] = true; N[nom].etat = "halt"; diffuser("surEtat", etat()); }, 2000);
  setTimeout(() => {
    delete horsLigne[nom];
    allumage[nom] = maintenant();
    N[nom].etat = "ok";
    const m = D.maj.noeuds.find((x) => x.noeud === nom);
    if (m) m.redemarrage_requis = false;
    notifier(action === "eteindre" ? `Démonstration : ${nom.toUpperCase()} est rallumé pour la suite de la visite.` : `${nom.toUpperCase()} a redémarré.`);
    diffuser("surEtat", etat());
  }, action === "eteindre" ? 20000 : 11000);
}

// ---------------------------------------------------------------------------------------- routes
const PAQUETS = [["libssl3t64", "3.5.4-1~deb13u1"], ["openssl", "3.5.4-1~deb13u1"], ["linux-image-rpi-2712", "1:6.12.47-1+rpt1"], ["raspi-firmware", "1:1.20251028-1"], ["curl", "8.14.1-2+deb13u2"], ["libcurl4t64", "8.14.1-2+deb13u2"], ["tzdata", "2025b-4+deb13u1"]];

function router(methode, chemin, corps) {
  const [voie, requete = ""] = chemin.split("?");
  const q = new URLSearchParams(requete);
  const p = voie.replace(/^\/api\//, "").split("/");
  const G = methode === "GET", P = methode === "POST";
  const noeudStockage = () => corps.noeud || q.get("noeud") || "vault";

  if (G && voie === "/api/etat") return lu(etat());
  if (G && voie === "/api/ping") return lu({ ydz: 1, nom: "forge", role: "forge", hub: true, version: D.etat.version });
  if (G && voie === "/api/noeuds") return lu({ noeuds: etat().noeuds });
  if (G && voie === "/api/systeme") return lu(D.systeme);
  if (G && voie === "/api/taches") return lu({ taches: taches.map(vueTache) });
  if (G && p[0] === "taches" && p[1]) {
    const t = taches.find((x) => x.id === p[1]);
    return t ? lu({ tache: { ...vueTache(t), journal: t.complet }, noeud: t.noeud }) : err(404, "tache", "Cette tâche n'existe plus.");
  }
  if (G && voie === "/api/diagnostic") {
    const n = q.get("noeud") || "forge";
    if (horsLigne[n]) return err(503, "hors_ligne", `${n.toUpperCase()} est hors ligne.`);
    return D.diagnostic[n] ? lu(D.diagnostic[n]) : err(404, "noeud", "Ce nœud n'existe pas.");
  }

  // Authentification : la démonstration se comporte comme l'écran de la tour (pas de code demandé).
  if (G && voie === "/api/auth") return lu({ pin_defini: true, local: true, connecte: true, attente_s: 0 });
  if (P && voie === "/api/auth/connexion") return ok({ jeton: "demo", expire_s: 43200 });
  if (P && voie === "/api/auth/deconnexion") return ok();
  if (P && voie === "/api/auth/pin") {
    const pin = String(corps.pin || "");
    if (!/^\d{4,8}$/.test(pin)) return err(400, "pin_invalide", "Le code doit faire 4 à 8 chiffres.");
    if (/^(\d)\1+$/.test(pin) || "0123456789876543210".includes(pin)) return err(400, "pin_invalide", "Ce code est trop simple. Choisis-en un autre.");
    return ok();
  }

  // Ventilateur
  if (G && voie === "/api/ventilo") return lu(ventilo);
  if (P && voie === "/api/ventilo") {
    const m = ventilo.modes.find((x) => x.id === corps.mode);
    if (!m) return err(400, "mode", "Mode inconnu.");
    Object.assign(ventilo, { mode: m.id, mode_nom: m.nom, courbe: m.courbe });
    tic();
    return ok({ ventilo });
  }
  if (P && voie === "/api/ventilo/test") { testVentiloFin = maintenant() + (corps.secondes || 5); tic(); return ok(); }

  // Applications
  if (G && voie === "/api/apps") return lu({ catalogue: CATALOGUE.map((a) => ({ ...a, installations: installations(a, false) })), noeuds: noeudsApps(), erreurs: [] });
  if (p[0] === "apps" && p[1]) {
    const a = app(p[1]);
    if (!a) return err(404, "app_inconnue", "Cette application n'est pas au catalogue.");
    if (G && !p[2]) return lu({ ...a, installations: installations(a, true), noeuds: noeudsApps() });
    if (G && p[2] === "journal") return journalApp(a.id, q.get("noeud"));
    if (P) return actionApp(a.id, p[2], corps);
  }

  // Stockage
  if (G && voie === "/api/stockage") {
    const n = noeudStockage();
    if (horsLigne[n]) return err(503, "hors_ligne", `${n.toUpperCase()} est hors ligne.`);
    return D.stockage[n] ? lu(stockage(n)) : err(404, "noeud", "Ce nœud n'existe pas.");
  }
  if (P && voie === "/api/stockage/formater/preparer") return preparer(corps, false);
  if (P && voie === "/api/stockage/miroir/preparer") return preparer(corps, true);
  if (P && voie === "/api/stockage/confirmer") return confirmer(corps);
  if (P && voie === "/api/stockage/remonter") {
    const s = D.stockage[noeudStockage()];
    const d = s.disques.find((x) => x.chemin === corps.disque);
    if (!d || !d.a_remonter) return err(409, "disque", "Ce disque n'a pas été préparé par YDZ : rien à remonter.");
    const nom = d.a_remonter;
    Object.assign(d, { nom, montage: `/srv/ydz/${nom}`, a_remonter: null, total: Math.round(d.taille * 0.983), libre: Math.round(d.taille * 0.41) });
    d.partitions[0].montage = [d.montage];
    return ok({ nom, montage: d.montage });
  }
  if (P && voie === "/api/stockage/samba/mot-de-passe") {
    if (String(corps.mot_de_passe || "").length < 8) return err(400, "mot_de_passe", "Le mot de passe doit faire 8 caractères au moins.");
    D.stockage[noeudStockage()].samba.mot_de_passe_defini = true;
    return ok();
  }
  if (P && voie === "/api/stockage/partages") {
    const n = noeudStockage(), s = D.stockage[n];
    const nom = String(corps.nom || "");
    if (!/^[a-z0-9][a-z0-9_-]{0,30}$/.test(nom)) return err(400, "nom", "Nom de partage refusé : lettres minuscules, chiffres et tirets seulement.");
    if (s.partages.some((x) => x.nom === nom)) return err(409, "nom", `Le partage « ${nom} » existe déjà.`);
    if (!s.disques.some((d) => d.nom === corps.disque && d.montage)) return err(400, "disque", "Choisis un disque préparé et monté.");
    if (!s.acces.some((a) => a.id === corps.acces)) return err(400, "acces", "Type d'accès inconnu.");
    if (corps.acces === "prive" && !s.samba.mot_de_passe_defini) return err(409, "mot_de_passe_requis", "Choisis d'abord le mot de passe des partages.");
    const partage = { nom, disque: corps.disque, chemin: `/srv/ydz/${corps.disque}/partages/${nom}`, acces: corps.acces, adresse: `\\\\${n}\\${nom}`, adresse_mac: `smb://${n}.local/${nom}` };
    s.partages.push(partage);
    return ok({ partage });
  }
  if (P && voie === "/api/stockage/partages/supprimer") {
    const s = D.stockage[noeudStockage()];
    if (!s.partages.some((x) => x.nom === corps.nom)) return err(404, "partage", "Ce partage n'existe pas.");
    s.partages = s.partages.filter((x) => x.nom !== corps.nom);
    return ok();
  }

  // Wake-on-LAN
  if (G && voie === "/api/wol") return lu(D.wol);
  if (P && voie === "/api/wol") {
    if (!/^([0-9a-f]{2}[:-]){5}[0-9a-f]{2}$/i.test(corps.mac || "")) return err(400, "mac", "Adresse MAC invalide. Exemple : 20:0B:74:6A:0B:6C.");
    if (!String(corps.nom || "").trim()) return err(400, "nom", "Donne un nom à cette machine.");
    const cible = { id: `m${D.wol.cibles.length}`, nom: corps.nom.trim(), mac: corps.mac.toUpperCase(), diffusion: corps.diffusion || "192.168.1.255", ip: corps.ip || null, fixe: false, en_ligne: corps.ip ? false : null };
    D.wol.cibles.push(cible);
    return ok({ cible });
  }
  if (P && p[0] === "wol" && p[2]) {
    const c = D.wol.cibles.find((x) => x.id === p[1]);
    if (!c) return err(404, "cible", "Cette machine n'est pas enregistrée.");
    if (p[2] === "reveiller") {
      if (c.en_ligne === false) setTimeout(() => { c.en_ligne = true; notifier(`${c.nom} est en ligne.`); }, 6000);
      return ok({ message: `Signal de réveil envoyé à ${c.nom}.` });
    }
    if (p[2] === "supprimer") {
      if (c.fixe) return err(403, "cible", "Cette machine se règle dans ydz.conf (clés wol_*).");
      D.wol.cibles = D.wol.cibles.filter((x) => x !== c);
      return ok();
    }
  }

  // Réseau de la maison
  if (G && voie === "/api/appareils") return lu({ appareils: listeAppareils(), maj: DEMO_DEBUT, nouveaux: NOUVEAUX });
  if (P && p[0] === "appareils" && /^[0-9a-f:]{17}$/i.test(p[1] || "")) return routeAppareil(p[1], corps);
  if (G && voie === "/api/reseau") return lu({ reseau_maison: reseauDemo(), pihole: piholeDemo() });
  if (P && voie === "/api/reseau/debit") return lancerDebit();

  // Mises à jour
  if (G && voie === "/api/maj") return lu({ noeuds: D.maj.noeuds.map((m) => (horsLigne[m.noeud] ? { noeud: m.noeud, erreur: "hors ligne" } : m)) });
  if (P && (voie === "/api/maj/verifier" || voie === "/api/maj/appliquer")) {
    const cibles = (corps.noeuds || ORDRE).filter((n) => !horsLigne[n]);
    const nombre = { forge: 7, vault: 3, pulse: 0 };
    if (voie.endsWith("verifier")) {
      return ok({ noeuds: cibles.map((n) => ({
        noeud: n, ok: true,
        tache: vueTache(tache({ type: "maj", titre: "Recherche de mises à jour", noeud: n }, [[600, "Lecture des listes de paquets…"]], () => {
          const m = D.maj.noeuds.find((x) => x.noeud === n);
          m.paquets = m.fait ? 0 : nombre[n];
          m.liste = PAQUETS.slice(0, m.paquets).map(([paquet, version]) => ({ paquet, version }));
          m.derniere_verif = maintenant();
          return m.paquets ? `${m.paquets} mises à jour disponibles sur ${n.toUpperCase()}.` : `${n.toUpperCase()} est à jour.`;
        })),
      })) });
    }
    cibles.forEach((n, k) => {
      const m = D.maj.noeuds.find((x) => x.noeud === n);
      m.en_cours = true;
      m.journal = ["Lecture des listes de paquets…"];
      const lignes = (m.liste.length ? m.liste : [{ paquet: "base-files", version: "13.8" }]).map((x) => `Paramétrage de ${x.paquet} (${x.version}) …`);
      lignes.forEach((l, i) => setTimeout(() => m.journal.push(l), 800 * (i + 1)));
      setTimeout(() => {
        Object.assign(m, { en_cours: false, fait: true, redemarrage_requis: m.liste.some((x) => x.paquet.startsWith("linux-image")), paquets: 0, liste: [], derniere_maj: maintenant(), derniere_verif: maintenant() });
        m.journal.push("Mise à jour terminée.");
        notifier(`${n.toUpperCase()} est à jour.`);
      }, 800 * (lignes.length + 1) + k * 300);
    });
    return ok({ noeuds: cibles.map((n) => ({ noeud: n, ok: true })) });
  }

  // Écran et badges
  if (G && voie === "/api/ecran") return lu(ecran);
  if (P && voie === "/api/ecran/activite") return ok({ reveil: false });
  if (P && voie === "/api/affichage") {
    for (const k of Object.keys(DEMO_REG)) if (corps[k] !== undefined) DEMO_REG[k] = typeof corps[k] === "string" ? corps[k].trim() : corps[k];
    return ok(affichageDemo(etat().noeuds));
  }
  if (P && voie === "/api/ecran") {
    const avant = ecran.rotation;
    if (corps.luminosite !== undefined) {
      if (!(corps.luminosite >= 5 && corps.luminosite <= 100)) return err(400, "luminosite", "La luminosité va de 5 à 100.");
      ecran.luminosite = Math.round(corps.luminosite);
    }
    if (corps.veille_min !== undefined) ecran.veille_min = corps.veille_min;
    if (corps.rotation !== undefined) {
      if (!ecran.rotations.includes(corps.rotation)) return err(400, "rotation", "Rotation inconnue.");
      ecran.rotation = corps.rotation;
    }
    return ok({ redemarrage_kiosque: avant !== ecran.rotation, ecran });
  }
  if (P && voie === "/api/badges") {
    const cibles = (corps.noeud ? [corps.noeud] : ORDRE).filter((n) => !horsLigne[n]);
    cibles.forEach((n) => {
      const b = N[n].badge;
      if (corps.luminosite !== undefined) b.luminosite = corps.luminosite;
      if (corps.accent) b.accent = corps.accent;
      if (corps.retourne !== undefined) b.retourne = corps.retourne;
    });
    return ok({ noeuds: cibles.map((n) => ({ noeud: n, ok: true, badge: N[n].badge })) });
  }

  // Alimentation
  if (P && p[0] === "noeuds" && N[p[1]] && ["redemarrer", "eteindre"].includes(p[2])) {
    if (horsLigne[p[1]]) return err(503, "hors_ligne", `${p[1].toUpperCase()} est hors ligne.`);
    couper(p[1], p[2]);
    notifier(`${p[1].toUpperCase()} : ${p[2] === "eteindre" ? "extinction" : "redémarrage"} en cours`);
    return ok({ noeud: p[1], action: p[2], delai_s: 2 });
  }
  if (P && p[0] === "tour" && ["redemarrer", "eteindre"].includes(p[1])) {
    arretTour = true;
    const liste = ["vault", "pulse", "forge"].filter((n) => !horsLigne[n]);
    liste.forEach((n) => couper(n, p[1]));
    setTimeout(() => { arretTour = false; }, p[1] === "eteindre" ? 20500 : 11500);
    return ok({ action: p[1], noeuds: liste.map((n) => ({ noeud: n, ok: true })) });
  }

  return err(404, "inconnu", "Route inconnue.");
}

export function requete(methode, chemin, corps) {
  return new Promise((resoudre) => {
    setTimeout(() => {
      let r;
      try { r = router(methode, chemin, corps || {}); } catch (e) { r = err(500, "interne", `Erreur de la démonstration : ${e.message}`); }
      resoudre(clone(r));
    }, alea(90, 220));
  });
}

export function abonner(cibles) {
  abonnes.add(cibles);
  const envoyer = () => cibles.surEtat && cibles.surEtat(clone(etat()));
  const debut = setTimeout(envoyer, 0);
  const rythme = setInterval(envoyer, 2000);
  return () => { abonnes.delete(cibles); clearTimeout(debut); clearInterval(rythme); };
}
