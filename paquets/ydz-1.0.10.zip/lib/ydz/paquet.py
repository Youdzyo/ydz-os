"""Paquets de mise à jour YDZ (.zip) déposés depuis l'interface (Réglages > Mises à jour).

Format d'un paquet :
  YDZ-PAQUET.json   obligatoire : {"nom": "...", "description": "...", "version": "1.0.1" (facultatif)}
  ui/... lib/... bin/... apps/... (même arborescence que /opt/ydz) : fichiers copiés tels quels
  apres.sh          facultatif : script lancé en root après la copie, hors du bac à sable du démon

Sécurité : la route exige le code PIN (accès « action »). Chemins absolus, « .. », liens et
dossiers hors liste sont refusés. Chaque fichier remplacé est d'abord sauvegardé dans
/var/lib/ydz/sauvegardes/<horodatage>/ ; « ydz paquet annuler » n'existe pas encore, mais la
sauvegarde permet de revenir en arrière à la main (cp -a).
"""
import io
import json
import os
import shutil
import subprocess
import threading
import time
import zipfile

TAILLE_MAX = 40 * 1024 * 1024
DOSSIERS = ("ui", "lib", "bin", "apps", "kiosk", "plymouth", "outils", "systemd", "installer", "presets", "payload")
FICHIERS_RACINE = ("VERSION", "YDZ-PAQUET.json", "apres.sh")
SAUVEGARDES = "/var/lib/ydz/sauvegardes"
JOURNAL = "/var/log/ydz/paquets.log"


class ErreurPaquet(Exception):
    pass


def _journal(texte):
    try:
        os.makedirs(os.path.dirname(JOURNAL), exist_ok=True)
        with open(JOURNAL, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + texte.rstrip() + "\n")
    except OSError:
        pass


def _chemin_sur(nom):
    """Renvoie le chemin relatif nettoyé, ou None si le membre doit être refusé."""
    nom = nom.replace("\\", "/")
    if nom.startswith("/") or ":" in nom.split("/")[0]:
        return None
    parts = [p for p in nom.split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts):
        return None
    if len(parts) == 1:
        return parts[0] if parts[0] in FICHIERS_RACINE else None
    return "/".join(parts) if parts[0] in DOSSIERS else None


def lire(brut):
    """Vérifie le zip et renvoie (infos, [(chemin_relatif, octets, executable)], script_apres)."""
    if not brut:
        raise ErreurPaquet("Fichier vide.")
    if len(brut) > TAILLE_MAX:
        raise ErreurPaquet("Paquet trop gros (40 Mo au maximum).")
    try:
        z = zipfile.ZipFile(io.BytesIO(brut))
    except zipfile.BadZipFile:
        raise ErreurPaquet("Ce fichier n'est pas un .zip valide.")
    noms = [i for i in z.infolist() if not i.is_dir()]
    # un zip créé depuis un dossier « paquet/ » : on retire ce dossier commun
    prefixe = ""
    tetes = {i.filename.replace("\\", "/").split("/")[0] for i in noms}
    if len(tetes) == 1 and not any(i.filename.replace("\\", "/").count("/") == 0 for i in noms):
        prefixe = tetes.pop() + "/"
    fichiers, infos, apres, total = [], None, None, 0
    for i in noms:
        nom = i.filename.replace("\\", "/")
        if prefixe and nom.startswith(prefixe):
            nom = nom[len(prefixe):]
        if (i.external_attr >> 16) & 0o170000 == 0o120000:
            raise ErreurPaquet("Lien symbolique refusé : %s" % nom)
        rel = _chemin_sur(nom)
        if rel is None:
            raise ErreurPaquet("Chemin refusé dans le paquet : %s" % nom)
        total += i.file_size
        if total > 4 * TAILLE_MAX:
            raise ErreurPaquet("Paquet trop gros une fois décompressé.")
        data = z.read(i)
        if rel == "YDZ-PAQUET.json":
            try:
                infos = json.loads(data.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                raise ErreurPaquet("YDZ-PAQUET.json illisible.")
            if not isinstance(infos, dict) or not isinstance(infos.get("nom"), str):
                raise ErreurPaquet("YDZ-PAQUET.json doit contenir au moins « nom ».")
            continue
        if rel == "apres.sh":
            apres = data
            continue
        exe = bool((i.external_attr >> 16) & 0o111) or rel.startswith(("bin/", "kiosk/", "outils/", "installer/")) or rel.endswith(".sh")
        fichiers.append((rel, data, exe))
    if infos is None:
        raise ErreurPaquet("Ce n'est pas un paquet YDZ (YDZ-PAQUET.json manquant).")
    if not fichiers and apres is None:
        raise ErreurPaquet("Le paquet ne contient rien à installer.")
    return infos, fichiers, apres


def installer(base, brut, redemarrer_demon):
    """Copie les fichiers dans base (/opt/ydz), sauvegarde l'ancien, lance apres.sh. Renvoie un résumé."""
    infos, fichiers, apres = lire(brut)
    horo = time.strftime("%Y%m%d-%H%M%S")
    sauve = os.path.join(SAUVEGARDES, horo)
    os.makedirs(sauve, exist_ok=True)
    remplaces, nouveaux = 0, 0
    for rel, data, exe in fichiers:
        cible = os.path.join(base, rel)
        if os.path.isfile(cible):
            dest = os.path.join(sauve, rel)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(cible, dest)
            remplaces += 1
        else:
            nouveaux += 1
        os.makedirs(os.path.dirname(cible), exist_ok=True)
        tmp = cible + ".ydz-tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.chmod(tmp, 0o755 if exe else 0o644)
        os.replace(tmp, cible)
    _journal("paquet « %s » : %d fichier(s) remplacé(s), %d nouveau(x), sauvegarde %s"
             % (infos.get("nom"), remplaces, nouveaux, sauve))
    script = None
    if apres is not None:
        script = os.path.join(sauve, "apres.sh")
        with open(script, "wb") as f:
            f.write(apres)
        os.chmod(script, 0o700)
    touche_demon = any(rel.startswith(("lib/", "bin/")) for rel, _, _ in fichiers)

    if script:
        # apres.sh tourne dans une unité systemd DÉTACHÉE (--no-block) : ni la fin de la requête, ni
        # un redémarrage de ydzd ne peuvent le couper. Sa sortie va dans le journal des paquets, et
        # c'est lui qui redémarre ydzd à la fin si le paquet a changé le démon.
        enveloppe = ('bash "$1"; c=$?; echo "$(date "+%Y-%m-%d %H:%M:%S") apres.sh : fin (code $c)"; '
                     '[ "$2" = 1 ] && systemctl restart ydzd; exit $c')
        cmd = ["systemd-run", "--quiet", "--collect", "--no-block",
               "--unit=ydz-paquet-" + horo,
               "--property=StandardOutput=append:" + JOURNAL,
               "--property=StandardError=append:" + JOURNAL,
               "/bin/bash", "-c", enveloppe, "ydz-paquet", script, "1" if touche_demon else "0"]
        _journal("apres.sh : lancé en tâche de fond (unité ydz-paquet-%s)" % horo)
        try:
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
        except (OSError, subprocess.TimeoutExpired) as ex:
            _journal("apres.sh : lancement impossible %r" % ex)
    elif touche_demon:
        def suite():
            time.sleep(1.5)
            redemarrer_demon()
        threading.Thread(target=suite, daemon=True).start()
    return {
        "ok": True,
        "nom": infos.get("nom"),
        "description": infos.get("description", ""),
        "fichiers": len(fichiers),
        "remplaces": remplaces,
        "nouveaux": nouveaux,
        "script": bool(script),
        "redemarrage_demon": touche_demon,
        "sauvegarde": sauve,
    }
