#!/bin/bash
# YDZ 1.0.10 : réseau de la maison. ydzd est redémarré à la fin par le paquet.
echo "== 1.0.10 : réseau de la maison ($(date '+%H:%M:%S'))"
# iw lit la qualité du Wi-Fi du Pi (sans lui, YDZ se rabat sur /proc/net/wireless)
if ! command -v iw >/dev/null; then
    apt-get -o Acquire::ForceIPv4=true -o Acquire::Retries=10 install -y --no-install-recommends iw \
        && echo "iw installé" || echo "iw indisponible : signal Wi-Fi lu dans /proc/net/wireless"
fi
# avahi-resolve (facultatif) donne un nom aux appareils que la box ne nomme pas
command -v avahi-resolve >/dev/null && echo "avahi-resolve présent" || echo "avahi-resolve absent : noms par la box seulement"
# recharge l'écran une fois ydzd redémarré (nouvelle page « réseau »)
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.10 terminé"
