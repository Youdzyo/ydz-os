#!/bin/bash
# YDZ OS 1.0.16 « Espace visiteurs ». ydzd est redémarré à la fin par le paquet (lib/ et bin/ ont changé).
# Idempotent et jamais fatal : chaque étape protège son échec.
echo "== 1.0.16 : espace visiteurs ($(date '+%H:%M:%S'))"

# 1. Le binaire du serveur visiteur doit être exécutable.
chmod 755 /opt/ydz/bin/ydz-visiteur 2>/dev/null || true

# 2. Dossier public (sens unique ydzd -> visiteur) : /run/ydz/public, 0755, données publiques seulement.
#    ydzd le (re)crée et le remplit au démarrage ; on le prépare ici pour éviter une fenêtre vide.
install -d -m 0755 /run/ydz/public 2>/dev/null || echo "/run/ydz/public : création différée au démarrage de ydzd"

# 3. Unité systemd du serveur visiteur : copiée depuis le paquet. Laissée ARRÊTÉE et DÉSACTIVÉE :
#    l'espace visiteurs est coupé par défaut, c'est ydzd qui démarre le service quand Justin l'active.
if [ -f /opt/ydz/systemd/ydz-visiteur.service ]; then
    install -m 0644 /opt/ydz/systemd/ydz-visiteur.service /etc/systemd/system/ydz-visiteur.service 2>/dev/null \
        && echo "unité ydz-visiteur.service installée (arrêtée, désactivée)" \
        || echo "unité ydz-visiteur.service non copiée (ignorée)"
    systemctl daemon-reload 2>/dev/null || true
    # on s'assure qu'elle ne démarre pas toute seule tant que Justin ne l'a pas demandé
    systemctl disable ydz-visiteur.service 2>/dev/null || true
    systemctl stop ydz-visiteur.service 2>/dev/null || true
else
    echo "ydz-visiteur.service absent du paquet (ignoré)"
fi

# 4. Rechargement systemd global.
systemctl daemon-reload 2>/dev/null || true

# 5. L'écran HDMI se recharge une fois ydzd revenu (le reste de l'interface est inchangé).
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.16 terminé"
