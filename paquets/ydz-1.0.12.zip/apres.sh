#!/bin/bash
# YDZ 1.0.12 : apps et accès. ydzd est redémarré à la fin par le paquet ; s'il était activé, l'accès HTTPS
# (tailscale serve) est réappliqué par ydzd lui-même au démarrage.
echo "== 1.0.12 : apps et accès ($(date '+%H:%M:%S'))"
# journal d'activité (/var/log/ydz/activite.jsonl) : lisible par root seulement (il contient des adresses IP)
install -d -m 750 /var/log/ydz
[ -f /var/log/ydz/activite.jsonl ] && chmod 640 /var/log/ydz/activite.jsonl
# kiosque : nouveau script (curseur invisible, pas de traduction Google). labwc doit redémarrer pour lire le
# thème de curseurs : on relance ydz-kiosk (donc labwc) une fois ydzd revenu.
chmod 755 /opt/ydz/kiosk/ydz-kiosk 2>/dev/null || true
if command -v tailscale >/dev/null; then
    echo "Tailscale présent : Réglages > Accès à distance pour activer les adresses HTTPS"
else
    echo "Tailscale absent : les adresses HTTPS resteront indisponibles"
fi
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.12 terminé"
