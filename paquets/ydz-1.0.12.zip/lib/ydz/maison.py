"""Écran du Pi (1.0.9) : réglages d'affichage, nuit, météo, état du PC, des services et conso électrique.

Tout ce qui touche au réseau (météo, contrôle des services, ping du PC) tourne dans un fil à part,
seulement sur le vrai système : la simulation et les tests n'envoient rien dehors.
La nuit, le hub écrit l'état voulu (« jour », « horloge » ou « eteint ») dans FICHIER_NUIT ; le kiosque
le lit et éteint la sortie HDMI quand il faut (l'interface, elle, dessine l'horloge de nuit).
"""
import re
import threading
import time

from .core import ApiError

FICHIER_NUIT = "/run/ydz/ecran-nuit"
RE_HEURE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")

DEFAUTS = {
    "nuit_actif": True, "nuit_debut": "00:00", "nuit_fin": "07:00", "nuit_mode": "eteint",
    "rotation_s": 30, "meteo_ville": "Toulouse", "meteo_lat": 43.6047, "meteo_lon": 1.4442,
    "prix_kwh": 0.194,
}

# codes météo WMO (Open-Meteo) -> (texte, icône)
METEO = {
    0: ("Ciel dégagé", "sun"), 1: ("Plutôt dégagé", "sun"), 2: ("Partiellement nuageux", "cloud-sun"),
    3: ("Couvert", "cloud"), 45: ("Brouillard", "cloud-fog"), 48: ("Brouillard givrant", "cloud-fog"),
    51: ("Bruine légère", "cloud-drizzle"), 53: ("Bruine", "cloud-drizzle"), 55: ("Forte bruine", "cloud-drizzle"),
    56: ("Bruine verglaçante", "cloud-drizzle"), 57: ("Bruine verglaçante", "cloud-drizzle"),
    61: ("Pluie faible", "cloud-rain"), 63: ("Pluie", "cloud-rain"), 65: ("Forte pluie", "cloud-rain"),
    66: ("Pluie verglaçante", "cloud-rain"), 67: ("Pluie verglaçante", "cloud-rain"),
    71: ("Neige faible", "cloud-snow"), 73: ("Neige", "cloud-snow"), 75: ("Forte neige", "cloud-snow"),
    77: ("Grains de neige", "cloud-snow"), 80: ("Averses", "cloud-rain"), 81: ("Averses", "cloud-rain"),
    82: ("Fortes averses", "cloud-rain"), 85: ("Averses de neige", "cloud-snow"), 86: ("Averses de neige", "cloud-snow"),
    95: ("Orage", "cloud-lightning"), 96: ("Orage et grêle", "cloud-lightning"), 99: ("Orage et grêle", "cloud-lightning"),
}


def meteo_texte(code, jour=True):
    txt, ico = METEO.get(int(code) if code is not None else -1, ("—", "cloud"))
    if not jour and ico in ("sun", "cloud-sun"):
        ico = "moon" if ico == "sun" else "cloud-moon"
    return txt, ico


def minutes(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def dans_plage(maintenant_min, debut, fin):
    """Vrai si l'heure (en minutes) est dans [debut, fin[, plage pouvant passer minuit."""
    d, f = minutes(debut), minutes(fin)
    if d == f:
        return False
    return d <= maintenant_min < f if d < f else (maintenant_min >= d or maintenant_min < f)


def lire_pmic(texte):
    """Sortie de `vcgencmd pmic_read_adc` -> puissance du Pi en watts (somme courant x tension par rail)."""
    courants, tensions = {}, {}
    for l in (texte or "").splitlines():
        m = re.match(r"\s*(\S+)_([AV])\s+\S+=([\d.]+)([AV])", l)
        if not m:
            continue
        (courants if m.group(2) == "A" else tensions)[m.group(1)] = float(m.group(3))
    w = sum(courants[k] * tensions[k] for k in courants if k in tensions)
    return round(w, 2) if w > 0 else None


def estimer_watts(noeud):
    """Estimation quand la mesure n'existe pas : Pi 5 ≈ 3 W au repos, ≈ 8 W à fond, + disques."""
    cpu = noeud.get("cpu") or 0
    disques = max(0, len(noeud.get("disques") or []) - 1)
    return round(3.0 + 5.0 * cpu / 100.0 + 1.5 * disques, 1)


class Maison:
    def __init__(self, hub):
        self.hub = hub
        self.sys = hub.sys
        self.state = hub.node.state
        self.reel = type(self.sys).__name__ == "System"
        self.stop = threading.Event()
        self.meteo = None
        self.services = None
        self.pc = None                     # {"nom", "en_ligne", "depuis"}
        self.watts_hub = None
        self._nuit_ecrite = None

    # --- réglages ------------------------------------------------------------------------
    def reglages(self):
        r = dict(DEFAUTS)
        r.update(self.state.get("affichage", {}) or {})
        return r

    def regler(self, b):
        r = self.reglages()
        if "nuit_actif" in b:
            if not isinstance(b["nuit_actif"], bool):
                raise ApiError(400, "Champ « nuit_actif » invalide.", "nuit_actif")
            r["nuit_actif"] = b["nuit_actif"]
        for k in ("nuit_debut", "nuit_fin"):
            if k in b:
                if not isinstance(b[k], str) or not RE_HEURE.match(b[k]):
                    raise ApiError(400, "Heure invalide (forme attendue : 07:30).", k)
                r[k] = b[k]
        if "nuit_mode" in b:
            if b["nuit_mode"] not in ("eteint", "horloge"):
                raise ApiError(400, "La nuit, l'écran peut être « eteint » ou « horloge ».", "nuit_mode")
            r["nuit_mode"] = b["nuit_mode"]
        if "rotation_s" in b:
            v = b["rotation_s"]
            if isinstance(v, bool) or not isinstance(v, int) or not (v == 0 or 10 <= v <= 600):
                raise ApiError(400, "Les pages tournent toutes les 10 à 600 secondes (0 = jamais).", "rotation_s")
            r["rotation_s"] = v
        if "prix_kwh" in b:
            v = b["prix_kwh"]
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not 0 < v < 2:
                raise ApiError(400, "Prix du kWh invalide (en euros, par exemple 0.194).", "prix_kwh")
            r["prix_kwh"] = round(float(v), 4)
        if "meteo_ville" in b:
            v = b["meteo_ville"]
            if not isinstance(v, str) or not 0 < len(v.strip()) <= 60:
                raise ApiError(400, "Nom de ville invalide.", "meteo_ville")
            if v.strip() != r["meteo_ville"]:
                lat, lon, nom = self._geocoder(v.strip())
                r.update(meteo_ville=nom, meteo_lat=lat, meteo_lon=lon)
                self.meteo = None
        self.state.set("affichage", r)
        self._ecrire_nuit()
        if self.reel and "meteo_ville" in b:
            threading.Thread(target=self._meteo_maj, daemon=True).start()
        return self.status()

    def _geocoder(self, ville):
        if not self.reel:
            return DEFAUTS["meteo_lat"], DEFAUTS["meteo_lon"], ville
        from urllib.parse import quote
        code, d = self.sys.http("GET", "https://geocoding-api.open-meteo.com/v1/search?count=1&language=fr&name="
                                + quote(ville), timeout=6)
        res = (d or {}).get("results") or []
        if code != 200 or not res:
            raise ApiError(404, "Ville introuvable : %s." % ville, "meteo_ville")
        return round(res[0]["latitude"], 4), round(res[0]["longitude"], 4), res[0].get("name", ville)

    # --- nuit ----------------------------------------------------------------------------
    def nuit(self):
        r = self.reglages()
        t = time.localtime(self.sys.now())
        en_cours = bool(r["nuit_actif"]) and dans_plage(t.tm_hour * 60 + t.tm_min, r["nuit_debut"], r["nuit_fin"])
        return {"actif": r["nuit_actif"], "debut": r["nuit_debut"], "fin": r["nuit_fin"],
                "mode": r["nuit_mode"], "en_cours": en_cours}

    def _ecrire_nuit(self):
        n = self.nuit()
        v = n["mode"] if n["en_cours"] else "jour"
        if v != self._nuit_ecrite and self.reel:
            try:
                self.sys.write(FICHIER_NUIT, v + "\n", mode=0o644)
                self._nuit_ecrite = v
            except Exception:
                pass

    # --- boucle --------------------------------------------------------------------------
    def start(self):
        if self.reel:
            threading.Thread(target=self._boucle, name="ydz-maison", daemon=True).start()

    def _boucle(self):
        tours = 0
        self._ecrire_nuit()
        time.sleep(8)
        while not self.stop.is_set():
            for f in (self._ecrire_nuit, self._pc_maj, self._watts_maj):
                try:
                    f()
                except Exception:
                    pass
            if tours % 2 == 0:                     # services : toutes les 2 minutes
                try:
                    self._services_maj()
                except Exception:
                    pass
            if tours % 15 == 0 or self.meteo is None and tours % 3 == 0:   # météo : 15 min
                self._meteo_maj()
            tours += 1
            self.stop.wait(60)

    def _meteo_maj(self):
        r = self.reglages()
        url = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
               "&current=temperature_2m,apparent_temperature,weather_code,is_day,wind_speed_10m,relative_humidity_2m"
               "&hourly=temperature_2m,weather_code,is_day,precipitation_probability"
               "&daily=temperature_2m_max,temperature_2m_min,weather_code"
               "&timezone=auto&forecast_days=3" % (r["meteo_lat"], r["meteo_lon"]))
        try:
            code, d = self.sys.http("GET", url, timeout=8)
        except Exception:
            return
        if code != 200 or not d or "current" not in d:
            return
        c = d["current"]
        txt, ico = meteo_texte(c.get("weather_code"), c.get("is_day", 1))
        heures = []
        h = d.get("hourly") or {}
        maint = c.get("time", "")
        for i, t in enumerate(h.get("time") or []):
            if t >= maint[:13] and len(heures) < 8:
                _, hi = meteo_texte(h["weather_code"][i], h["is_day"][i])
                heures.append({"h": t[11:13] + "h", "temp": round(h["temperature_2m"][i]), "icone": hi,
                               "pluie": (h.get("precipitation_probability") or [None] * (i + 1))[i]})
        jours = []
        dj = d.get("daily") or {}
        for i, t in enumerate(dj.get("time") or []):
            _, ji = meteo_texte(dj["weather_code"][i])
            jours.append({"date": t, "min": round(dj["temperature_2m_min"][i]),
                          "max": round(dj["temperature_2m_max"][i]), "icone": ji})
        self.meteo = {"ville": r["meteo_ville"], "temp": round(c.get("temperature_2m", 0)),
                      "ressenti": round(c.get("apparent_temperature", 0)), "texte": txt, "icone": ico,
                      "vent": round(c.get("wind_speed_10m", 0)), "humidite": c.get("relative_humidity_2m"),
                      "heures": heures, "jours": jours, "maj": int(self.sys.now())}

    def _pc_maj(self):
        t = self.hub.wol.targets()[0]
        en_ligne = self.hub.wol._online(t.get("ip")) if t.get("ip") else None
        if self.pc is None or self.pc["en_ligne"] != en_ligne:
            self.pc = {"nom": t.get("nom") or "PC", "en_ligne": en_ligne, "depuis": int(self.sys.now())}
        else:
            self.pc["nom"] = t.get("nom") or "PC"

    def _watts_maj(self):
        if self.sys.which("vcgencmd"):
            r = self.sys.run(["vcgencmd", "pmic_read_adc"], timeout=5)
            if r.ok:
                self.watts_hub = lire_pmic(r.out)

    def _services_maj(self):
        out = []
        for node in self.hub.nodes(self.hub.node.status()):
            if not node.get("en_ligne"):
                continue
            for a in node.get("apps", []):
                app = self.hub.node.apps.catalog.get(a["id"], {})
                etat = "ok" if a.get("etat") == "actif" else ("off" if a.get("etat") == "arrete" else "crit")
                web = app.get("web")
                if etat == "ok" and web and node.get("ip"):
                    url = "%s://%s:%d%s" % (web.get("schema", "http"), node["ip"], web["port"], web.get("chemin", "/"))
                    code, _ = self.sys.http("GET", url, timeout=4)
                    if not code or code >= 500:
                        etat = "warn"
                out.append({"id": a["id"], "nom": app.get("nom", a["id"]), "icone": app.get("icone", "box"),
                            "noeud": node["nom"], "etat": etat})
        self.services = sorted(out, key=lambda s: s["nom"].lower())

    # --- conso ---------------------------------------------------------------------------
    def conso(self, nodes):
        prix = self.reglages()["prix_kwh"]
        total, mesure = 0.0, False
        for n in nodes:
            if not n.get("en_ligne"):
                continue
            if n.get("hub") and self.watts_hub:
                total += self.watts_hub + 0.8     # + écran USB/HDMI, Wi-Fi, ventilateur hors PMIC
                mesure = True
            else:
                total += estimer_watts(n)
        kwh_mois = total * 24 * 30 / 1000.0
        return {"watts": round(total, 1), "mesure": mesure, "kwh_mois": round(kwh_mois, 1),
                "euros_mois": round(kwh_mois * prix, 2), "prix_kwh": prix}

    def status(self, nodes=None):
        r = self.reglages()
        return {"nuit": self.nuit(), "rotation_s": r["rotation_s"], "meteo_ville": r["meteo_ville"],
                "meteo": self.meteo, "pc": self.pc, "services": self.services,
                "curseur": self.hub.node.conf.get("curseur") == "oui",
                "conso": self.conso(nodes) if nodes is not None else None}
