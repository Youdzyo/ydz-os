#!/bin/bash
# YDZ OS 1.0.15 « Sécurité ». ydzd est redémarré à la fin par le paquet (lib/ a changé).
# Idempotent et jamais fatal : chaque étape facultative protège son échec.
echo "== 1.0.15 : sécurité ($(date '+%H:%M:%S'))"

# 1. openssl (chiffrement des sauvegardes) : présent par défaut sur Pi OS, on l'installe au besoin
if ! command -v openssl >/dev/null; then
    apt-get -o Acquire::ForceIPv4=true -o Acquire::Retries=10 install -y --no-install-recommends openssl \
        || echo "openssl non installé : les sauvegardes chiffrées seront indisponibles tant qu'il manque"
fi

# 2. Dossier du jeton « écran local » du kiosque : dans /run (root), groupe ydz-kiosk, 0750.
#    ydzd (re)crée et (re)remplit ce dossier au démarrage ; on le prépare ici pour éviter une fenêtre vide.
if getent group ydz-kiosk >/dev/null; then
    install -d -o root -g ydz-kiosk -m 0750 /run/ydz-kiosk || echo "/run/ydz-kiosk : création différée au démarrage de ydzd"
    # ancien emplacement (0400 dans un dossier appartenant à ydz-kiosk) : on retire le jeton qui y traîne (F-11)
    rm -f /var/lib/ydz-kiosk/jeton-local 2>/dev/null || true
fi
chmod 755 /opt/ydz/kiosk/ydz-kiosk /opt/ydz/bin/ydz-maj-chaine 2>/dev/null || true

# 3. Stratégie Chromium du kiosque (F-19) : DevTools coupés, navigation limitée à l'interface et au terminal.
for d in /etc/chromium/policies/managed /etc/chromium-browser/policies/managed; do
    if [ -d "$(dirname "$(dirname "$d")")" ] || command -v chromium >/dev/null || command -v chromium-browser >/dev/null; then
        install -D -m 0644 /opt/ydz/kiosk/chromium-policy.json "$d/ydz.json" 2>/dev/null \
            && echo "stratégie Chromium posée dans $d" || true
    fi
done

# 4. Unités systemd mises à jour (durcissement ydzd et kiosque) : copiées depuis le paquet, puis rechargées.
for u in ydzd.service ydz-kiosk.service; do
    if [ -f "/opt/ydz/systemd/$u" ]; then
        install -m 0644 "/opt/ydz/systemd/$u" "/etc/systemd/system/$u" 2>/dev/null \
            && echo "unité $u mise à jour" || echo "unité $u non copiée (ignorée)"
    fi
done

# 5. Terminal web (ttyd, F-15) : vérification d'origine + limite de clients, /tmp privé. Unité absente du paquet,
#    on la corrige sur place si elle existe (jamais fatal). ttyd reste sur le réseau local (le terminal depuis le
#    téléphone continue de marcher) ; la liaison 127.0.0.1-seulement est documentée dans TECHNIQUE.md.
UT=/etc/systemd/system/ydz-terminal.service
if [ -f "$UT" ]; then
    changed=0
    if ! grep -q -- '--check-origin' "$UT"; then
        sed -i -E 's#(ExecStart=.*\bttyd\b)#\1 --check-origin --max-clients 2#' "$UT" && changed=1
        echo "ttyd : --check-origin --max-clients 2 ajoutés"
    fi
    if ! grep -q '^PrivateTmp=' "$UT"; then
        sed -i '/^\[Service\]/a PrivateTmp=yes\nProtectSystem=full\nProtectHome=yes\nNoNewPrivileges=yes' "$UT" && changed=1
        echo "ttyd : durcissement systemd ajouté"
    fi
    [ "$changed" = 1 ] && systemctl daemon-reload 2>/dev/null || true
    systemctl restart ydz-terminal 2>/dev/null && echo "ydz-terminal relancé" || echo "ydz-terminal non relancé (ignoré)"
else
    echo "ydz-terminal.service absent : rien à durcir pour ttyd (ignoré)"
fi

# 6. Rechargement systemd global (nouvelles unités ydzd/kiosque)
systemctl daemon-reload 2>/dev/null || true

# 7. L'écran HDMI se recharge une fois ydzd revenu (nouvel écran de verrouillage, carte contrôle réseau).
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.15 terminé"
