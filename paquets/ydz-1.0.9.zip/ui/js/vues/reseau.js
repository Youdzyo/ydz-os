// Réseau : nœuds et adresses, Wake-on-LAN, accès à distance.
import { esc, ic, debit } from "../outils.js";
import { S, NOM, btn, champ, pastille, ouvrir, enteteDialogue, confirmer, toast, rendre } from "../noyau.js";
import { entete } from "../cadre.js";
import { lire, agir } from "../api.js";

function ligneNoeud(n) {
  if (!n.connu) {
    return `<li class="ligne-noeud libre" data-cle="r-${n.nom}"><span class="voyant off"></span><div><b>${NOM(n.nom)}</b><small>emplacement libre</small></div></li>`;
  }
  const r = n.reseau || {};
  return `<li class="ligne-noeud${n.en_ligne ? "" : " hors-ligne"}" data-cle="r-${n.nom}">
    <span class="voyant ${n.en_ligne ? "ok" : "off"}"></span>
    <div class="ln-nom"><b>${NOM(n.nom)}</b><small>${esc(n.nom)}.local</small></div>
    <div class="ln-adresse"><b>${esc(n.ip || n.adresse || "–")}</b><small>${esc((n.mac || "").toUpperCase() || "MAC inconnue")}</small></div>
    <div class="ln-lien">${n.en_ligne
      ? `<b>${r.lien_mbps ? (r.lien_mbps >= 1000 ? `${r.lien_mbps / 1000} Gbit/s` : `${r.lien_mbps} Mbit/s`) : "Lien inconnu"}</b><small>${ic("arrow-down")}${debit(r.rx_bps)} ${ic("arrow-up")}${debit(r.tx_bps)}</small>`
      : `<b>Hors ligne</b><small>${n.cle_invalide ? "refuse les ordres" : "ne répond plus"}</small>`}</div>
  </li>`;
}

function carteCible(c) {
  const etat = c.en_ligne === true ? pastille("ok", "En ligne") : c.en_ligne === false ? pastille("off", "Éteint") : pastille("off", "État inconnu");
  return `<article class="cible" data-cle="w-${c.id}">
    <span class="disque-icone${c.en_ligne ? " ok" : ""}">${ic("monitor")}</span>
    <div class="disque-textes"><h3><b>${esc(c.nom)}</b></h3><p>${esc(c.mac)}${c.ip ? ` · ${esc(c.ip)}` : ""}</p>${etat}</div>
    <div class="actions">
      ${c.fixe ? "" : btn("supprimer", "", { icone: "trash-2", classe: "rond discret danger-texte", titre: `Retirer ${c.nom}`, d: { id: c.id } })}
      ${c.ip ? btn("eteindre-pc", "Éteindre", { icone: "power", classe: "discret danger-texte grand", d: { id: c.id } }) : ""}
      ${btn("reveiller", "Réveiller", { icone: "zap", classe: "plein grand", d: { id: c.id } })}
    </div>
    ${c.ip ? `<button type="button" class="lien-discret" data-action="config-extinction" data-id="${c.id}">${ic("settings")}<span>Configurer l'extinction à distance</span></button>` : ""}
  </article>`;
}

function ouvrirCible() {
  const d = ouvrir({
    classe: "large",
    donnees: { nom: "", mac: "", ip: "", erreur: "" },
    rendu: () => {
      const x = d.donnees;
      return `${enteteDialogue("Ajouter une machine", { icone: "zap", sous: "Elle doit être reliée par câble, avec le Wake-on-LAN activé dans son BIOS." })}
      <div class="dlg-corps formulaire">
        <label class="reglage"><span class="reglage-nom">Nom</span>${champ("nom", x.nom, { placeholder: "PC du salon", max: 32, label: "Nom", rendre: true })}</label>
        <label class="reglage${x.erreur ? " erreur" : ""}"><span class="reglage-nom">Adresse MAC</span>${champ("mac", x.mac, { placeholder: "20:0B:74:6A:0B:6C", max: 17, label: "Adresse MAC", rendre: true })}
          <small>${x.erreur ? esc(x.erreur) : "Six groupes de deux caractères. Elle se lit dans les réglages réseau de la machine ou dans ta box."}</small></label>
        <label class="reglage"><span class="reglage-nom">Adresse IP <em>facultatif</em></span>${champ("ip", x.ip, { placeholder: "192.168.1.40", max: 15, label: "Adresse IP" })}
          <small>Avec l'adresse IP, YDZ peut dire si la machine est allumée.</small></label>
      </div>
      <footer class="dlg-pied">${btn("fermer", "Annuler", { classe: "discret" })}${btn("ajouter", "Ajouter", { icone: "plus", classe: "plein", off: !x.nom.trim() || !x.mac.trim() })}</footer>`;
    },
    actions: {
      async ajouter() {
        const x = d.donnees;
        const diffusion = S.etat.noeuds[0]?.ip ? S.etat.noeuds[0].ip.replace(/\.\d+$/, ".255") : "192.168.1.255";
        const corps = { nom: x.nom.trim(), mac: x.mac.trim().toUpperCase().replace(/-/g, ":"), diffusion };
        if (x.ip.trim()) corps.ip = x.ip.trim();
        try { await agir("/api/wol", corps); } catch (e) {
          if (e.code === "mac") { x.erreur = e.message; return; }
          throw e;
        }
        d.fermer();
        toast(`${corps.nom} ajouté.`, "ok");
        vue.charger().then(rendre);
      },
    },
  });
}

// Commande PowerShell (administrateur) à coller une fois sur le PC Windows : serveur OpenSSH,
// clé de forge limitée à la seule commande d'extinction, pare-feu limité au réseau privé.
function commandeWindows(cle) {
  const ligne = `command="shutdown /s /f /t 5",no-port-forwarding,no-pty,no-agent-forwarding ${cle}`;
  return [
    "Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0 | Out-Null",
    "Set-Service sshd -StartupType Automatic; Start-Service sshd",
    "if (!(Get-NetFirewallRule -Name OpenSSH-Server-In-TCP -ErrorAction SilentlyContinue)) { New-NetFirewallRule -Name OpenSSH-Server-In-TCP -DisplayName 'OpenSSH Server (sshd)' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22 -Profile Private | Out-Null }",
    `$l = '${ligne.replace(/'/g, "''")}'`,
    "$f = \"$env:ProgramData\\ssh\\administrators_authorized_keys\"; Add-Content -Path $f -Value $l; icacls $f /inheritance:r /grant '*S-1-5-32-544:F' /grant '*S-1-5-18:F' | Out-Null",
    "New-Item -ItemType Directory -Force \"$env:USERPROFILE\\.ssh\" | Out-Null; Add-Content -Path \"$env:USERPROFILE\\.ssh\\authorized_keys\" -Value $l",
    "Write-Host 'YDZ : extinction a distance prete.' -ForegroundColor Green",
  ].join("\n");
}

async function ouvrirExtinction(cible) {
  const r = await lire("/api/wol/cle");
  const cmd = commandeWindows(r.cle);
  const d = ouvrir({
    classe: "large",
    donnees: {},
    rendu: () => `${enteteDialogue("Extinction à distance", { icone: "power", sous: `${esc(cible?.nom || "PC")} · une seule fois, sur le PC` })}
      <div class="dlg-corps formulaire">
        <p class="texte">1. Sur le PC, clic droit sur le menu Démarrer, puis <b>Terminal (administrateur)</b> ou <b>Windows PowerShell (administrateur)</b>.</p>
        <p class="texte">2. Copie le bloc ci-dessous, colle-le dans la fenêtre (clic droit) et appuie sur Entrée. Attends le message vert.</p>
        <pre class="commande-pc">${esc(cmd)}</pre>
        <p class="note-fine">${ic("info")}La clé de forge ne peut lancer qu'une chose sur le PC : <code>shutdown</code>. Le compte utilisé est <b>${esc(r.utilisateur)}</b> (clé wol_utilisateur de /etc/ydz/ydz.conf). Pour rallumer, le bouton Réveiller utilise le Wake-on-LAN.</p>
      </div>
      <footer class="dlg-pied">${btn("copier", "Copier", { icone: "copy", classe: "discret" })}${btn("fermer", "Terminé", { classe: "plein" })}</footer>`,
    actions: {
      async copier() {
        let ok = false;
        try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(cmd); ok = true; } } catch { /* http simple */ }
        if (!ok) {
          // http simple : zone de texte temporaire hors écran + execCommand (marche aussi sur iPhone)
          const t = document.createElement("textarea");
          t.value = cmd; t.setAttribute("readonly", "");
          t.style.cssText = "position:fixed;top:0;left:-9999px;opacity:0";
          document.body.appendChild(t);
          t.select(); t.setSelectionRange(0, cmd.length);
          try { ok = document.execCommand("copy"); } catch { /* navigateur ancien */ }
          t.remove();
        }
        toast(ok ? "Commande copiée." : "Sélectionne le texte et copie-le à la main.", ok ? "ok" : undefined);
      },
    },
  });
}

const vue = {
  cibles: null,
  async charger() {
    const r = await lire("/api/wol").catch(() => null);
    if (r) this.cibles = r.cibles;
  },
  rendu() {
    const e = S.etat;
    const enLigne = e.noeuds.filter((n) => n.en_ligne).length;
    const wg = S.apps?.catalogue.find((a) => a.id === "wg-easy");
    const wgIns = wg?.installations[0];
    return `${entete("Réseau", { sous: `${enLigne} nœud${enLigne > 1 ? "s" : ""} en ligne · interface sur http://${esc(e.hub)}.local` })}
    <div class="deux-colonnes">
      <section class="carte bloc">
        <h2 class="bloc-titre">${ic("network")}Nœuds</h2>
        <ul class="lignes-noeuds">${e.noeuds.map(ligneNoeud).join("")}</ul>
        <p class="note-fine">${ic("info")}Les nœuds se trouvent par leur nom en <b>.local</b>. Si un nom ne répond pas, utilise l'adresse IP affichée sur le badge.</p>
      </section>
      <div class="colonne">
        <section class="carte bloc">
          <h2 class="bloc-titre">${ic("zap")}Réveil à distance</h2>
          ${this.cibles ? this.cibles.map(carteCible).join("") : `<div class="attente">${ic("loader-circle", "tourne")}</div>`}
          <button type="button" class="btn discret seul" data-action="ajouter">${ic("plus")}<span>Ajouter une machine</span></button>
        </section>
        <section class="carte bloc">
          <h2 class="bloc-titre">${ic("shield-check")}Accès depuis l'extérieur</h2>
          <p class="texte">Ta tour est joignable de partout grâce à <b>Tailscale</b> : ton téléphone rejoint ton réseau comme s'il était à la maison, sans rien ouvrir sur ta box.</p>
          <ol class="etapes">
            <li>Active l'app <b>Tailscale</b> sur ton téléphone ou ton PC (même compte que forge).</li>
            <li>Ouvre <b>http://forge/</b> : le site, le terminal et le réveil du PC marchent comme à la maison.</li>
            <li>Ne redirige aucun port de ta box vers la tour : Tailscale suffit.</li>
          </ol>
          <a class="btn" href="https://login.tailscale.com/admin/machines" target="_blank" rel="noopener">${ic("external-link")}<span>Console Tailscale</span></a>
        </section>
      </div>
    </div>`;
  },
  actions: {
    ajouter: ouvrirCible,
    async "eteindre-pc"({ id }) {
      const c = this.cibles?.find((x) => x.id === id);
      if (!(await confirmer({ titre: `Éteindre ${c?.nom || "le PC"} ?`, texte: "Le PC s'éteint dans 5 secondes, sans demander. Enregistre ton travail avant.", libelle: "Éteindre", danger: true, icone: "power" }))) return;
      await agir(`/api/wol/${id}/eteindre`);
      toast("Ordre d'extinction envoyé.", "ok");
      setTimeout(() => this.charger().then(rendre), 15000);
    },
    async "config-extinction"({ id }) {
      await ouvrirExtinction(this.cibles?.find((x) => x.id === id));
    },
    async reveiller({ id }) {
      const r = await agir(`/api/wol/${id}/reveiller`);
      toast(r.message || "Signal de réveil envoyé.", "ok");
    },
    async supprimer({ id }) {
      const c = this.cibles.find((x) => x.id === id);
      if (!(await confirmer({ titre: `Retirer ${c?.nom || "cette machine"} ?`, texte: "Elle ne sera plus proposée au réveil. Tu pourras la rajouter.", libelle: "Retirer", danger: true }))) return;
      await agir(`/api/wol/${id}/supprimer`);
      await this.charger();
    },
  },
};
export default vue;
