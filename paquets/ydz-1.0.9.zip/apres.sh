#!/bin/bash
# YDZ 1.0.9 : écran d'affichage. ydzd est redémarré à la fin par le paquet.
echo "== 1.0.9 : écran du Pi ($(date '+%H:%M:%S'))"
# wlopm met l'écran HDMI en veille la nuit (sinon on coupe la sortie avec wlr-randr)
if ! command -v wlopm >/dev/null; then
    apt-get -o Acquire::ForceIPv4=true -o Acquire::Retries=10 install -y --no-install-recommends wlopm \
        && echo "wlopm installé" || echo "wlopm indisponible : la sortie sera coupée avec wlr-randr"
fi
# heure de France si le Pi est resté en UTC (la nuit et la météo suivent l'heure locale)
if [ "$(timedatectl show -p Timezone --value 2>/dev/null)" = "Etc/UTC" ]; then
    timedatectl set-timezone Europe/Paris && echo "fuseau horaire : Europe/Paris"
fi
echo "fuseau : $(timedatectl show -p Timezone --value 2>/dev/null)"
# recharge l'écran une fois ydzd redémarré
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.9 terminé"
