"""Appareils connectés au réseau de la maison (affichés en haut de l'accueil).

Toutes les 5 minutes, le hub « touche » chaque adresse de son réseau /24 avec un petit paquet UDP
(port 9, ignoré par tout le monde) : le noyau doit alors trouver l'adresse matérielle de chacun, et
la table ARP (/proc/net/arp) contient ensuite les appareils réellement présents. On compte aussi les
appareils Tailscale en ligne. Rien n'est envoyé hors du réseau local.
"""
import ipaddress
import json
import socket
import threading
import time

PERIODE = 300


class Voisins:
    def __init__(self, sys):
        self.sys = sys
        self.res = None            # {"appareils": n, "tailscale": m|None, "maj": t}
        self.stop = threading.Event()
        self.reel = type(sys).__name__ == "System"   # pas de balayage en simulation / tests

    def start(self):
        if self.reel:
            threading.Thread(target=self._boucle, name="ydz-voisins", daemon=True).start()

    def status(self):
        return self.res

    def _boucle(self):
        time.sleep(20)                        # laisse le réseau se lever au démarrage
        while not self.stop.is_set():
            try:
                self.res = self.mesure()
            except Exception:                 # une mesure ratée ne doit jamais gêner le démon
                pass
            self.stop.wait(PERIODE)

    def _reseau(self):
        """(interface, adresse, réseau /24) de la route par défaut."""
        r = self.sys.run(["ip", "-4", "-o", "route", "get", "1.1.1.1"], timeout=5)
        mots = (r.out or "").split()
        if not r.ok or "dev" not in mots or "src" not in mots:
            return None
        dev, src = mots[mots.index("dev") + 1], mots[mots.index("src") + 1]
        net = ipaddress.ip_network(src + "/24", strict=False)
        return dev, src, net

    def mesure(self):
        r = self._reseau()
        if not r:
            return None
        dev, src, net = r
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            for h in net.hosts():
                if str(h) == src:
                    continue
                try:
                    s.sendto(b"\0", (str(h), 9))
                except OSError:
                    pass
                time.sleep(0.004)             # ~1 s pour tout le réseau, sans saturer un Wi-Fi faible
        finally:
            s.close()
        time.sleep(3)                         # le temps que les réponses ARP arrivent
        vus = set()
        for ligne in (self.sys.read("/proc/net/arp", "") or "").splitlines()[1:]:
            c = ligne.split()
            if len(c) >= 6 and c[2] == "0x2" and c[5] == dev and c[3] != "00:00:00:00:00:00":
                try:
                    if ipaddress.ip_address(c[0]) in net:
                        vus.add(c[3])
                except ValueError:
                    pass
        ts = None
        if self.sys.which("tailscale"):
            t = self.sys.run(["tailscale", "status", "--json"], timeout=8)
            if t.ok:
                try:
                    pairs = (json.loads(t.out).get("Peer") or {}).values()
                    ts = sum(1 for p in pairs if p.get("Online"))
                except ValueError:
                    ts = None
        # + 1 : le hub lui-même est un appareil du réseau
        return {"appareils": len(vus) + 1, "tailscale": ts, "maj": int(self.sys.now())}
