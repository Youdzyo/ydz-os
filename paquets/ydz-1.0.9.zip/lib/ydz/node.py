"""Le nœud YDZ : boucle de mesure, badge, et toutes les routes de l'API.

Niveaux d'accès d'une route :
  libre   lecture pour tout le réseau local ;
  action  écran local (127.0.0.1) OU session PIN (hub) OU ordre signé du hub ;
  agent   écran/CLI local OU ordre signé du hub (routes internes /api/agent/…).
"""
import ipaddress
import re
import threading
from urllib.parse import quote

from . import auth as authmod
from . import config, diag
from .apps import Apps, mask_settings
from .badge import BadgeLink
from .core import ApiError, Events, Tasks
from .fan import MODES
from .hub import Hub
from .metrics import Collector
from .services import Updates
from .storage import Storage

ROUTES = []


def route(method, pattern, acces="libre", hub=False):
    def deco(fn):
        ROUTES.append((method, re.compile("^" + pattern + "$"), acces, hub, fn))
        return fn
    return deco


class Req:
    def __init__(self, params, query, body, ctx):
        self.p, self.q, self.b, self.ctx = params, query, body, ctx

    def str(self, key, default=None):
        v = self.b.get(key, default)
        if v is not None and not isinstance(v, str):
            raise ApiError(400, "Champ « %s » invalide." % key, "champ")
        return v


class Node:
    def __init__(self, sys, conf, base, sync_tasks=False, net_only=False):
        self.sys, self.conf, self.base = sys, conf, base
        self.name = sys.hostname()
        self.role = conf.role(self.name)
        self.net_only = net_only          # --sim-reseau : 127.0.0.1 traité comme le réseau
        self.state = config.State(sys)
        self.local = authmod.LocalToken(sys)
        self.events = Events()
        self.tasks = Tasks(sys, self.name, self._task_changed, sync=sync_tasks)
        self.collector = Collector(sys, conf)
        self.badge = BadgeLink(sys, conf, self.state)
        self.apps = Apps(sys, self.state, self.tasks, base + "/apps", self.collector)
        self.storage = Storage(sys, self.state, self.tasks)
        self.updates = Updates(sys, conf, self.state, self.tasks, base)
        self.halting = None
        self.lock = threading.Lock()
        self.hub = Hub(self) if self.role == "forge" else None
        self._raw = self.collector.collect()
        self.stop = threading.Event()

    # --- boucle -------------------------------------------------------------
    def status(self):
        st = dict(self._raw)
        st["heure"] = int(self.sys.now())      # horloge fraîche : le hub signe ses ordres avec
        st["badge"] = self.badge.status()
        st["appaire"] = bool(self.state.get("cle_tour"))
        st["apps"] = self.apps.list(st["docker"]["conteneurs"])
        st["taches"] = self.tasks.list()[:8]
        if self.halting:
            st["etat"] = "halt"
        return st

    def tick(self):
        self._raw = self.collector.collect()
        st = self.status()
        self.badge.tick(st, "halt" if self.halting else None)
        if self.hub:
            self.hub.tick(st)
            if self.events.listeners:
                self.events.publish("etat", self.hub.snapshot(st))
        return st

    def run(self):
        if self.hub:
            self.hub.start()
        while not self.stop.is_set():
            try:
                self.tick()
            except Exception as ex:           # la boucle ne meurt jamais
                print("ydzd : erreur de boucle : %r" % ex, flush=True)
            self.stop.wait(2.0)

    def shutdown(self, system_halting=False):
        """Arrêt du démon. Ventilateur relâché = 100 % (sécurité)."""
        self.stop.set()
        if system_halting or self.halting:
            self.badge.halt(self.status())
        if self.hub:
            self.hub.fan.pwm.release()

    def _task_changed(self, task):
        self.events.publish("tache", task.as_dict())

    def power(self, action, delay=2):
        if self.halting:
            return
        self.halting = action
        st = self.status()
        self.badge.halt(st)
        self.events.publish("notification", {"niveau": "info", "texte": "%s : %s en cours" % (
            self.name.upper(), "extinction" if action == "eteindre" else "redémarrage")})
        cmd = ["systemctl", "poweroff" if action == "eteindre" else "reboot"]
        t = threading.Timer(delay, lambda: self.sys.spawn(cmd))
        t.daemon = True
        t.start()

    # --- accès ----------------------------------------------------------------
    def check_access(self, acces, ctx):
        if acces == "libre" or ctx.get("local") or ctx.get("sig"):
            return
        if acces == "action" and self.hub:
            if self.hub.auth.valid(ctx.get("token")):
                return
            if not self.hub.auth.pin_set:
                raise ApiError(403, "Aucun code PIN n'est défini. Choisis-en un sur l'écran de la tour "
                                    "(Réglages > Code PIN) pour agir depuis le réseau.", "pin_non_defini")
            raise ApiError(401, "Code PIN demandé.", "pin_requis")
        raise ApiError(401, "Accès refusé : cette route est réservée au hub et à l'écran local.", "signature")

    def dispatch(self, method, path, query, body, ctx):
        """Retourne (code HTTP, dict)."""
        found = False
        for m, rx, acces, hub_only, fn in ROUTES:
            mt = rx.match(path)
            if not mt:
                continue
            found = True
            if m != method:
                continue
            try:
                if hub_only and not self.hub:
                    raise ApiError(404, "Ce nœud n'est pas le hub. Adresse-toi à forge.", "pas_hub")
                self.check_access(acces, ctx)
                res = fn(self, Req(mt.groupdict(), query or {}, body if isinstance(body, dict) else {}, ctx))
                if isinstance(res, tuple):
                    return res
                return 200, res
            except ApiError as ex:
                return ex.status, ex.body()
            except Exception as ex:          # un bug de route ne doit ni tuer le fil HTTP ni fuiter une trace
                print("ydzd : erreur inattendue sur %s %s : %r" % (method, path, ex), flush=True)
                return 500, {"erreur": "Erreur interne du démon. Détail : ydz journal.", "code": "interne"}
        if found:
            return 405, {"erreur": "Méthode non permise.", "code": "methode"}
        return 404, {"erreur": "Route inconnue.", "code": "inconnu"}

    def dispatch_local(self, method, path, body=None):
        q = {}
        if "?" in path:
            from urllib.parse import parse_qsl
            path, qs = path.split("?", 1)
            q = dict(parse_qsl(qs))
        code, data = self.dispatch(method, path, q, body or {}, {"local": True, "client": "interne"})
        if code >= 400:
            extra = {k: v for k, v in data.items() if k not in ("erreur", "code")}
            raise ApiError(code, data.get("erreur", "Erreur."), data.get("code", "erreur"), **extra)
        data.setdefault("noeud", self.name)
        return data


def _task(t):
    return {"ok": True, "tache": t.as_dict()}


def _int(v, default, lo, hi):
    try:
        return max(lo, min(hi, int(v)))
    except (TypeError, ValueError):
        return default


# =============================================================================
# Routes de tous les nœuds (port 8787)
# =============================================================================
@route("GET", "/api/status")
def r_status(n, r):
    return n.status()


@route("GET", "/api/ping")
def r_ping(n, r):
    return {"ydz": 1, "nom": n.name, "role": n.role, "hub": bool(n.hub), "version": config.version()}


@route("POST", "/api/pair")
def r_pair(n, r):
    """Appairage « à la première rencontre » : un nœud sans clé accepte celle
    du premier hub qui se présente depuis le réseau local."""
    if n.hub:
        raise ApiError(409, "Le hub ne s'appaire pas.", "hub")
    if n.state.get("cle_tour"):
        raise ApiError(409, "Ce nœud est déjà appairé. Pour recommencer : « sudo ydz appairer ».", "deja_appaire")
    try:
        ip = ipaddress.ip_address(r.ctx.get("client", "").replace("::ffff:", ""))
        private = ip.is_private or ip.is_loopback or ip.is_link_local
    except ValueError:
        private = False
    key = r.str("cle")
    if not private or not key or not re.match(r"^[A-Za-z0-9_-]{32,64}$", key):
        raise ApiError(403, "Appairage refusé.", "appairage")
    n.state.set("cle_tour", key)
    n.state.set("hub", (r.str("hub") or "")[:32])
    return {"ok": True, "nom": n.name}


@route("POST", "/api/ecran/billet", hub=True)
def r_ticket(n, r):
    """Billet à usage unique que le script du kiosque échange contre le cookie « écran local »."""
    if not r.ctx.get("local"):
        raise ApiError(403, "Réservé au kiosque de la tour.", "local")
    return {"billet": n.local.make_billet()}


@route("POST", "/api/appairage/oublier", "agent")
def r_unpair(n, r):
    if n.hub:
        raise ApiError(409, "Sur le hub, il n'y a rien à oublier.", "hub")
    n.state.delete("cle_tour")
    return {"ok": True}


@route("POST", "/api/(?P<action>redemarrer|eteindre)", "action")
def r_power(n, r):
    n.power(r.p["action"])
    return {"ok": True, "noeud": n.name, "action": r.p["action"], "delai_s": 2}


# --- routes d'agent ------------------------------------------------------------
@route("GET", "/api/agent/apps", "agent")
def a_apps(n, r):
    return {"apps": n.apps.list(n._raw["docker"]["conteneurs"], secrets_ok=True)}


@route("POST", "/api/agent/apps/(?P<id>[a-z0-9-]+)/(?P<action>installer|demarrer|arreter|redemarrer|"
               "mettre-a-jour|desinstaller|reglages)", "agent")
def a_app_action(n, r):
    a, i = r.p["action"], r.p["id"]
    if a == "installer":
        return _task(n.apps.install(i, r.b.get("reglages"), r.str("emplacement")))
    if a == "reglages":
        return _task(n.apps.configure(i, r.b.get("reglages")))
    if a == "desinstaller":
        return _task(n.apps.uninstall(i, r.b.get("supprimer_donnees") is True))
    return _task({"demarrer": n.apps.start, "arreter": n.apps.stop, "redemarrer": n.apps.restart,
                  "mettre-a-jour": n.apps.update}[a](i))


@route("GET", "/api/agent/apps/(?P<id>[a-z0-9-]+)/journal", "agent")
def a_app_logs(n, r):
    return n.apps.logs(r.p["id"], _int(r.q.get("lignes"), 200, 10, 1000))


@route("GET", "/api/agent/stockage", "agent")
def a_storage(n, r):
    return n.storage.overview()


@route("POST", "/api/agent/stockage/(?P<kind>formater|miroir)/preparer", "agent")
def a_storage_prepare(n, r):
    mirror = r.p["kind"] == "miroir"
    paths = r.b.get("disques") if mirror else [r.b.get("disque")]
    return n.storage.prepare(paths, r.b.get("nom"), mirror)


@route("POST", "/api/agent/stockage/confirmer", "agent")
def a_storage_confirm(n, r):
    return _task(n.storage.confirm(r.b.get("jeton"), r.b.get("phrase")))


@route("POST", "/api/agent/stockage/remonter", "agent")
def a_storage_remount(n, r):
    return dict(n.storage.remount(r.b.get("disque")), ok=True)


@route("POST", "/api/agent/stockage/partages", "agent")
def a_share_add(n, r):
    return {"ok": True, "partage": n.storage.add_share(r.b.get("nom"), r.b.get("disque"),
                                                       r.b.get("acces", "prive"))}


@route("POST", "/api/agent/stockage/partages/supprimer", "agent")
def a_share_del(n, r):
    n.storage.remove_share(r.b.get("nom"))
    return {"ok": True}


@route("POST", "/api/agent/stockage/samba/mot-de-passe", "agent")
def a_smb_pw(n, r):
    n.storage.set_password(r.b.get("mot_de_passe"))
    return {"ok": True}


@route("GET", "/api/agent/maj", "agent")
def a_maj(n, r):
    return n.updates.status()


@route("POST", "/api/agent/maj/verifier", "agent")
def a_maj_check(n, r):
    return _task(n.updates.check())


@route("POST", "/api/agent/maj/appliquer", "agent")
def a_maj_apply(n, r):
    n.updates.apply()
    return {"ok": True}


@route("POST", "/api/agent/badge", "agent")
def a_badge(n, r):
    b = r.b
    if "luminosite" in b:
        if not isinstance(b["luminosite"], int) or isinstance(b["luminosite"], bool) or not 0 <= b["luminosite"] <= 100:
            raise ApiError(400, "La luminosité va de 0 à 100.", "luminosite")
        n.state.set("badge_lum", b["luminosite"])
    if "accent" in b:
        if not isinstance(b["accent"], str) or not re.match(r"^#?[0-9A-Fa-f]{6}$", b["accent"]):
            raise ApiError(400, "Couleur attendue : RRGGBB.", "accent")
        n.state.set("accent", b["accent"].lstrip("#").upper())
    if "retourne" in b:
        n.state.set("badge_rot", 1 if b["retourne"] else 0)
    return {"ok": True, "badge": n.badge.status()}


@route("GET", "/api/agent/taches/(?P<id>[0-9a-f]+)", "agent")
def a_task(n, r):
    t = n.tasks.get(r.p["id"])
    if not t:
        raise ApiError(404, "Tâche inconnue (trop ancienne ?).", "tache")
    return {"tache": t.as_dict(full=True)}


@route("GET", "/api/agent/diagnostic", "agent")
def a_diag(n, r):
    return {"noeud": n.name, "controles": diag.run(n)}


# =============================================================================
# Routes du hub (ports 80 et 8787 de forge)
# =============================================================================
@route("GET", "/api/etat", hub=True)
def h_etat(n, r):
    return n.hub.snapshot(n.status())


@route("GET", "/api/noeuds", hub=True)
def h_nodes(n, r):
    return {"noeuds": n.hub.nodes(n.status())}


@route("GET", "/api/noeuds/(?P<nom>[a-z0-9-]+)", hub=True)
def h_node(n, r):
    for x in n.hub.nodes(n.status()):
        if x["nom"] == r.p["nom"]:
            return x
    raise ApiError(404, "Nœud inconnu.", "noeud")


@route("POST", "/api/noeuds/(?P<nom>[a-z0-9-]+)/(?P<action>redemarrer|eteindre)", "action", hub=True)
def h_node_power(n, r):
    return n.hub.agent(r.p["nom"], "POST", "/api/" + r.p["action"], {}, timeout=5)


@route("POST", "/api/tour/(?P<action>redemarrer|eteindre)", "action", hub=True)
def h_tower(n, r):
    return {"ok": True, "action": r.p["action"], "noeuds": n.hub.tower(r.p["action"])}


@route("GET", "/api/systeme", hub=True)
def h_system(n, r):
    c = n.conf
    return {"nom": n.name, "role": n.role, "version": config.version(), "modele": n.collector.model,
            "config": {k: c.get(k) for k in ("role", "noeuds", "port", "port_web", "kiosk", "rotation",
                                             "ventilo_gpio", "ventilo_hz", "badge", "accent", "docker",
                                             "maj_auto")},
            "erreurs_config": c.errors, "erreurs_catalogue": n.apps.errors, "simulation": bool(n.sys.sim)}


# --- appairage des nœuds (confirmation explicite) -------------------------------------
@route("GET", "/api/appairage", hub=True)
def h_pairing(n, r):
    return {"demandes": n.hub.pending()}


@route("POST", "/api/appairage/(?P<nom>[a-z0-9-]+)/(?P<action>accepter|refuser)", "action", hub=True)
def h_pairing_answer(n, r):
    if r.p["action"] == "accepter":
        return n.hub.accept_pair(r.p["nom"])
    return n.hub.refuse_pair(r.p["nom"])


# --- authentification ------------------------------------------------------------
@route("GET", "/api/auth", hub=True)
def h_auth(n, r):
    a = n.hub.auth
    return {"pin_defini": a.pin_set, "local": bool(r.ctx.get("local")),
            "connecte": bool(r.ctx.get("local")) or a.valid(r.ctx.get("token")),
            "attente_s": max(a.limiter.wait(r.ctx.get("client")), a.limiter.wait("*"))}


@route("POST", "/api/auth/connexion", hub=True)
def h_login(n, r):
    tok, msg, wait = n.hub.auth.login(r.b.get("pin"), r.ctx.get("client"))
    if tok:
        return {"ok": True, "jeton": tok, "expire_s": authmod.SESSION_TTL}
    if wait:
        raise ApiError(429, msg, "trop_d_essais", attente_s=wait)
    raise ApiError(401 if n.hub.auth.pin_set else 403, msg,
                   "pin_incorrect" if n.hub.auth.pin_set else "pin_non_defini", attente_s=0)


@route("POST", "/api/auth/deconnexion", hub=True)
def h_logout(n, r):
    n.hub.auth.logout(r.ctx.get("token"))
    return {"ok": True}


@route("POST", "/api/auth/pin", hub=True)
def h_set_pin(n, r):
    a = n.hub.auth
    if not r.ctx.get("local"):
        if not a.pin_set:
            raise ApiError(403, "Le premier code PIN se choisit sur l'écran de la tour.", "pin_non_defini")
        if not a.valid(r.ctx.get("token")):
            raise ApiError(401, "Code PIN demandé.", "pin_requis")
        tok, msg, wait = a.login(r.b.get("ancien"), r.ctx.get("client"))
        if not tok:
            raise ApiError(429 if wait else 401, "Ancien code incorrect." if not wait else msg,
                           "trop_d_essais" if wait else "pin_incorrect", attente_s=wait)
    try:
        a.set_pin(r.b.get("pin"))
    except ValueError as ex:
        raise ApiError(400, str(ex), "pin_invalide")
    return {"ok": True}


# --- ventilateur -------------------------------------------------------------------
@route("GET", "/api/ventilo", hub=True)
def h_fan(n, r):
    return n.hub.fan.status()


@route("POST", "/api/ventilo", "action", hub=True)
def h_fan_set(n, r):
    if r.b.get("mode") not in MODES:
        raise ApiError(400, "Mode inconnu (silence, equilibre, performance).", "mode")
    n.hub.fan.set_mode(r.b["mode"])
    return {"ok": True, "ventilo": n.hub.fan.status()}


@route("POST", "/api/ventilo/test", "action", hub=True)
def h_fan_test(n, r):
    n.hub.fan.test(_int(r.b.get("secondes"), 5, 1, 30))
    return {"ok": True}


# --- applications --------------------------------------------------------------------
def _installations(n, app_id=None):
    out = {}
    for node in n.hub.nodes(n.status()):
        if not node.get("en_ligne"):
            continue
        for a in node.get("apps", []):
            if app_id and a["id"] != app_id:
                continue
            app = n.apps.catalog.get(a["id"], {})
            web = app.get("web")
            url = None
            if web and node.get("ip"):
                url = "%s://%s:%d%s" % (web.get("schema", "http"), node["ip"], web["port"], web.get("chemin", "/"))
            out.setdefault(a["id"], []).append(dict(a, noeud=node["nom"], url=url))
    return out


def _app_nodes(n):
    out = []
    for node in n.hub.nodes(n.status()):
        if not node.get("connu"):
            continue
        ram = node.get("ram", {})
        out.append({"nom": node["nom"], "role": node.get("role"), "en_ligne": node["en_ligne"],
                    "docker": bool(node.get("docker", {}).get("dispo")),
                    "ram_total": ram.get("total"), "ram_libre": (ram.get("total", 0) - ram.get("utilise", 0)),
                    "emplacements": [d["point"] for d in node.get("disques", [])
                                     if d["point"].startswith("/srv/ydz/")]})
    return out


@route("GET", "/api/apps", hub=True)
def h_apps(n, r):
    inst = _installations(n)
    cat = [dict(a, installations=inst.get(a["id"], [])) for a in
           sorted(n.apps.catalog.values(), key=lambda a: (a["categorie"], a["nom"]))]
    return {"catalogue": cat, "noeuds": _app_nodes(n), "erreurs": n.apps.errors}


@route("GET", "/api/apps/(?P<id>[a-z0-9-]+)", hub=True)
def h_app(n, r):
    app = n.apps.catalog.get(r.p["id"])
    if not app:
        raise ApiError(404, "Application inconnue.", "app_inconnue")
    inst = _installations(n, app["id"]).get(app["id"], [])
    if r.ctx.get("local") or n.hub.auth.valid(r.ctx.get("token")):
        for i in inst:                    # réglages en clair pour qui a le droit d'agir
            try:
                full = n.hub.agent(i["noeud"], "GET", "/api/agent/apps")["apps"]
                i["reglages"] = next((x["reglages"] for x in full if x["id"] == app["id"]), i["reglages"])
            except ApiError:
                pass
    return dict(app, installations=inst, noeuds=_app_nodes(n))


@route("POST", "/api/apps/(?P<id>[a-z0-9-]+)/(?P<action>installer|demarrer|arreter|redemarrer|"
               "mettre-a-jour|desinstaller|reglages)", "action", hub=True)
def h_app_action(n, r):
    app = n.apps.catalog.get(r.p["id"], {})
    body = {k: r.b[k] for k in ("reglages", "emplacement", "supprimer_donnees") if k in r.b}
    return n.hub.agent(r.str("noeud"), "POST", "/api/agent/apps/%s/%s" % (r.p["id"], r.p["action"]), body,
                       default=app.get("noeud_conseille") if r.p["action"] == "installer" and
                       n.hub.peers.get(app.get("noeud_conseille") or "") and
                       n.hub.peers.online(n.hub.peers.get(app["noeud_conseille"])) else None)


@route("GET", "/api/apps/(?P<id>[a-z0-9-]+)/journal", "action", hub=True)
def h_app_logs(n, r):
    return n.hub.agent(r.q.get("noeud"), "GET", "/api/agent/apps/%s/journal?lignes=%d"
                       % (r.p["id"], _int(r.q.get("lignes"), 200, 10, 1000)))


# --- stockage --------------------------------------------------------------------------
def _storage_node(n, name):
    if name:
        return name
    v = n.hub.peers.get("vault")
    return "vault" if v and n.hub.peers.online(v) else n.name


@route("GET", "/api/stockage", hub=True)
def h_storage(n, r):
    return n.hub.agent(_storage_node(n, r.q.get("noeud")), "GET", "/api/agent/stockage")


@route("POST", "/api/stockage/(?P<sub>formater/preparer|miroir/preparer|confirmer|remonter|partages|"
               "partages/supprimer|samba/mot-de-passe)", "action", hub=True)
def h_storage_action(n, r):
    body = {k: v for k, v in r.b.items() if k != "noeud"}
    return n.hub.agent(_storage_node(n, r.str("noeud")), "POST", "/api/agent/stockage/" + r.p["sub"], body,
                       timeout=30)


# --- Wake-on-LAN -------------------------------------------------------------------------
@route("GET", "/api/wol", hub=True)
def h_wol(n, r):
    return n.hub.wol.status()


@route("POST", "/api/wol", "action", hub=True)
def h_wol_add(n, r):
    return {"ok": True, "cible": n.hub.wol.add(r.b.get("nom"), r.b.get("mac"), r.b.get("diffusion"),
                                               r.b.get("ip", ""))}


@route("POST", "/api/wol/(?P<id>[a-z0-9]+)/reveiller", "action", hub=True)
def h_wol_wake(n, r):
    t = n.hub.wol.wake(r.p["id"])
    return {"ok": True, "message": "Signal de réveil envoyé à %s." % t["nom"]}


@route("POST", "/api/wol/(?P<id>[a-z0-9]+)/eteindre", "action", hub=True)
def h_wol_off(n, r):
    t = n.hub.wol.eteindre(r.p["id"])
    return {"ok": True, "cible": t}


@route("GET", "/api/wol/cle", hub=True)
def h_wol_key(n, r):
    return {"cle": n.hub.wol.cle_publique(), "utilisateur": n.conf.get("wol_utilisateur")}


@route("POST", "/api/wol/(?P<id>[a-z0-9]+)/supprimer", "action", hub=True)
def h_wol_del(n, r):
    n.hub.wol.remove(r.p["id"])
    return {"ok": True}


# --- mises à jour ----------------------------------------------------------------------------
def _targets(n, names):
    online = [x["nom"] for x in n.hub.nodes(n.status()) if x["en_ligne"]]
    if names is None:
        return online
    if not isinstance(names, list) or any(not isinstance(x, str) for x in names):
        raise ApiError(400, "« noeuds » doit être une liste de noms.", "noeuds")
    return names


@route("GET", "/api/maj", hub=True)
def h_maj(n, r):
    out = []
    for name in _targets(n, None):
        try:
            out.append(n.hub.agent(name, "GET", "/api/agent/maj", timeout=8))
        except ApiError as ex:
            out.append({"noeud": name, "erreur": ex.message})
    return {"noeuds": out}


@route("POST", "/api/maj/(?P<action>verifier|appliquer)", "action", hub=True)
def h_maj_action(n, r):
    res = []
    names = _targets(n, r.b.get("noeuds"))
    for name in sorted(names, key=lambda x: x == n.name):     # le hub en dernier
        try:
            res.append(dict(n.hub.agent(name, "POST", "/api/agent/maj/" + r.p["action"], {}), noeud=name))
        except ApiError as ex:
            res.append({"noeud": name, "ok": False, "erreur": ex.message})
    return {"ok": all(x.get("ok") for x in res), "noeuds": res}


@route("POST", "/api/maj/paquet", "action", hub=True)
def h_maj_paquet(n, r):
    """Installe un paquet YDZ (.zip) déposé depuis l'interface. Corps : le zip brut."""
    from . import paquet
    import subprocess
    brut = r.b.get("_brut") or b""

    def redemarrer():
        try:
            subprocess.Popen(["systemctl", "restart", "--no-block", "ydzd"])
        except OSError:
            pass
    try:
        res = paquet.installer(n.base, brut, redemarrer)
    except paquet.ErreurPaquet as ex:
        raise ApiError(400, str(ex), "paquet")
    return res


# --- écran, badges ---------------------------------------------------------------------------
@route("GET", "/api/ecran", hub=True)
def h_screen(n, r):
    return n.hub.screen.status()


@route("POST", "/api/ecran", "action", hub=True)
def h_screen_set(n, r):
    restart = n.hub.screen.set(r.b.get("luminosite"), r.b.get("veille_min"), r.b.get("rotation"))
    return {"ok": True, "redemarrage_kiosque": restart, "ecran": n.hub.screen.status()}


@route("GET", "/api/affichage", hub=True)
def h_affichage(n, r):
    return dict(n.hub.maison.status(n.hub.nodes(n.status())), reglages=n.hub.maison.reglages())


@route("POST", "/api/affichage", "action", hub=True)
def h_affichage_set(n, r):
    n.hub.maison.regler(r.b)
    return dict(n.hub.maison.status(n.hub.nodes(n.status())), ok=True, reglages=n.hub.maison.reglages())


@route("POST", "/api/ecran/activite", hub=True)
def h_screen_touch(n, r):
    """Appelée par l'interface locale à chaque appui : repousse la veille."""
    if not r.ctx.get("local"):
        return {"ok": True, "reveil": False}
    return {"ok": True, "reveil": n.hub.screen.activity()}


@route("POST", "/api/badges", "action", hub=True)
def h_badges(n, r):
    body = {k: r.b[k] for k in ("luminosite", "accent", "retourne") if k in r.b}
    names = _targets(n, [r.b["noeud"]] if r.b.get("noeud") else None)
    res = []
    for name in names:
        try:
            res.append(n.hub.agent(name, "POST", "/api/agent/badge", body, timeout=5))
        except ApiError as ex:
            res.append({"noeud": name, "ok": False, "erreur": ex.message})
    return {"ok": all(x.get("ok") for x in res), "noeuds": res}


# --- tâches, diagnostic ----------------------------------------------------------------------
@route("GET", "/api/taches", hub=True)
def h_tasks(n, r):
    return {"taches": n.hub.snapshot(n.status())["taches"]}


@route("GET", "/api/taches/(?P<id>[0-9a-f]+)", hub=True)
def h_task(n, r):
    return n.hub.agent(r.q.get("noeud"), "GET", "/api/agent/taches/" + quote(r.p["id"]), timeout=5)


@route("GET", "/api/diagnostic", "action", hub=True)
def h_diag(n, r):
    return n.hub.agent(r.q.get("noeud"), "GET", "/api/agent/diagnostic", timeout=40)


__all__ = ["Node", "ROUTES", "mask_settings"]
