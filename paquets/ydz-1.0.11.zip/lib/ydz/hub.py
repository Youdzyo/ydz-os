"""Hub (FORGE) : découverte et suivi des pairs, agrégation, ordres signés vers
les agents, ventilateur, arrêt propre de la tour."""
import json
import re
import secrets
import threading

from .voisins import Voisins
from .maison import Maison
from .reseau import Reseau
from .notifs import Notifications, Veilleur
from .sauvegarde import Sauvegarde
from .minecraft import Minecraft
from . import paquet

from . import auth as authmod
from .core import ApiError
from .fan import FanController
from .services import Screen, Wol

OFFLINE_AFTER = 8.0        # secondes sans réponse avant « hors ligne »
PAIR_TTL = 300           # une demande d'appairage vit 5 minutes
PAIR_COOLDOWN = 600      # après un refus, on ne redemande pas pendant 10 minutes
RE_NODE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,30}[a-z0-9])?$")


def parse_avahi_browse(text):
    """Sortie de `avahi-browse -rpt _ydz._tcp` -> {nom d'hôte: ip}."""
    out = {}
    for line in (text or "").splitlines():
        p = line.split(";")
        if len(p) >= 9 and p[0] == "=" and p[2] == "IPv4":
            host = p[6].split(".")[0].lower()
            if RE_NODE.match(host):
                out[host] = p[7]
    return out


class Peer:
    def __init__(self, name):
        self.name = name
        self.status = None
        self.seen = None           # monotonic du dernier succès
        self.addr = None
        self.bad_key = False
        self.clock = 0             # heure du pair - heure du hub (s)
        self.next_resolve = 0
        self.thread = None


class Peers:
    def __init__(self, sys, conf, self_name, key_fn):
        self.sys, self.conf, self.self_name, self.key_fn = sys, conf, self_name, key_fn
        self.port = conf.int("port")
        self.peers = {}
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self._browse_at = 0
        self.on_unpaired = None
        for n in conf.peers():
            self.add(n)

    def add(self, name, addr=None):
        name = name.lower().split(".")[0]
        if name == self.self_name or not RE_NODE.match(name):
            return
        with self.lock:
            p = self.peers.get(name)
            if p is None:
                p = self.peers[name] = Peer(name)
            if addr and not p.addr:
                p.addr = addr

    def url(self, peer):
        over = getattr(self.sys, "peer_url", None)
        if over:
            return over(peer.name)
        now = self.sys.monotonic()
        if not peer.addr and now >= peer.next_resolve:
            peer.next_resolve = now + 30
            peer.addr = self.sys.resolve(peer.name + ".local") or self.sys.resolve(peer.name)
            if not peer.addr and self.sys.which("avahi-resolve"):     # libnss-mdns absent ou muet
                r = self.sys.run(["avahi-resolve", "-4", "-n", peer.name + ".local"], timeout=4)
                parts = r.out.split()
                if r.ok and len(parts) >= 2 and parts[1].count(".") == 3:
                    peer.addr = parts[1]
        return "http://%s:%d" % (peer.addr, self.port) if peer.addr else None

    def poll_one(self, peer):
        url = self.url(peer)
        if not url:
            return False
        code, st = self.sys.http("GET", url + "/api/status", timeout=1.5)
        if code != 200 or not isinstance(st, dict) or st.get("v") != 1:
            if peer.seen is None or self.sys.monotonic() - peer.seen > 30:
                peer.addr = None                      # l'adresse a pu changer (DHCP)
            return False
        peer.status, peer.seen = st, self.sys.monotonic()
        peer.clock = int(st.get("heure", self.sys.now()) - self.sys.now())
        if st.get("appaire") is False and self.on_unpaired:
            self.on_unpaired(peer)        # jamais d'envoi de clé ici : une demande attend l'accord de l'utilisateur
        return True

    def _loop(self, peer):
        while not self.stop.is_set():
            ok = False
            try:
                ok = self.poll_one(peer)
            except Exception:
                pass
            self.stop.wait(2.0 if ok or (peer.seen and self.sys.monotonic() - peer.seen < 60) else 6.0)

    def browse(self):
        """Découverte mDNS des nœuds non listés dans ydz.conf (toutes les 60 s)."""
        now = self.sys.monotonic()
        if now < self._browse_at or not self.sys.which("avahi-browse"):
            return
        self._browse_at = now + 60
        r = self.sys.run(["avahi-browse", "-rpt", "_ydz._tcp"], timeout=8)
        for host, ip in parse_avahi_browse(r.out).items():
            self.add(host, ip)
        self.start()

    def start(self):
        with self.lock:
            for p in self.peers.values():
                if p.thread is None:
                    p.thread = threading.Thread(target=self._loop, args=(p,), name="ydz-pair-" + p.name,
                                                daemon=True)
                    p.thread.start()

    def online(self, peer):
        return peer.seen is not None and self.sys.monotonic() - peer.seen < OFFLINE_AFTER

    def get(self, name):
        return self.peers.get(name)

    def all(self):
        with self.lock:
            return list(self.peers.values())


class Hub:
    def __init__(self, node):
        self.node = node
        s, conf, state = node.sys, node.conf, node.state
        self.sys = s
        if not state.get("cle_tour"):
            state.set("cle_tour", secrets.token_urlsafe(32))
        self.auth = authmod.Auth(s, state)
        self.peers = Peers(s, conf, node.name, lambda: state.get("cle_tour"))
        self.fan = FanController(s, state, conf.int("ventilo_gpio"), conf.int("ventilo_hz"),
                                 conf.flag("ventilo_inverse"))
        self.wol = Wol(s, conf, state)
        self.screen = Screen(s, conf, state)
        self.relais = []                  # fonctions(alerte) appelées pour chaque alerte (Discord/ntfy : 1.0.11)
        self.voisins = Voisins(s, state, self.alerte)
        self.maison = Maison(self)
        self.reseau = Reseau(self)
        self.notifs = Notifications(self)
        self.relais.append(self.notifs.relayer)
        self.veilleur = Veilleur(self.alerte, s.now)
        self.sauvegarde = Sauvegarde(self)
        self.minecraft = Minecraft(self)
        self.halting = False
        self.pairing = {}                 # nom -> {"ip", "expire", "etat": attente|refuse}
        self.pair_lock = threading.Lock()
        self.auto_pair = False            # simulation seulement
        self.peers.on_unpaired = self.pair_request

    def start(self):
        self.peers.start()
        self.voisins.start()
        self.maison.start()
        self.reseau.start()
        self.sauvegarde.start()
        self.minecraft.start()

    # --- alertes : notification dans l'interface + relais extérieurs (Discord, ntfy : 1.0.11) -------
    def alerte(self, type_, niveau, texte, ui=True, **details):
        if ui:
            self.node.events.publish("notification", {"niveau": niveau, "texte": texte})
        a = dict(details, type=type_, niveau=niveau, texte=texte, heure=int(self.sys.now()))
        for relais in list(self.relais):
            try:
                relais(a)
            except Exception:             # un relais en panne ne doit jamais gêner le démon
                pass

    def tick(self, own):
        self.peers.browse()
        temps = {own["nom"]: own.get("temp")}
        for p in self.peers.all():
            if self.peers.online(p):
                temps[p.name] = p.status.get("temp")
        self.fan.tick(temps)
        self.screen.tick()
        try:
            self.veilleur.observer(self.nodes(own))     # changements d'état -> alertes (1.0.11)
        except Exception:
            pass

    def relancer_annulation(self, horo):
        """Après « Annuler ce paquet » : ydzd puis l'écran redémarrent (unités systemd détachées)."""
        if type(self.sys).__name__ == "System":
            paquet.relancer_apres_annulation(horo)
        else:
            self.sys.spawn(["ydz-relance-annulation", horo])

    # --- appairage : le hub ne donne la clé de la tour qu'après un « Accepter » explicite ----------
    def pair_request(self, peer):
        """Appelé quand un pair se présente sans clé. Crée (ou laisse vivre) une demande de 5 min."""
        now = self.sys.monotonic()
        with self.pair_lock:
            e = self.pairing.get(peer.name)
            if e and e["expire"] > now and (e["etat"] == "refuse" or e["ip"] == peer.addr):
                return
            self.pairing[peer.name] = {"ip": peer.addr, "expire": now + PAIR_TTL, "etat": "attente"}
        if self.auto_pair:
            try:
                self.accept_pair(peer.name)
            except ApiError:
                pass
            return
        self.node.events.publish("notification", {
            "niveau": "info", "texte": "%s (%s) demande à rejoindre la tour : Accepter ou Refuser"
                                       % (peer.name.upper(), peer.addr)})

    def _request(self, name):
        e = self.pairing.get(name)
        if e and e["expire"] > self.sys.monotonic() and e["etat"] == "attente":
            return e
        return None

    def pending(self):
        now = self.sys.monotonic()
        with self.pair_lock:
            return [{"nom": k, "ip": e["ip"], "expire_s": int(e["expire"] - now)}
                    for k, e in sorted(self.pairing.items()) if self._request(k)]

    def accept_pair(self, name):
        with self.pair_lock:
            e = self._request(name)
            if not e:
                raise ApiError(404, "Aucune demande d'appairage en cours pour %s (elle expire après 5 minutes : "
                                    "le nœud la renouvelle tout seul)." % name.upper(), "appairage_aucune")
            peer = self.peers.get(name)
            if not peer or not peer.status or not self.peers.online(peer):
                raise ApiError(503, "%s ne répond plus." % name.upper(), "hors_ligne")
            if peer.addr != e["ip"] or peer.status.get("appaire") is not False:
                self.pairing.pop(name, None)
                raise ApiError(409, "%s a changé depuis la demande. Rien n'a été envoyé : attends la nouvelle demande."
                               % name.upper(), "appairage_change")
            body = json.dumps({"cle": self.node.state.get("cle_tour"), "hub": self.node.name}).encode()
            code, _ = self.sys.http("POST", self.peers.url(peer) + "/api/pair", body, timeout=3)
            if code != 200:
                raise ApiError(502, "%s a refusé l'appairage." % name.upper(), "appairage")
            self.pairing.pop(name, None)
            peer.bad_key = False
        return {"ok": True, "noeud": name}

    def refuse_pair(self, name):
        with self.pair_lock:
            if not self._request(name):
                raise ApiError(404, "Aucune demande d'appairage en cours pour %s." % name.upper(), "appairage_aucune")
            self.pairing[name] = {"ip": self.pairing[name]["ip"], "expire": self.sys.monotonic() + PAIR_COOLDOWN,
                                  "etat": "refuse"}
        return {"ok": True, "noeud": name}

    # --- agrégation -------------------------------------------------------
    def nodes(self, own):
        out = [dict(own, en_ligne=True, vu_il_y_a=0, connu=True, cle_invalide=False)]
        now = self.sys.monotonic()
        for p in sorted(self.peers.all(), key=lambda x: x.name):
            base = dict(p.status) if p.status else {"nom": p.name, "role": p.name if p.name in
                                                    ("forge", "vault", "pulse") else None}
            base.update(en_ligne=self.peers.online(p), connu=p.status is not None,
                        vu_il_y_a=int(now - p.seen) if p.seen is not None else None,
                        cle_invalide=p.bad_key, adresse=p.addr)
            out.append(base)
        return out

    def snapshot(self, own):
        nodes = self.nodes(own)
        alerts, level, tasks = [], "ok", []
        for n in nodes:
            if not n["connu"]:
                continue
            if not n["en_ligne"]:
                alerts.append({"noeud": n["nom"], "niveau": "warn", "texte": "%s ne répond plus" % n["nom"].upper()})
                level = "warn" if level == "ok" else level
                continue
            for a in n.get("alertes", []):
                alerts.append({"noeud": n["nom"], "niveau": n.get("etat", "warn"), "texte": a})
            if n.get("etat") == "crit" or (n.get("etat") == "warn" and level == "ok"):
                level = n["etat"]
            if n["cle_invalide"]:
                alerts.append({"noeud": n["nom"], "niveau": "warn",
                               "texte": "%s refuse les ordres du hub : lance « sudo ydz appairer » dessus"
                                        % n["nom"].upper()})
            tasks += n.get("taches", [])
        fan = self.fan.status()
        if not fan["pwm"]:
            alerts.append({"noeud": own["nom"], "niveau": "warn",
                           "texte": "Ventilateur non piloté (il tourne à 100 % par sécurité)"})
        tasks.sort(key=lambda t: -t["debut"])
        return {"heure": int(self.sys.now()), "hub": own["nom"], "version": own["version"],
                "tour": {"etat": level, "alertes": alerts, "arret_en_cours": self.halting},
                "noeuds": nodes, "ventilo": fan, "ecran": self.screen.status(),
                "reseau_maison": self.reseau_maison(), "pihole": self.reseau.pihole, "affichage": self.maison.status(nodes),
                "sauvegarde": self.sauvegarde.status(), "minecraft": self.minecraft.etat,
                "taches": tasks[:12], "auth": {"pin_defini": self.auth.pin_set}, "appairage": self.pending()}

    def reseau_maison(self):
        r = self.voisins.status()
        r["debit"] = self.reseau.status_debit()
        r["wifi"] = self.reseau.wifi
        return r

    # --- ordres vers un agent ----------------------------------------------
    def resolve_node(self, name, default=None):
        name = name or default or self.node.name
        if name == self.node.name:
            return name
        p = self.peers.get(name) if isinstance(name, str) else None
        if not p or not p.status:
            raise ApiError(404, "Nœud « %s » inconnu." % name, "noeud")
        if not self.peers.online(p):
            raise ApiError(503, "%s est hors ligne." % name.upper(), "hors_ligne")
        return name

    def agent(self, noeud, method, path, body=None, timeout=20, default=None):
        """Exécute une route d'agent sur `noeud` (appel direct si c'est le hub).
        Retourne le dict de réponse ; lève ApiError avec le message de l'agent."""
        name = self.resolve_node(noeud, default)
        if name == self.node.name:
            return self.node.dispatch_local(method, path, body)
        peer = self.peers.get(name)
        raw = json.dumps(body or {}).encode() if method == "POST" else b""
        hdr = {"X-YDZ-Sig": authmod.sig_header(self.node.state.get("cle_tour"), method, path,
                                               self.sys.now() + peer.clock, raw)}
        code, data = self.sys.http(method, self.peers.url(peer) + path, raw if method == "POST" else None,
                                   hdr, timeout=timeout)
        if code == 0:
            raise ApiError(503, "%s ne répond pas." % name.upper(), "hors_ligne")
        if code == 401:
            peer.bad_key = True
            raise ApiError(502, "%s refuse les ordres du hub. Sur ce nœud, lance « sudo ydz appairer »."
                           % name.upper(), "appairage")
        if not isinstance(data, dict):
            raise ApiError(502, "Réponse illisible de %s." % name.upper(), "agent")
        if code >= 400:
            extra = {k: v for k, v in data.items() if k not in ("erreur", "code")}
            raise ApiError(code, data.get("erreur", "Erreur sur %s." % name), data.get("code", "agent"), **extra)
        peer.bad_key = False
        data.setdefault("noeud", name)
        return data

    # --- arrêt / redémarrage de la tour --------------------------------------
    def tower(self, action):
        """Éteint (ou redémarre) d'abord les autres nœuds, vault en premier
        (ses disques), puis le hub en dernier."""
        if action not in ("eteindre", "redemarrer"):
            raise ApiError(400, "Action inconnue.", "action")
        self.halting = True
        res = []
        order = sorted(self.peers.all(), key=lambda p: (p.name != "vault", p.name))
        for p in order:
            if not self.peers.online(p):
                continue
            try:
                self.agent(p.name, "POST", "/api/" + action, {}, timeout=5)
                res.append({"noeud": p.name, "ok": True})
            except ApiError as ex:
                res.append({"noeud": p.name, "ok": False, "erreur": ex.message})
        self.node.power(action, delay=6 if res else 2)
        res.append({"noeud": self.node.name, "ok": True})
        return res
