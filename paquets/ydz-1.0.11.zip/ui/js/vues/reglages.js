// Réglages : ventilateur, écran, mises à jour (et historique des paquets), sauvegarde vers le PC, notifications,
// alimentation, code PIN, badges, terminal, diagnostic, à propos.
import { esc, ic, ilYA, borne } from "../outils.js";
import {
  S, NOM, btn, champ, interrupteur, pastille, vide, ouvrir, enteteDialogue, confirmer, toast, pave, actionsPave, toucheClavierPave, demanderPin, rendre,
} from "../noyau.js";
import { entete } from "../cadre.js";
import { lire, lireProtege, agir, session, changerPin, deconnexion, envoyerPaquet } from "../api.js";
import { alimentation } from "./accueil.js";
import { ouvrirAssistant } from "./assistant.js";

const SECTIONS = [
  ["ventilateur", "Ventilateur", "fan"],
  ["ecran", "Écran", "monitor"],
  ["mises-a-jour", "Mises à jour", "download"],
  ["sauvegarde", "Sauvegarde", "hard-drive-upload"],
  ["notifications", "Notifications", "bell"],
  ["alimentation", "Redémarrer, éteindre", "power"],
  ["code-pin", "Code PIN", "lock"],
  ["badges", "Badges", "badge-check"],
  ["terminal", "Terminal", "terminal"],
  ["diagnostic", "Diagnostic", "heart-pulse"],
  ["a-propos", "À propos", "info"],
];
const ICONE_MODE = { silence: "volume-x", equilibre: "scale", performance: "rocket" };
const AIDE_MODE = { silence: "Discret, laisse monter la température", equilibre: "Le bon compromis au quotidien", performance: "Refroidit tôt, pour les longues sessions" };

// ---------------------------------------------------------------------------------- ventilateur
function courbe(v) {
  const L = 520, H = 210, g = 44, b = 30, d = 14, h = 12;
  const x = (t) => g + ((borne(t, 30, 85) - 30) / 55) * (L - g - d);
  const y = (p) => h + (1 - p / 100) * (H - h - b);
  const chemin = (pts) => pts.map(([t, p], i) => `${i ? "L" : "M"}${x(t).toFixed(1)} ${y(p).toFixed(1)}`).join(" ");
  const active = v.courbe || [];
  const px = v.temp != null ? x(v.temp) : null, py = y(v.vitesse ?? 0);
  return `<svg class="graphe-ventilo" viewBox="0 0 ${L} ${H}" role="img" aria-label="Courbe du ventilateur : vitesse selon la température">
    ${[0, 25, 50, 75, 100].map((p) => `<line class="grille" x1="${g}" x2="${L - d}" y1="${y(p)}" y2="${y(p)}"/><text class="axe" x="${g - 8}" y="${y(p) + 4}" text-anchor="end">${p}</text>`).join("")}
    ${[30, 40, 50, 60, 70, 80].map((t) => `<text class="axe" x="${x(t)}" y="${H - 8}" text-anchor="middle">${t}°</text>`).join("")}
    ${(v.modes || []).filter((m) => m.id !== v.mode).map((m) => `<path class="autre" d="${chemin(m.courbe)}"/>`).join("")}
    <path class="aire" d="${chemin(active)} L${x(85)} ${y(0)} L${x(30)} ${y(0)} Z"/>
    <path class="active" d="${chemin(active)}"/>
    ${px != null ? `<line class="repere" x1="${px}" x2="${px}" y1="${y(0)}" y2="${py}"/><circle class="halo" cx="${px}" cy="${py}" r="11"/><circle class="point" cx="${px}" cy="${py}" r="5.5"/>` : ""}
  </svg>`;
}
function ventilateur() {
  const v = S.etat.ventilo;
  return `
    ${v.pwm === false ? `<p class="bandeau warn">${ic("triangle-alert")}${esc(v.erreur || "Le ventilateur n'est pas piloté : il tourne à fond par sécurité.")} Voir Diagnostic.</p>` : ""}
    <div class="modes">${(v.modes || []).map((m) => `<button type="button" class="mode${m.id === v.mode ? " actif" : ""}" data-action="mode" data-id="${m.id}">
      ${ic(ICONE_MODE[m.id] || "fan")}<b>${esc(m.nom)}</b><small>${AIDE_MODE[m.id] || ""}</small></button>`).join("")}</div>
    <div class="carte bloc ventilo-detail">
      <div class="ventilo-chiffres">
        <div><small>Vitesse</small><b class="chiffre">${v.vitesse}<small>%</small></b></div>
        <div><small>Nœud le plus chaud</small><b class="chiffre moyen">${v.noeud ? `${NOM(v.noeud)}` : "–"}</b><span>${v.temp != null ? `${v.temp.toFixed(1)} °C` : "température inconnue"}</span></div>
        ${btn("test", v.test ? "Test en cours…" : "Tester 5 s", { icone: "wind", off: v.test })}
      </div>
      ${courbe(v)}
    </div>
    <p class="note-fine">${ic("info")}Le ventilateur suit le nœud le plus chaud. Le point montre où il se trouve sur la courbe du mode choisi.</p>`;
}

// ---------------------------------------------------------------------------------------- écran
const VEILLES = [[0, "Jamais"], [1, "1 min"], [5, "5 min"], [10, "10 min"], [30, "30 min"], [60, "1 h"]];
function glissiere(champNom, valeur, min, max, fin, icone) {
  return `<div class="glissiere">${ic(icone, "pale")}
    <input type="range" min="${min}" max="${max}" step="5" value="${valeur}" data-champ="${champNom}" data-rendre data-fin="${fin}" style="--p:${((valeur - min) / (max - min)) * 100}%" aria-label="Luminosité">
    <b>${valeur} %</b></div>`;
}
function ecran(vue) {
  const e = S.etat.ecran;
  if (!e) return "";
  const lum = vue.donnees.lum ?? e.luminosite;
  return `
    ${e.present ? "" : `<p class="bandeau warn">${ic("triangle-alert")}Aucun écran détecté sur forge. Ces réglages s'appliqueront quand il sera branché.</p>`}
    <div class="carte bloc"><h2 class="bloc-titre">${ic("sun")}Luminosité</h2>${glissiere("lum", lum, 5, 100, "luminosite", "sun")}</div>
    <div class="carte bloc"><h2 class="bloc-titre">${ic("moon")}Mise en veille</h2>
      <div class="segments">${VEILLES.map(([m, nom]) => `<button type="button" class="${e.veille_min === m ? "actif" : ""}" data-action="veille" data-min="${m}">${nom}</button>`).join("")}</div>
      <p class="note-fine">${e.veille_min ? `L'écran s'éteint après ${e.veille_min} min sans appui. Touche-le pour le rallumer.` : "L'écran reste toujours allumé."}</p></div>
    <div class="carte bloc"><h2 class="bloc-titre">${ic("rotate-cw")}Rotation</h2>
      <div class="segments">${(e.rotations || [0, 90, 180, 270]).map((r) => `<button type="button" class="${e.rotation === r ? "actif" : ""}" data-action="rotation" data-angle="${r}">${r}°</button>`).join("")}</div>
      <p class="note-fine">Si l'image est à l'envers, passe de 90 à 270. L'écran se recharge en quelques secondes.</p></div>
    ${ecranPi(vue)}`;
}

// Écran du Pi en mode affichage (1.0.9) : nuit, pages, météo, prix de l'électricité.
const ROTATIONS = [[0, "Jamais"], [15, "15 s"], [30, "30 s"], [60, "1 min"], [120, "2 min"]];
function ecranPi(vue) {
  const a = S.etat.affichage;
  if (!a) return "";
  const n = a.nuit;
  const mode = n.actif ? n.mode : "non";
  const prix = a.conso?.prix_kwh ?? 0.194;
  return `
    <h2 class="rubrique">Écran d'affichage (HDMI)</h2>
    <div class="carte bloc"><h2 class="bloc-titre">${ic("moon")}La nuit</h2>
      <div class="segments">${[["non", "Rien"], ["eteint", "Écran éteint"], ["horloge", "Horloge douce"]].map(([id, nom]) =>
        `<button type="button" class="${mode === id ? "actif" : ""}" data-action="nuit-mode" data-mode="${id}">${nom}</button>`).join("")}</div>
      ${n.actif ? `<div class="plage-nuit">De <input type="time" class="champ" value="${n.debut}" data-fin="nuit-heure" data-cle-heure="nuit_debut" aria-label="Début de la nuit">
        à <input type="time" class="champ" value="${n.fin}" data-fin="nuit-heure" data-cle-heure="nuit_fin" aria-label="Fin de la nuit"></div>` : ""}
      <p class="note-fine">${n.actif ? (n.mode === "eteint" ? `L'écran se met en veille de ${n.debut} à ${n.fin}.` : `De ${n.debut} à ${n.fin}, seule une grande horloge très sombre reste affichée.`) : "L'écran reste allumé toute la nuit."}${n.en_cours ? " C'est la nuit en ce moment." : ""}</p></div>
    <div class="carte bloc"><h2 class="bloc-titre">${ic("rotate-cw")}Pages qui tournent</h2>
      <div class="segments">${ROTATIONS.map(([v, nom]) => `<button type="button" class="${a.rotation_s === v ? "actif" : ""}" data-action="rotation-pages" data-s="${v}">${nom}</button>`).join("")}</div>
      <p class="note-fine">L'écran alterne entre la tour et la page « maison » (météo, services, PC, consommation).</p></div>
    <div class="carte bloc"><h2 class="bloc-titre">${ic("cloud-sun")}Météo</h2>
      <div class="ligne-champ"><input class="champ" type="text" value="${esc(vue.donnees.ville ?? a.meteo_ville)}" data-champ="ville" data-entree="ville" aria-label="Ville" maxlength="60">
        ${btn("ville", "Changer", { icone: "map-pin" })}</div></div>
    <div class="carte bloc"><h2 class="bloc-titre">${ic("zap")}Prix de l'électricité</h2>
      <div class="ligne-champ"><input class="champ" type="number" step="0.001" min="0.01" max="1.99" value="${vue.donnees.prix ?? prix}" data-champ="prix" data-entree="prix" aria-label="Prix du kWh en euros">
        ${btn("prix", "Enregistrer", { icone: "check" })}</div>
      <p class="note-fine">En euros par kWh, comme sur ta facture (tarif bleu EDF : environ 0,194 €). Sert à estimer le coût de la tour.</p></div>`;
}

// --------------------------------------------------------------------------------- mises à jour
function misesAJour(vue) {
  const m = vue.maj;
  if (!m) return `<div class="attente">${ic("loader-circle", "tourne")}</div>`;
  const total = m.noeuds.reduce((s, n) => s + (n.paquets || 0), 0);
  const enCours = m.noeuds.some((n) => n.en_cours);
  return `
    <div class="carte bloc maj-resume">
      <div><b class="chiffre moyen">${enCours ? "Mise à jour en cours" : total ? `${total} mise${total > 1 ? "s" : ""} à jour` : "Tout est à jour"}</b>
        <p>YDZ OS ${esc(S.etat.version)} · les correctifs de sécurité s'installent seuls chaque nuit.</p></div>
      <div class="actions">${btn("verifier", "Vérifier", { icone: "refresh-cw", off: enCours })}${btn("appliquer", "Tout installer", { icone: "download", classe: "plein", off: enCours || !total })}</div>
    </div>
    <div class="carte bloc paquet-bloc">
      <h2 class="bloc-titre">${ic("download")}Installer un paquet YDZ</h2>
      <p class="texte">Une amélioration préparée pour toi ? Choisis le fichier <b>.zip</b> (depuis Téléchargements sur le PC, ou Fichiers sur le téléphone) : YDZ l'installe et se recharge tout seul. L'ancienne version est gardée en sauvegarde.</p>
      <div class="actions"><label class="btn plein">${ic("download")}<span>Choisir un paquet .zip</span><input type="file" accept=".zip,application/zip,application/x-zip-compressed" data-fichier="paquet" hidden></label></div>
    </div>
    ${historiquePaquets(vue)}
    <div class="pile">${m.noeuds.map((n) => n.erreur
      ? `<div class="carte ligne-reglage" data-cle="mj-${n.noeud}"><span class="voyant off"></span><div><h3>${NOM(n.noeud)}</h3><p>Injoignable : ${esc(n.erreur)}</p></div></div>`
      : `<div class="carte ligne-reglage colonne" data-cle="mj-${n.noeud}">
          <div class="ligne"><span class="voyant ${n.paquets ? "warn" : "ok"}"></span>
            <div><h3>${NOM(n.noeud)}</h3><p>${n.paquets == null ? "Jamais vérifié" : n.paquets ? `${n.paquets} paquet${n.paquets > 1 ? "s" : ""} à mettre à jour` : "À jour"} · vérifié ${ilYA(n.derniere_verif)}</p></div>
            ${n.en_cours ? `<span class="pastille cours">${ic("loader-circle", "tourne")}Installation</span>` : n.redemarrage_requis ? pastille("warn", "Redémarrage requis", "rotate-cw") : ""}</div>
          ${n.en_cours && n.journal?.length ? `<pre class="journal mini">${n.journal.slice(-4).map(esc).join("\n")}</pre>` : ""}
          ${!n.en_cours && n.liste?.length ? `<p class="paquets">${n.liste.slice(0, 6).map((p) => esc(p.paquet)).join(", ")}${n.liste.length > 6 ? `, et ${n.liste.length - 6} autres` : ""}</p>` : ""}
        </div>`).join("")}</div>`;
}


// Historique des paquets (1.0.11) : on peut annuler le dernier, un à la fois.
const dateCourte = (t) => (t ? new Date(t * 1000).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "date inconnue");
function historiquePaquets(vue) {
  const h = vue.histo;
  if (!h) return "";
  return `<div class="carte bloc historique-paquets" data-cle="histo">
    <h2 class="bloc-titre">${ic("history")}Historique des paquets</h2>
    ${h.length ? `<ul class="liste-paquets">${h.slice(0, 10).map((x) => `<li class="${x.annulee ? "annule" : ""}" data-cle="hp-${esc(x.id)}">
        <span class="paquet-icone">${ic(x.annulee ? "undo-2" : "download")}</span>
        <div class="paquet-textes"><b>${esc(x.nom || "Paquet sans nom")}</b>
          <small>${dateCourte(x.date)} · ${x.version_avant ? `${esc(x.version_avant)} → ` : ""}${esc(x.version || "?")} · ${x.fichiers} fichier${x.fichiers > 1 ? "s" : ""}${x.complet ? "" : " · sauvegarde ancienne"}</small></div>
        ${x.annulee ? pastille("off", "Annulé", "undo-2") : x.annulable ? btn("annuler-paquet", "Annuler ce paquet", { icone: "undo-2", classe: "discret danger-texte", d: { id: x.id } }) : ""}
      </li>`).join("")}</ul>
      <p class="note-fine">${ic("info")}Seul le dernier paquet installé peut être annulé, puis le précédent, et ainsi de suite. Les 10 plus récents sont gardés.</p>`
    : `<p class="texte">Aucun paquet installé depuis cette interface pour l'instant.</p>`}
  </div>`;
}

// Copie dans le presse-papiers, y compris en http simple (iPhone compris).
async function copierTexte(texte, message = "Commande copiée.") {
  let ok = false;
  try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(texte); ok = true; } } catch { /* http simple */ }
  if (!ok) {
    const t = document.createElement("textarea");
    t.value = texte; t.setAttribute("readonly", "");
    t.style.cssText = "position:fixed;top:0;left:-9999px;opacity:0";
    document.body.appendChild(t);
    t.select(); t.setSelectionRange(0, texte.length);
    try { ok = document.execCommand("copy"); } catch { /* navigateur ancien */ }
    t.remove();
  }
  toast(ok ? message : "Sélectionne le texte et copie-le à la main.", ok ? "ok" : undefined);
}

// ----------------------------------------------------------------------------- sauvegarde (1.0.11)
const octetsFr = (n) => (n == null ? "–" : n >= 1e9 ? `${(n / 1e9).toFixed(1).replace(".", ",")} Go` : n >= 1e6 ? `${(n / 1e6).toFixed(1).replace(".", ",")} Mo` : `${Math.max(1, Math.round(n / 1e3))} Ko`);
const quand = (t) => {
  if (!t) return "";
  const d = new Date(t * 1000), auj = new Date(), dem = new Date(); dem.setDate(auj.getDate() + 1);
  const hm = d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === auj.toDateString()) return `aujourd'hui à ${hm}`;
  if (d.toDateString() === dem.toDateString()) return `demain à ${hm}`;
  return `${d.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })} à ${hm}`;
};
const GARDES = [3, 7, 14, 30];
function blocSauvegarde(vue) {
  const s = S.etat.sauvegarde;
  if (!s) return `<div class="attente">${ic("loader-circle", "tourne")}</div>`;
  const d = s.derniere;
  let tete;
  if (s.en_cours) tete = [`${ic("loader-circle", "tourne")}`, "cours", "Sauvegarde en cours", esc(s.etape || "…")];
  else if (!d) tete = [ic("hard-drive-upload"), "", "Aucune sauvegarde pour l'instant", s.actif ? `La première se fera ${quand(s.prochaine)}.` : "Prépare le PC, puis active la sauvegarde."];
  else if (d.ok) tete = [ic("circle-check"), "ok", `Sauvegardé ${ilYA(d.t)}`, `${octetsFr(d.taille)} envoyés sur le PC · ${esc(d.fichier || "")}`];
  else tete = [ic("triangle-alert"), "crit", "La dernière sauvegarde a échoué", `${esc(d.erreur || "Raison inconnue")} · ${ilYA(d.t)}`];
  const heure = vue.donnees.svHeure ?? s.heure;
  return `
    ${s.smbclient === false ? `<p class="bandeau warn">${ic("triangle-alert")}L'outil smbclient manque sur forge : réinstalle le paquet 1.0.11, ou lance <code>sudo apt install smbclient</code>.</p>` : ""}
    <div class="carte bloc sauvegarde-etat" data-cle="sv-etat">
      <div class="sv-tete"><span class="grand-icone ${tete[1]}">${tete[0]}</span>
        <div><h2>${tete[2]}</h2><p class="texte">${tete[3]}</p></div>
        ${interrupteur("sv-actif", s.actif, {}, "Sauvegarde automatique")}</div>
      <dl class="fiche">
        <div><dt>Automatique</dt><dd>${s.actif ? `chaque jour à ${esc(s.heure)}` : "désactivée"}</dd></div>
        <div><dt>Prochaine</dt><dd>${s.actif && s.prochaine ? quand(s.prochaine) : "–"}</dd></div>
        <div><dt>Dernière réussie</dt><dd>${s.dernier_succes ? ilYA(s.dernier_succes) : "jamais"}</dd></div>
        <div><dt>Vers</dt><dd>\\\\${esc(s.hote || "?")}\\${esc(s.partage)}</dd></div>
      </dl>
      <div class="actions">${btn("sv-maintenant", s.en_cours ? "En cours…" : "Sauvegarder maintenant", { icone: "hard-drive-upload", classe: "plein", off: s.en_cours })}${btn("sv-preparer", "Préparer le PC", { icone: "monitor" })}</div>
    </div>
    <div class="carte bloc" data-cle="sv-reglages"><h2 class="bloc-titre">${ic("clock")}Quand et combien</h2>
      <div class="ligne-champ"><span class="libelle-champ">Heure</span><input type="time" class="champ court" value="${esc(heure)}" data-fin="sv-heure" aria-label="Heure de la sauvegarde"></div>
      <p class="note-fine">Si le PC est éteint à cette heure, forge réessaie toutes les heures jusqu'à 09:00, puis te prévient.</p>
      <h3 class="intertitre">Garder sur le PC</h3>
      <div class="segments">${GARDES.map((g) => `<button type="button" class="${s.garder === g ? "actif" : ""}" data-action="sv-garder" data-n="${g}">${g} dernières</button>`).join("")}</div>
      <label class="reglage en-ligne cadre"><span class="reglage-nom">Inclure les données des apps</span>${interrupteur("sv-donnees", s.inclure_donnees_apps, {}, "Inclure les données des apps")}
        <small>${s.inclure_donnees_apps ? "Mondes Minecraft, bases des apps… L'archive peut devenir très grosse." : "Par défaut : configuration de la tour, réglages et mots de passe des apps (quelques Mo)."}</small></label>
    </div>
    <p class="note-fine">${ic("info")}Chaque sauvegarde est un fichier <b>ydz-forge-AAAAMMJJ-HHMM.tar.gz</b> dans <b>C:\\YDZ-Sauvegardes</b> : /etc/ydz et /var/lib/ydz (réglages, apps, clés). Il contient des mots de passe : garde ce dossier pour toi.</p>`;
}

function ouvrirPreparerPC(r0) {
  let r = r0;
  const d = ouvrir({
    classe: "large",
    rendu: () => `${enteteDialogue("Préparer le PC", { icone: "monitor", sous: `${esc(r.hote || "PC")} · une seule fois, à refaire seulement si tu changes le mot de passe` })}
      <div class="dlg-corps formulaire">
        <p class="texte">1. Sur le PC, clic droit sur le menu Démarrer, puis <b>Terminal (administrateur)</b> ou <b>Windows PowerShell (administrateur)</b>.</p>
        <p class="texte">2. Copie le bloc ci-dessous, colle-le dans la fenêtre (clic droit) et appuie sur Entrée. Attends le message vert.</p>
        <pre class="commande-pc">${esc(r.script)}</pre>
        <p class="texte">3. Reviens ici et touche <b>Sauvegarder maintenant</b> pour vérifier.</p>
        <p class="note-fine">${ic("info")}Le script crée le compte <b>${esc(r.utilisateur)}</b> (caché de l'écran de connexion), le dossier <b>${esc(r.dossier)}</b>, le partage <b>${esc(r.partage)}</b> réservé à ce compte, et ouvre le port 445 pour forge (${esc(r.ip_pi)}) seulement, même en réseau « Public ». On peut le relancer sans risque. Le mot de passe ne s'affiche qu'ici.</p>
      </div>
      <footer class="dlg-pied">${btn("nouveau-mdp", "Nouveau mot de passe", { icone: "key-round", classe: "discret" })}${btn("copier", "Copier", { icone: "copy", classe: "discret" })}${btn("fermer", "Terminé", { classe: "plein" })}</footer>`,
    actions: {
      copier() { return copierTexte(r.script); },
      async "nouveau-mdp"() {
        if (!(await confirmer({ titre: "Changer le mot de passe ?", texte: "Forge tire un nouveau mot de passe. Il faudra recoller le script sur le PC, sinon les sauvegardes échoueront.", libelle: "Changer", icone: "key-round" }))) return;
        r = await agir("/api/sauvegarde/preparer-pc", { nouveau_mot_de_passe: true });
        toast("Nouveau mot de passe : recopie le script sur le PC.", "ok");
        rendre();
      },
    },
  });
  return d;
}

// --------------------------------------------------------------------------- notifications (1.0.11)
function blocNotifications(vue) {
  const n = vue.notifs;
  if (!n) return `<div class="attente">${ic("loader-circle", "tourne")}</div>`;
  const dc = n.discord, nt = n.ntfy;
  const ntfySh = /^https:\/\/ntfy\.sh\/?$/.test(nt.serveur);
  return `
    <div class="notifs-grille">
    <div class="carte bloc" data-cle="nt-ntfy">
      <div class="nt-tete"><h2 class="bloc-titre">${ic("smartphone")}iPhone (ntfy)</h2>${interrupteur("nt-ntfy", nt.actif, {}, "Activer ntfy")}</div>
      <div class="sujet-ntfy"><small>Sujet</small><code>${esc(nt.sujet)}</code>${btn("nt-copier-sujet", "", { icone: "copy", classe: "rond discret", titre: "Copier le sujet" })}</div>
      ${nt.erreur ? `<p class="bandeau warn">${ic("triangle-alert")}${esc(nt.erreur)}</p>` : ""}
      <ol class="etapes">
        <li>Installe l'app <b>ntfy</b> depuis l'App Store.</li>
        <li>Touche <b>+</b>, colle le sujet <b>${esc(nt.sujet)}</b>${ntfySh ? "" : `, coche « Use another server » et mets <b>${esc(nt.serveur)}</b>`}, puis <b>Subscribe</b>.</li>
        <li>Autorise les notifications, active le bouton ci-dessus et touche <b>Envoyer un test</b>.</li>
      </ol>
      <div class="ligne-champ"><span class="libelle-champ">Serveur</span><input class="champ" type="text" value="${esc(vue.donnees.ntServeur ?? nt.serveur)}" data-champ="ntServeur" data-entree="nt-serveur" aria-label="Serveur ntfy" maxlength="80">${btn("nt-serveur", "", { icone: "check", classe: "rond", titre: "Enregistrer le serveur" })}</div>
      <p class="note-fine">${ic("lock")}Le sujet sert de mot de passe : qui le connaît peut lire tes alertes. Ne le partage pas.</p>
      <div class="actions">${btn("nt-test", "Envoyer un test", { icone: "send", classe: "plein", d: { canal: "ntfy" }, off: !nt.actif })}${btn("nt-sujet", "Nouveau sujet", { icone: "refresh-cw", classe: "discret" })}</div>
    </div>
    <div class="carte bloc" data-cle="nt-discord">
      <div class="nt-tete"><h2 class="bloc-titre">${ic("bell")}Discord</h2>${interrupteur("nt-discord", dc.actif, {}, "Activer Discord")}</div>
      ${dc.defini ? `<p class="webhook">${ic("circle-check")}<span>${esc(dc.apercu)}</span></p>` : ""}
      ${dc.erreur ? `<p class="bandeau warn">${ic("triangle-alert")}${esc(dc.erreur)}</p>` : ""}
      <ol class="etapes">
        <li>Dans Discord : <b>Paramètres du serveur</b> → <b>Intégrations</b> → <b>Webhooks</b>.</li>
        <li><b>Nouveau webhook</b>, choisis le salon, puis <b>Copier l'URL du webhook</b>.</li>
        <li>Colle-la ici et touche <b>Enregistrer</b>.</li>
      </ol>
      <div class="ligne-champ">${champ("discord", vue.donnees.discord ?? "", { type: "secret", placeholder: dc.defini ? "Coller une nouvelle adresse" : "https://discord.com/api/webhooks/…", label: "Adresse du webhook Discord", entree: "nt-discord-url", max: 220 })}${btn("nt-discord-url", "Enregistrer", { icone: "check" })}</div>
      <div class="actions">${btn("nt-test", "Envoyer un test", { icone: "send", classe: "plein", d: { canal: "discord" }, off: !dc.actif })}${dc.defini ? btn("nt-discord-oublier", "Retirer", { icone: "trash-2", classe: "discret danger-texte" }) : ""}</div>
    </div>
    </div>
    <div class="carte bloc" data-cle="nt-types"><h2 class="bloc-titre">${ic("bell-ring")}Quoi m'envoyer</h2>
      <ul class="types-alertes">${n.types.map((t) => `<li data-cle="ty-${t.id}"><div><b>${esc(t.nom)}</b><small>${esc(t.description)}</small></div>${interrupteur("nt-type", t.actif, { id: t.id }, t.nom)}</li>`).join("")}</ul>
      <p class="note-fine">${ic("info")}Une même alerte part au plus une fois par heure, et jamais plus de 20 par heure en tout.</p>
    </div>
    ${n.recentes?.length ? `<div class="carte bloc" data-cle="nt-recentes"><h2 class="bloc-titre">${ic("history")}Dernières alertes</h2>
      <ul class="liste-alertes">${n.recentes.slice(0, 8).map((a) => `<li class="${esc(a.niveau)}"><i class="voyant ${a.niveau === "info" ? "" : esc(a.niveau)}"></i><span>${esc(a.texte)}</span><small>${ilYA(a.t)}</small></li>`).join("")}</ul></div>` : ""}`;
}

// --------------------------------------------------------------------------------- alimentation
function blocAlimentation() {
  const e = S.etat;
  return `
    <div class="pile">${e.noeuds.filter((n) => n.connu).map((n) => `<div class="carte ligne-reglage" data-cle="al-${n.nom}">
      <span class="voyant ${n.en_ligne ? "ok" : "off"}"></span>
      <div><h3>${NOM(n.nom)}</h3><p>${n.en_ligne ? `${esc(n.role_nom || n.role)}${n.redemarrage_requis ? " · redémarrage requis" : ""}` : "Hors ligne"}</p></div>
      <div class="actions">${btn("n-redemarrer", "Redémarrer", { icone: "rotate-cw", d: { nom: n.nom }, off: !n.en_ligne })}${btn("n-eteindre", "Éteindre", { icone: "power", classe: "danger-texte", d: { nom: n.nom }, off: !n.en_ligne })}</div>
    </div>`).join("")}</div>
    <div class="carte bloc tour-entiere">
      <h2 class="bloc-titre">${ic("server")}Toute la tour</h2>
      <p class="texte">Les nœuds s'arrêtent dans l'ordre, forge en dernier. Attends que les badges affichent « Arrêt en cours » puis s'éteignent avant de couper le courant.</p>
      <div class="actions">${btn("tour-redemarrer", "Redémarrer la tour", { icone: "rotate-cw", classe: "grand" })}${btn("tour-eteindre", "Éteindre la tour", { icone: "power", classe: "danger grand" })}</div>
    </div>`;
}

// ------------------------------------------------------------------------------------- code PIN
// Choix ou changement du code. Renvoie true si le code est enregistré.
export function ouvrirChangementPin() {
  return new Promise((resoudre) => {
    const local = session.auth.local;
    const defini = S.etat.auth?.pin_defini || session.auth.pin_defini;
    const etapes = [...(defini && !local ? ["ancien"] : []), "nouveau", "encore"];
    const titres = { ancien: "Code actuel", nouveau: defini ? "Nouveau code" : "Choisis un code", encore: "Encore une fois" };
    const sous = { ancien: "Saisis le code PIN actuel.", nouveau: "4 à 8 chiffres. Évite 1234 et 0000, ils sont refusés.", encore: "Retape le même code pour vérifier." };
    const d = ouvrir({
      classe: "pin",
      donnees: { pin: "", erreur: "", secoue: 0, i: 0, saisies: {} },
      surFermer: (v) => resoudre(v === true),
      surTouche(ev) { toucheClavierPave(d, ev); },
      rendu: () => {
        const e = etapes[d.donnees.i];
        return `${enteteDialogue(titres[e], { icone: "lock", sous: sous[e] })}
          <div class="dlg-corps">${pave(d.donnees.pin, { erreur: d.donnees.erreur, secoue: d.donnees.secoue })}</div>`;
      },
      actions: actionsPave,
      async valider(pin) {
        const x = d.donnees;
        const e = etapes[x.i];
        x.saisies[e] = pin;
        x.pin = "";
        if (e !== "encore") { x.i++; return; }
        if (x.saisies.encore !== x.saisies.nouveau) {
          Object.assign(x, { i: etapes.indexOf("nouveau"), erreur: "Les deux codes sont différents. Recommence.", secoue: Date.now() });
          return;
        }
        try {
          await changerPin(x.saisies.nouveau, x.saisies.ancien);
          d.fermer(true);
          toast(local ? "Code PIN enregistré." : "Code PIN changé. Saisis-le à la prochaine action.", "ok");
        } catch (err) {
          Object.assign(x, { i: 0, saisies: {}, erreur: err.code === "pin_incorrect" ? "Le code actuel est incorrect." : err.message, secoue: Date.now() });
        }
      },
    });
  });
}
function codePin() {
  const a = session.auth;
  const defini = S.etat.auth?.pin_defini ?? a.pin_defini;
  let action;
  if (a.local) action = btn("pin-changer", defini ? "Changer le code" : "Choisir un code", { icone: "lock", classe: defini ? "" : "plein grand" });
  else if (!defini) action = "";
  else if (a.connecte) action = `${btn("pin-changer", "Changer le code", { icone: "lock" })}${btn("pin-verrouiller", "Verrouiller cet appareil", { icone: "lock" })}`;
  else action = btn("pin-saisir", "Saisir le code", { icone: "lock-open", classe: "plein grand" });
  return `
    <div class="carte bloc pin-etat">
      <span class="grand-icone ${defini ? "ok" : ""}">${ic(defini ? "shield-check" : "lock-open")}</span>
      <div><h2>${defini ? "Un code PIN protège la tour" : "Aucun code PIN"}</h2>
        <p class="texte">${a.local
          ? "Sur cet écran, tout est permis sans code. Depuis un téléphone ou un ordinateur, on peut tout voir, mais il faut le code pour agir."
          : defini ? (a.connecte ? "Cet appareil est déverrouillé : tu peux agir sur la tour." : "Depuis cet appareil, tu peux tout voir. Le code est demandé à la première action.")
          : "Depuis cet appareil, tu peux tout voir mais pas agir. Le premier code se choisit sur l'écran de la tour : Réglages, Code PIN."}</p>
        <div class="actions">${action}</div></div>
    </div>
    <p class="note-fine">${ic("info")}Code oublié ? Sur forge : <code>sudo ydz pin</code>. Après 5 erreurs, la saisie se bloque 30 secondes, puis de plus en plus longtemps.</p>`;
}

// --------------------------------------------------------------------------------------- badges
// L'API ne renvoie pas le sens du badge : l'interface se souvient du dernier choix fait ici.
function retournes() {
  try { return JSON.parse(localStorage.getItem("ydz_badges_retournes") || "{}"); } catch { return {}; }
}
const ACCENTS = [["D9713F", "Terracotta"], ["E8A33D", "Ambre"], ["7FBF8E", "Sauge"], ["5AA9E6", "Azur"], ["B48EE0", "Lilas"], ["F4EFE9", "Ivoire"]];
function badges(vue) {
  const noeuds = S.etat.noeuds.filter((n) => n.connu);
  const ref = noeuds.find((n) => n.badge?.present)?.badge || noeuds[0]?.badge || {};
  const lum = vue.donnees.blum ?? ref.luminosite ?? 80;
  const accent = (ref.accent || "D9713F").toUpperCase();
  return `
    <div class="carte bloc"><h2 class="bloc-titre">${ic("sun")}Luminosité des badges</h2>
      <div class="glissiere">${ic("sun", "pale")}<input type="range" min="0" max="100" step="5" value="${lum}" data-champ="blum" data-rendre data-fin="badge-luminosite" style="--p:${lum}%" aria-label="Luminosité des badges"><b>${lum} %</b></div></div>
    <div class="carte bloc"><h2 class="bloc-titre">${ic("sparkles")}Couleur d'accent</h2>
      <div class="pastilles-couleur">${ACCENTS.map(([hex, nom]) => `<button type="button" class="${accent === hex ? "actif" : ""}" style="--c:#${hex}" data-action="badge-accent" data-hex="${hex}" aria-label="${nom}"><i></i><span>${nom}</span></button>`).join("")}</div></div>
    <div class="pile">${noeuds.map((n) => {
      const b = n.badge || {};
      return `<div class="carte ligne-reglage" data-cle="bd-${n.nom}">
        <span class="mini-badge" style="--c:#${esc(b.accent || "D9713F")}"><b>${NOM(n.nom)}</b><i>${n.temp != null ? Math.round(n.temp) : "–"}°</i></span>
        <div><h3>${NOM(n.nom)}</h3><p>${!n.en_ligne ? "Nœud hors ligne" : b.present ? `Branché · firmware ${esc(b.fw || "?")}` : b.actif === false ? "Badge désactivé dans ydz.conf" : esc(b.erreur || "Badge non détecté : vérifie le câble USB")}</p></div>
        <label class="retourne"><span>Retourné</span>${interrupteur("badge-retourne", !!retournes()[n.nom], { nom: n.nom }, `Retourner le badge de ${n.nom}`)}</label>
      </div>`;
    }).join("")}</div>
    <p class="note-fine">${ic("info")}Un badge neuf reçoit le programme YDZ tout seul au branchement. S'il reste noir : <code>sudo ydz badge flasher</code> sur son Pi.</p>`;
}

// ----------------------------------------------------------------------------------- diagnostic
const ICONE_CONTROLE = { ok: ["circle-check", "ok"], warn: ["triangle-alert", "warn"], err: ["circle-x", "crit"], info: ["info", ""] };
function diagnostic(vue) {
  const noeuds = S.etat.noeuds.filter((n) => n.connu);
  const choisi = vue.donnees.diagNoeud || noeuds[0]?.nom;
  const r = vue.diag && vue.diag.noeud === choisi ? vue.diag : null;
  const soucis = r ? r.controles.filter((c) => c.etat === "warn" || c.etat === "err").length : 0;
  return `
    <div class="carte bloc diag-tete">
      <div class="segments">${noeuds.map((n) => `<button type="button" class="${n.nom === choisi ? "actif" : ""}" data-action="diag-noeud" data-nom="${n.nom}"${n.en_ligne ? "" : " disabled"}>${NOM(n.nom)}</button>`).join("")}</div>
      ${btn("diag-lancer", r ? "Relancer" : "Lancer le diagnostic", { icone: "heart-pulse", classe: "plein", d: { nom: choisi } })}
    </div>
    ${r ? `<p class="bandeau ${soucis ? "warn" : "ok"}">${ic(soucis ? "triangle-alert" : "circle-check")}${soucis ? `${soucis} point${soucis > 1 ? "s" : ""} à regarder sur ${NOM(choisi)}.` : `Tout est en ordre sur ${NOM(choisi)}.`}</p>
      <ul class="controles">${r.controles.map((c) => {
        const [icone, ton] = ICONE_CONTROLE[c.etat] || ICONE_CONTROLE.info;
        return `<li class="${ton}" data-cle="c-${esc(c.id)}">${ic(icone)}<div><b>${esc(c.nom)}</b><small>${esc(c.detail)}</small>${c.conseil ? `<p>${esc(c.conseil)}</p>` : ""}</div></li>`;
      }).join("")}</ul>`
      : vide("heart-pulse", "Vérifier le matériel", "Alimentation, ventilateur, écran, disques, badge, Docker : chaque point est contrôlé, avec un conseil si quelque chose cloche.")}`;
}

// -------------------------------------------------------------------------------------- terminal
// Terminal web (ttyd, port 7681) du Pi qui sert l'interface. Connexion avec le compte Linux.
const PORT_TERMINAL = 7681;
function terminal() {
  const url = `${location.protocol}//${location.hostname}:${PORT_TERMINAL}/`;
  return `
    <div class="carte bloc terminal-bloc">
      <h2 class="bloc-titre">${ic("terminal")}Terminal de ${esc(location.hostname)}</h2>
      <p class="texte">Le même terminal qu'en SSH. Connecte-toi avec ton nom d'utilisateur et ton mot de passe Linux.</p>
      <iframe class="terminal-cadre" src="${esc(url)}" title="Terminal" allow="clipboard-read; clipboard-write"></iframe>
      <div class="actions"><a class="btn" href="${esc(url)}" target="_blank" rel="noopener">${ic("external-link")}<span>Ouvrir en plein écran</span></a></div>
      <p class="note-fine">${ic("info")}Écran noir ou « connexion refusée » : le service ydz-terminal n'est pas lancé (sudo systemctl restart ydz-terminal). Réservé au réseau local : n'ouvre jamais le port ${PORT_TERMINAL} sur Internet.</p>
    </div>`;
}

// ------------------------------------------------------------------------------------- à propos
function aPropos(vue) {
  const s = vue.systeme;
  const e = S.etat;
  return `
    <div class="carte bloc apropos">
      <span class="logo geant">YDZ</span>
      <div><h2>YDZ OS ${esc(e.version)}</h2><p class="texte">Le système de la tour YDZ Stack. ${e.noeuds.filter((n) => n.connu).length} nœuds, une seule interface.</p>
        ${session.demo ? `<p class="note-fine">${ic("sparkles")}Mode démonstration : les données sont simulées, rien n'est modifié.</p>` : s?.simulation ? `<p class="note-fine">${ic("sparkles")}Le démon tourne en simulation (--sim).</p>` : ""}</div>
    </div>
    ${s ? `<div class="carte bloc"><h2 class="bloc-titre">${ic("server")}${NOM(s.nom)}</h2>
      <dl class="fiche"><div><dt>Modèle</dt><dd>${esc(s.modele)}</dd></div>
      ${Object.entries(s.config || {}).map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join("")}</dl>
      ${[...(s.erreurs_config || []), ...(s.erreurs_catalogue || [])].map((x) => `<p class="bandeau warn">${ic("triangle-alert")}${esc(x)}</p>`).join("")}</div>` : ""}
    <div class="carte bloc"><h2 class="bloc-titre">${ic("sparkles")}Premier démarrage</h2>
      <p class="texte">L'assistant reprend les étapes du début : code PIN, vérification des nœuds et des badges, test du ventilateur, premières applications.</p>
      <div class="actions">${btn("assistant", "Relancer l'assistant", { icone: "rocket" })}</div></div>
    <p class="note-fine">${ic("info")}Polices Unbounded et Instrument Sans (licence SIL OFL 1.1), icônes Lucide (licence ISC). Aucune ressource externe : la tour fonctionne hors ligne.</p>`;
}

// ------------------------------------------------------------------------------------------ vue
const vue = {
  donnees: {},
  maj: null, systeme: null, diag: null, histo: null, notifs: null,
  entrer() { this.donnees.lum = undefined; this.donnees.blum = undefined; },
  async charger(args) {
    const section = args?.[0];
    if (section === "mises-a-jour") {
      const [m, h] = await Promise.all([lire("/api/maj").catch(() => this.maj), lire("/api/maj/sauvegardes").catch(() => null)]);
      this.maj = m;
      if (h) this.histo = h.sauvegardes;
    }
    if (section === "notifications") this.notifs = await lire("/api/notifications").catch(() => this.notifs);
    if (section === "a-propos" && !this.systeme) this.systeme = await lire("/api/systeme").catch(() => null);
  },
  rendu(args) {
    const section = SECTIONS.find((s) => s[0] === args[0]);
    const courante = section || SECTIONS[0];
    const panneaux = { ventilateur, ecran, "mises-a-jour": misesAJour, sauvegarde: blocSauvegarde, notifications: blocNotifications, alimentation: blocAlimentation, "code-pin": codePin, badges, terminal, diagnostic, "a-propos": aPropos };
    return `${entete(section ? `<span class="large-seul">Réglages</span><span class="etroit-seul">${courante[1]}</span>` : "Réglages", { retour: section ? "#/reglages" : null, retourEtroit: true })}
    <div class="reglages ${section ? "avec-section" : "sans-section"}">
      <nav class="sections" aria-label="Sections des réglages">${SECTIONS.map(([id, nom, icone]) => `<a class="section-lien${courante[0] === id ? " actif" : ""}" href="#/reglages/${id}">${ic(icone)}<span>${nom}</span>${ic("chevron-right", "pale")}</a>`).join("")}</nav>
      <section class="panneau" data-cle="pan-${courante[0]}"><h2 class="panneau-titre">${courante[1]}</h2>${panneaux[courante[0]](this)}</section>
    </div>`;
  },
  actions: {
    async mode({ id }) {
      const r = await agir("/api/ventilo", { mode: id });
      S.etat.ventilo = r.ventilo;
      toast(`Ventilateur en mode ${r.ventilo.mode_nom}.`, "ok");
    },
    async test() {
      await agir("/api/ventilo/test", { secondes: 5 });
      S.etat.ventilo.test = true;
      toast("Test : le ventilateur tourne à fond pendant 5 secondes.");
    },
    async luminosite({ valeur }) {
      const r = await agir("/api/ecran", { luminosite: Number(valeur) });
      S.etat.ecran = r.ecran;
      this.donnees.lum = undefined;
    },
    async "nuit-mode"({ mode }) {
      const corps = mode === "non" ? { nuit_actif: false } : { nuit_actif: true, nuit_mode: mode };
      const r = await agir("/api/affichage", corps);
      Object.assign(S.etat.affichage, r);
    },
    async "nuit-heure"({ valeur, cleHeure }) {
      if (!/^\d\d:\d\d$/.test(valeur || "")) return;
      const r = await agir("/api/affichage", { [cleHeure]: valeur });
      Object.assign(S.etat.affichage, r);
      toast("Horaires de nuit enregistrés.", "ok");
    },
    async "rotation-pages"({ s }) {
      const r = await agir("/api/affichage", { rotation_s: Number(s) });
      Object.assign(S.etat.affichage, r);
    },
    async ville() {
      const v = (this.donnees.ville ?? "").trim();
      if (!v) return;
      const r = await agir("/api/affichage", { meteo_ville: v });
      Object.assign(S.etat.affichage, r);
      this.donnees.ville = undefined;
      toast(`Météo : ${r.meteo_ville}.`, "ok");
    },
    async prix() {
      const v = Number(String(this.donnees.prix ?? "").replace(",", "."));
      if (!(v > 0 && v < 2)) { toast("Prix invalide (par exemple 0.194).", "erreur"); return; }
      const r = await agir("/api/affichage", { prix_kwh: v });
      Object.assign(S.etat.affichage, r);
      this.donnees.prix = undefined;
      toast("Prix du kWh enregistré.", "ok");
    },
    async veille({ min }) {
      const r = await agir("/api/ecran", { veille_min: Number(min) });
      S.etat.ecran = r.ecran;
    },
    async rotation({ angle }) {
      if (Number(angle) === S.etat.ecran.rotation) return;
      if (!(await confirmer({ titre: `Tourner l'écran à ${angle}° ?`, texte: "L'écran de la tour se recharge pendant quelques secondes. Si l'image est à l'envers ensuite, reviens ici et choisis l'angle opposé.", libelle: "Tourner", icone: "rotate-cw" }))) return;
      const r = await agir("/api/ecran", { rotation: Number(angle) });
      S.etat.ecran = r.ecran;
      toast(r.redemarrage_kiosque ? "Rotation enregistrée. L'écran de la tour se recharge." : "Rotation enregistrée.", "ok");
    },
    async paquet({ fichier }) {
      if (!fichier) return;
      if (!/\.zip$/i.test(fichier.name)) { toast("Choisis un fichier .zip (paquet YDZ).", "erreur"); return; }
      if (!(await confirmer({ titre: "Installer ce paquet ?", texte: `${fichier.name} (${Math.max(1, Math.round(fichier.size / 1024))} Ko). YDZ copie les fichiers, garde une sauvegarde de l'ancienne version, puis se recharge.`, libelle: "Installer", icone: "download" }))) return;
      toast("Installation du paquet…");
      const r = await envoyerPaquet(fichier);
      toast(`Paquet « ${r.nom} » installé : ${r.fichiers} fichier${r.fichiers > 1 ? "s" : ""}${r.script ? ", script lancé" : ""}.`, "ok");
      setTimeout(() => location.reload(), r.redemarrage_demon ? 7000 : 1500);
    },
    async "annuler-paquet"({ id }) {
      const x = (this.histo || []).find((h) => h.id === id);
      if (!x) return;
      const avant = x.version_avant ? `YDZ OS ${x.version_avant}` : "la version d'avant";
      const texte = `Retour à <b>${esc(avant)}</b> : les fichiers remplacés par « ${esc(x.nom || "ce paquet")} » sont remis${x.complet ? ", ceux qu'il a ajoutés sont effacés" : ""}. YDZ redémarre et l'écran se recharge tout seul dans quelques secondes.`;
      const detail = x.complet ? "" : `<p class="bandeau warn">${ic("triangle-alert")}Sauvegarde faite avant 1.0.11 : seuls les fichiers remplacés sont remis. Les fichiers que ce paquet a ajoutés restent en place (ils ne gênent pas).</p>`;
      if (!(await confirmer({ titre: "Annuler ce paquet ?", texte, detail, libelle: "Annuler le paquet", danger: true, annuler: "Garder" }))) return;
      const r = await agir("/api/maj/annuler", { sauvegarde: id });
      toast(`Paquet annulé : retour à ${r.version_avant || "la version d'avant"}. Rechargement…`, "ok");
      setTimeout(() => location.reload(), 9000);
    },
    async "sv-actif"() {
      const r = await agir("/api/sauvegarde", { actif: !S.etat.sauvegarde.actif });
      S.etat.sauvegarde = r;
      toast(r.actif ? `Sauvegarde automatique chaque jour à ${r.heure}.` : "Sauvegarde automatique coupée.", r.actif ? "ok" : undefined);
    },
    async "sv-heure"({ valeur }) {
      if (!/^\d\d:\d\d$/.test(valeur || "")) return;
      S.etat.sauvegarde = await agir("/api/sauvegarde", { heure: valeur });
      this.donnees.svHeure = undefined;
      toast(`Sauvegarde à ${valeur}.`, "ok");
    },
    async "sv-garder"({ n }) { S.etat.sauvegarde = await agir("/api/sauvegarde", { garder: Number(n) }); },
    async "sv-donnees"() { S.etat.sauvegarde = await agir("/api/sauvegarde", { inclure_donnees_apps: !S.etat.sauvegarde.inclure_donnees_apps }); },
    async "sv-maintenant"() {
      S.etat.sauvegarde = await agir("/api/sauvegarde/lancer");
      toast("Sauvegarde lancée : le résultat arrive dans une minute ou deux.");
    },
    async "sv-preparer"() { ouvrirPreparerPC(await agir("/api/sauvegarde/preparer-pc")); },
    async "nt-ntfy"() { this.notifs = await agir("/api/notifications", { ntfy_actif: !this.notifs.ntfy.actif }); },
    async "nt-discord"() {
      if (!this.notifs.discord.defini) { toast("Colle d'abord l'adresse du webhook Discord.", "erreur"); return; }
      this.notifs = await agir("/api/notifications", { discord_actif: !this.notifs.discord.actif });
    },
    async "nt-discord-url"() {
      const v = (this.donnees.discord || "").trim();
      if (!v) return;
      this.notifs = await agir("/api/notifications", { discord: v });
      this.donnees.discord = "";
      toast("Webhook Discord enregistré.", "ok");
    },
    async "nt-discord-oublier"() {
      if (!(await confirmer({ titre: "Retirer Discord ?", texte: "Plus aucune alerte ne partira vers ce salon. Tu pourras recoller une adresse.", libelle: "Retirer", danger: true, icone: "trash-2" }))) return;
      this.notifs = await agir("/api/notifications", { discord: "" });
    },
    async "nt-serveur"() {
      const v = (this.donnees.ntServeur ?? "").trim();
      if (!v) return;
      this.notifs = await agir("/api/notifications", { ntfy_serveur: v });
      this.donnees.ntServeur = undefined;
      toast("Serveur ntfy enregistré.", "ok");
    },
    async "nt-sujet"() {
      if (!(await confirmer({ titre: "Nouveau sujet ntfy ?", texte: "L'ancien sujet ne recevra plus rien : il faudra t'abonner au nouveau dans l'app ntfy.", libelle: "Changer", icone: "refresh-cw" }))) return;
      this.notifs = await agir("/api/notifications", { ntfy_sujet: "" });
    },
    "nt-copier-sujet"() { return copierTexte(this.notifs.ntfy.sujet, "Sujet copié."); },
    async "nt-type"({ id }) {
      const t = this.notifs.types.find((x) => x.id === id);
      this.notifs = await agir("/api/notifications", { types: { [id]: !t.actif } });
    },
    async "nt-test"({ canal }) {
      const r = await agir("/api/notifications/test", { canal });
      const res = r.resultats?.[canal];
      if (res && !res.ok) toast(res.erreur || "L'envoi a échoué.", "erreur");
      else toast(canal === "discord" ? "Test envoyé sur Discord." : "Test envoyé : regarde ton téléphone.", "ok");
      this.notifs = await lire("/api/notifications").catch(() => this.notifs);
    },
    async verifier() {
      await agir("/api/maj/verifier");
      toast("Recherche de mises à jour sur tous les nœuds.");
    },
    async appliquer() {
      if (!(await confirmer({ titre: "Installer les mises à jour ?", texte: "Tous les nœuds en ligne se mettent à jour, forge en dernier. Les applications continuent de tourner ; un redémarrage peut être demandé à la fin.", libelle: "Installer", icone: "download" }))) return;
      const r = await agir("/api/maj/appliquer");
      const rates = (r.noeuds || []).filter((n) => !n.ok);
      if (rates.length) toast(`Échec sur ${rates.map((n) => NOM(n.noeud)).join(", ")} : ${rates[0].erreur || "nœud injoignable"}.`, "erreur");
      else toast("Mise à jour lancée.");
      this.maj = await lire("/api/maj").catch(() => this.maj);
    },
    "n-redemarrer"({ nom }) { return alimentation(nom, "redemarrer"); },
    "n-eteindre"({ nom }) { return alimentation(nom, "eteindre"); },
    async "tour-redemarrer"() {
      if (!(await confirmer({ titre: "Redémarrer toute la tour ?", texte: "Tous les nœuds redémarrent, forge en dernier. Les applications et cette interface seront coupées une à deux minutes.", libelle: "Redémarrer la tour", icone: "rotate-cw" }))) return;
      await agir("/api/tour/redemarrer");
      toast("La tour redémarre. L'interface revient toute seule.");
    },
    async "tour-eteindre"() {
      if (!(await confirmer({ titre: "Éteindre toute la tour ?", danger: true, libelle: "Éteindre la tour", texte: "Tous les nœuds s'arrêtent proprement, forge en dernier. Attends que les badges s'éteignent avant de couper le courant. Pour rallumer, il faudra remettre l'alimentation." }))) return;
      await agir("/api/tour/eteindre");
      toast("La tour s'éteint. Attends l'extinction des badges avant de couper le courant.");
    },
    async "pin-changer"() { await ouvrirChangementPin(); },
    "pin-saisir"() { return demanderPin(); },
    async "pin-verrouiller"() { await deconnexion(); toast("Appareil verrouillé."); },
    async "badge-luminosite"({ valeur }) {
      await agir("/api/badges", { luminosite: Number(valeur) });
      S.etat.noeuds.forEach((n) => { if (n.badge) n.badge.luminosite = Number(valeur); });
      this.donnees.blum = undefined;
    },
    async "badge-accent"({ hex }) {
      await agir("/api/badges", { accent: hex });
      S.etat.noeuds.forEach((n) => { if (n.badge) n.badge.accent = hex; });
    },
    async "badge-retourne"({ nom }) {
      const etat = retournes();
      const voulu = !etat[nom];
      await agir("/api/badges", { noeud: nom, retourne: voulu });
      etat[nom] = voulu;
      try { localStorage.setItem("ydz_badges_retournes", JSON.stringify(etat)); } catch { /* stockage indisponible */ }
    },
    "diag-noeud"({ nom }) { this.donnees.diagNoeud = nom; },
    async "diag-lancer"({ nom }) {
      this.diag = await lireProtege(`/api/diagnostic?noeud=${encodeURIComponent(nom)}`);
    },
    assistant() { ouvrirAssistant(); },
  },
};
export default vue;
