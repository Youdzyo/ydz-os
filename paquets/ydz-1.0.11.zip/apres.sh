#!/bin/bash
# YDZ 1.0.11 : fiabilité. ydzd est redémarré à la fin par le paquet.
echo "== 1.0.11 : fiabilité ($(date '+%H:%M:%S'))"
# smbclient envoie les sauvegardes vers le partage Windows du PC (facultatif : sans lui, la sauvegarde
# l'indique dans Réglages et le reste de YDZ fonctionne)
if ! command -v smbclient >/dev/null; then
    apt-get -o Acquire::ForceIPv4=true -o Acquire::Retries=10 install -y --no-install-recommends smbclient \
        && echo "smbclient installé" || echo "smbclient indisponible : sauvegarde vers le PC impossible pour l'instant"
else
    echo "smbclient déjà présent"
fi
# dossier de travail des sauvegardes (archive temporaire, fichier d'identification en 600)
install -d -m 700 /var/lib/ydz/tmp && rm -f /var/lib/ydz/tmp/smb-auth
# recharge l'écran une fois ydzd redémarré (pied « Minecraft » de la tuile Apps)
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.11 terminé"
