#!/bin/bash
# YDZ 1.0.14 : mises à jour automatiques depuis GitHub. ydzd est redémarré à la fin par le paquet (lib/ a changé).
echo "== 1.0.14 : mises à jour automatiques ($(date '+%H:%M:%S'))"

# 1. Dossier des versions téléchargées (paquets vérifiés, avancement de la chaîne d'installation)
mkdir -p /var/lib/ydz/maj && chmod 700 /var/lib/ydz/maj && chown root:root /var/lib/ydz/maj
echo "dossier /var/lib/ydz/maj prêt (0700)"
chmod 755 /opt/ydz/bin/ydz-maj-chaine /opt/ydz/kiosk/ydz-kiosk 2>/dev/null || true

# 2. Coupure réelle de l'écran la nuit : wlr-randr (déjà là normalement), wlopm en secours (facultatif)
if ! command -v wlr-randr >/dev/null; then
    apt-get -o Acquire::ForceIPv4=true -o Acquire::Retries=10 install -y --no-install-recommends wlr-randr \
        || echo "wlr-randr non installé (la mise en veille de l'écran restera indisponible)"
fi
if ! command -v wlopm >/dev/null; then
    apt-get -o Acquire::ForceIPv4=true -o Acquire::Retries=10 install -y --no-install-recommends wlopm \
        || echo "wlopm non installé (facultatif : seulement en secours de wlr-randr)"
fi

# 3. Accès à GitHub (lecture seule, sans compte) : simple contrôle, jamais bloquant
if curl -fsS -m 10 -o /dev/null -H "User-Agent: YDZ-OS" https://api.github.com/repos/Youdzyo/ydz-os/releases?per_page=1; then
    echo "GitHub joignable : la première vérification aura lieu ~5 min après le redémarrage de YDZ"
else
    echo "GitHub injoignable pour l'instant (ou dépôt pas encore public) : YDZ réessaiera toutes les 6 h"
fi

# 4. l'écran HDMI se recharge une fois ydzd revenu (nouveau guetteur de nuit, horloge avec secondes)
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk
echo "== 1.0.14 terminé"
