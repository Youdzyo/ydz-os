#!/bin/bash
# YDZ OS 1.0.18 : rien de lourd. ydzd redémarre tout seul (lib/ a changé) ; on recharge juste l'écran.
echo "== 1.0.18 : mise en place de « Perso » (agenda, rappels, Wi-Fi invités) ($(date '+%H:%M:%S'))"
# L'écran HDMI (kiosque) se recharge après le redémarrage de ydzd, pour prendre la nouvelle interface.
systemd-run --quiet --collect --on-active=25 /bin/systemctl restart ydz-kiosk \
  && echo "rechargement de l'écran programmé dans 25 s" \
  || echo "impossible de programmer le rechargement de l'écran (sans gravité : il se rechargera au prochain cycle)"
echo "== 1.0.18 terminé"
