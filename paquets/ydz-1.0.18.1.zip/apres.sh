#!/bin/bash
echo "== 1.0.18.1 : correctif Internet IPv4 ($(date '+%H:%M:%S'))"
# ydzd redémarre tout seul (lib/ a changé) ; on recharge juste l'écran.
systemd-run --quiet --collect --on-active=20 /bin/systemctl restart ydz-kiosk 2>/dev/null || true
echo "== 1.0.18.1 terminé"
